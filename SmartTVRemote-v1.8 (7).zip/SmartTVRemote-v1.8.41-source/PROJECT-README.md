# Smart TV Remote — project source 1.8.41

This archive contains the editable React/Vite web source, Android Java source, Gradle project files, and the latest WebView assets packaged by the Android app. It corresponds to app version 1.8.41 (versionCode 122).

## Open and build

- Open this folder in Android Studio and allow Gradle sync.
- Use JDK 21 and Android SDK 34; the project was built with Gradle 9.3.1.
- To rebuild the web UI: run `pnpm install`, `pnpm lint`, and `pnpm build` in `web_source_code`; copy the contents of `web_source_code/dist/` into `app/src/main/assets/` before assembling the Android app.

## Signing note

For security, this source archive does not include the private release keystore, its passwords, or machine-specific `local.properties`. A `keystore.properties.example` file is included as a template. To sign updates that install over an already-installed release, you must configure the original authorized signing key; a different key will produce an APK that cannot update the existing installation.
