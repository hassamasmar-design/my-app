export type TvProtocol = 'android_tv_v2' | 'google_tv_cast' | 'fire_tv_adb' | 'samsung_tizen' | 'lg_webos';

export interface TvDevice {
  id: string;
  name: string;
  type: 'fire_tv' | 'android_tv' | 'google_tv' | 'custom';
  ip: string;
  port: number;
  protocol: TvProtocol;
  isOnline: boolean;
  paired: boolean;
}

export type RemoteKey =
  | 'POWER'
  | 'MENU'
  | 'SETTINGS'
  | 'KEYBOARD'
  | 'MIC'
  | 'BACK'
  | 'HOME'
  | 'DPAD_UP'
  | 'DPAD_DOWN'
  | 'DPAD_LEFT'
  | 'DPAD_RIGHT'
  | 'DPAD_CENTER'
  | 'VOLUME_MUTE'
  | 'VOLUME_DOWN'
  | 'VOLUME_UP'
  | 'SEEK_BACKWARD'
  | 'SEEK_FORWARD'
  | 'PLAY_PAUSE'
  | 'REWIND_FAST'
  | 'FORWARD_FAST'
  | 'CHANNEL_DOWN'
  | 'CHANNEL_UP'
  | 'CHANNEL_LIST';

export type RemoteSkin = 'firetv' | 'samsung' | 'lg_magic' | 'apple_tv' | 'android_dpad';

export interface ButtonLayout {
  x: number;
  y: number;
  size: number;
  width?: number;
  height?: number;
}

export type ButtonLayouts = Record<string, ButtonLayout>;

export interface InterfaceColors {
  buttons: string;
  buttonIcons: string;
  border: string;
  touchArea: string;
  interface: string;
}

export interface RemoteSettings {
  language: 'ar' | 'en';
  hapticFeedback: boolean;
  soundFeedback: boolean;
  mouseSpeed: number; // pointer multiplier: 0.25x to 5x
  mouseInvertY: boolean;
  tvIp: string;
  autoConnect: boolean;
  theme: 'dark' | 'light';
  remoteLayout: RemoteSkin;
  interfaceColors: InterfaceColors;
}

export interface TvStatus {
  power: boolean;
  volume: number;
  muted: boolean;
  isPlaying: boolean;
  playbackPosition: number; // in seconds
  playbackDuration: number; // in seconds
  currentChannel: number;
  channelName: string;
  currentApp: string;
  currentMediaTitle: string;
  selectedNavIndex: number;
  lastCommand: string | null;
  lastCommandTimestamp: number;
}
