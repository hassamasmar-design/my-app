import React, { useEffect, useRef, useState } from 'react';

interface FluidVolumeBarProps {
  volume: number;
  color: string;
}

const clamp = (value: number, min: number, max: number) => Math.max(min, Math.min(max, value));

/**
 * Port of the supplied fluid-volume project: two independent liquid waves,
 * spring-damped tilt and a moving meniscus line. It is intentionally kept
 * inside the volume control so the TV volume remains the source of the fill.
 */
export const FluidVolumeBar: React.FC<FluidVolumeBarProps> = ({ volume, color }) => {
  const [, setFrame] = useState(0);
  const tiltRef = useRef(0);
  const targetTiltRef = useRef(0);
  const angleRef = useRef(0);
  const velocityRef = useRef(0);
  const phaseRef = useRef(0);
  const lastTimeRef = useRef(0);
  const nativeTiltSeenRef = useRef(false);
  const sensorBaselineRef = useRef<number | null>(null);
  const fraction = clamp(volume / 15, 0, 1);

  useEffect(() => {
    const setSensorTilt = (rawDegrees: number) => {
      if (!Number.isFinite(rawDegrees)) return;
      if (sensorBaselineRef.current === null) sensorBaselineRef.current = rawDegrees;
      // Calibrate the phone's resting position and ignore tiny sensor noise.
      let delta = rawDegrees - sensorBaselineRef.current;
      if (Math.abs(delta) < 1.2) delta = 0;
      // The bar follows the handset, but with a calmer, less aggressive response.
      targetTiltRef.current = clamp((delta * 0.55 * Math.PI) / 180, -0.22, 0.22);
    };
    const onOrientation = (event: DeviceOrientationEvent) => {
      if (nativeTiltSeenRef.current) return;
      const gamma = Number.isFinite(event.gamma) ? (event.gamma || 0) : 0;
      setSensorTilt(gamma);
    };
    const onNativeTilt = (event: Event) => {
      try {
        const detail = JSON.parse((event as CustomEvent).detail || '{}');
        if (Number.isFinite(detail.roll)) {
          nativeTiltSeenRef.current = true;
          setSensorTilt(detail.roll);
        }
      } catch { /* ignore malformed sensor events */ }
    };
    const requestSensorAccess = async () => {
      const orientation = DeviceOrientationEvent as typeof DeviceOrientationEvent & { requestPermission?: () => Promise<string> };
      if (typeof orientation.requestPermission === 'function') {
        try { await orientation.requestPermission(); } catch { /* permission remains optional */ }
      }
    };
    window.addEventListener('deviceorientation', onOrientation);
    window.addEventListener('nativeTiltStatus', onNativeTilt);
    window.addEventListener('pointerdown', requestSensorAccess, { once: true, passive: true });
    let raf = 0;
    const animate = (now: number) => {
      if (!lastTimeRef.current) lastTimeRef.current = now;
      const dt = clamp((now - lastTimeRef.current) / 1000, 0.005, 0.04);
      lastTimeRef.current = now;
      phaseRef.current += dt * 3.4;
      // Smooth noisy phone-sensor readings before applying the liquid physics.
      tiltRef.current += (targetTiltRef.current - tiltRef.current) * Math.min(1, dt * 3.8);
      // A damped spring keeps the liquid aligned without violent overshoot.
      const displacement = tiltRef.current - angleRef.current;
      const acceleration = 20 * displacement - 14 * velocityRef.current;
      velocityRef.current += acceleration * dt;
      angleRef.current += velocityRef.current * dt;
      setFrame(value => value + 1);
      raf = window.requestAnimationFrame(animate);
    };
    raf = window.requestAnimationFrame(animate);
    return () => {
      window.removeEventListener('deviceorientation', onOrientation);
      window.removeEventListener('nativeTiltStatus', onNativeTilt);
      window.removeEventListener('pointerdown', requestSensorAccess);
      window.cancelAnimationFrame(raf);
    };
  }, []);

  const width = 100;
  const height = 190;
  const baseY = height * (1 - fraction);
  // A horizontal liquid surface in world space becomes this exact screen
  // slope when the handset is rolled; do not compress it with an arbitrary
  // scale factor.
  const slope = Math.tan(clamp(angleRef.current, -0.22, 0.22));
  const phase = phaseRef.current * 0.72;
  const makeWave = (amplitude: number, frequency: number, offset: number) => {
    const points: string[] = [];
    for (let x = 0; x <= width; x += 2) {
      const relX = x - width / 2;
      const tiltY = -slope * relX;
      const wave = Math.sin(x * frequency + phase * 1.15 + offset) * amplitude;
      const ripple = Math.cos(x * frequency * 1.7 - phase * 1.3 + offset) * amplitude * 0.32;
      points.push(`${x.toFixed(1)},${clamp(baseY + tiltY + wave + ripple, 0, height).toFixed(1)}`);
    }
    return `M 0 ${height} L ${points.join(' L ')} L ${width} ${height} Z`;
  };

  const calmVelocity = clamp(Math.abs(velocityRef.current), 0, 0.35);
  const backPath = makeWave(2.6 + calmVelocity * 0.8, (2 * Math.PI) / 90, 1.2);
  const frontPath = makeWave(3.8 + calmVelocity * 1.1, (2 * Math.PI) / width, 0);
  const meniscus = frontPath.replace(`M 0 ${height} L `, '').replace(` L ${width} ${height} Z`, '');

  return (
    <div className="fluid-volume-bar pointer-events-none absolute inset-0 z-0 overflow-hidden rounded-[32px]" aria-hidden="true">
      <svg className="absolute inset-0 h-full w-full overflow-visible" viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none">
        <path d={backPath} fill={color} opacity=".52" />
        <path d={frontPath} fill={color} opacity=".96" />
        <path d={meniscus} fill="none" stroke="white" strokeWidth="1.8" opacity=".72" vectorEffect="non-scaling-stroke" />
      </svg>
      <span className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-black/10 to-transparent" />
    </div>
  );
};
