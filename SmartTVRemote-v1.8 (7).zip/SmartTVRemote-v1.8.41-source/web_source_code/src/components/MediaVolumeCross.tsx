import React, { useRef, useState, useEffect, useCallback } from 'react';
import { RemoteKey } from '../types';
import { playRemoteClick, triggerHaptic } from '../utils/sound';

interface MediaVolumeCrossProps {
  onCommand: (key: RemoteKey) => void;
}

export const MediaVolumeCross: React.FC<MediaVolumeCrossProps> = ({ onCommand }) => {
  // Joystick knob position { x, y } in px
  const [knobPos, setKnobPos] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [activeDirection, setActiveDirection] = useState<'up' | 'down' | 'left' | 'right' | null>(null);

  // Maximum travel radius along the cross arms (in px)
  const MAX_DISTANCE = 42;
  // Threshold to trigger an action
  const TRIGGER_THRESHOLD = 24;

  const dragStartRef = useRef<{ clientX: number; clientY: number }>({ clientX: 0, clientY: 0 });
  const isDraggingRef = useRef(false);
  const lastTriggeredDirRef = useRef<'up' | 'down' | 'left' | 'right' | null>(null);
  const repeatIntervalRef = useRef<NodeJS.Timeout | null>(null);

  const fireCommand = useCallback(
    (key: RemoteKey, soundType: 'button' | 'seek' = 'button') => {
      playRemoteClick(soundType);
      triggerHaptic(18);
      onCommand(key);
    },
    [onCommand]
  );

  const triggerDirectionAction = useCallback(
    (dir: 'up' | 'down' | 'left' | 'right') => {
      switch (dir) {
        case 'up':
          fireCommand('VOLUME_UP', 'button');
          break;
        case 'down':
          fireCommand('VOLUME_DOWN', 'button');
          break;
        case 'left':
          fireCommand('SEEK_BACKWARD', 'seek');
          break;
        case 'right':
          fireCommand('SEEK_FORWARD', 'seek');
          break;
      }
    },
    [fireCommand]
  );

  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.currentTarget.setPointerCapture?.(e.pointerId);
    isDraggingRef.current = true;
    setIsDragging(true);
    dragStartRef.current = { clientX: e.clientX, clientY: e.clientY };
    lastTriggeredDirRef.current = null;
    playRemoteClick('tap');
    triggerHaptic(12);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isDraggingRef.current) return;
    const rawDx = e.clientX - dragStartRef.current.clientX;
    const rawDy = e.clientY - dragStartRef.current.clientY;

    let constrainedX = 0;
    let constrainedY = 0;
    let currentDir: 'up' | 'down' | 'left' | 'right' | null = null;

    // Constrain motion strictly to 4 orthogonal directions (horizontal OR vertical, never diagonal)
    if (Math.abs(rawDx) >= Math.abs(rawDy)) {
      // Horizontal motion only (Left / Right)
      const clampedX = Math.max(-MAX_DISTANCE, Math.min(MAX_DISTANCE, rawDx));
      constrainedX = clampedX;
      constrainedY = 0;
      if (clampedX >= TRIGGER_THRESHOLD) {
        currentDir = 'right';
      } else if (clampedX <= -TRIGGER_THRESHOLD) {
        currentDir = 'left';
      }
    } else {
      // Vertical motion only (Up / Down)
      const clampedY = Math.max(-MAX_DISTANCE, Math.min(MAX_DISTANCE, rawDy));
      constrainedX = 0;
      constrainedY = clampedY;
      if (clampedY <= -TRIGGER_THRESHOLD) {
        currentDir = 'up';
      } else if (clampedY >= TRIGGER_THRESHOLD) {
        currentDir = 'down';
      }
    }

    setKnobPos({ x: constrainedX, y: constrainedY });
    setActiveDirection(currentDir);

    // Trigger once when the finger reaches a direction, then keep repeating
    // while the finger remains held there—even if it stops moving.
    if (currentDir && currentDir !== lastTriggeredDirRef.current) {
      lastTriggeredDirRef.current = currentDir;
      triggerDirectionAction(currentDir);

      // Setup continuous repeat if held in that direction
      if (repeatIntervalRef.current) clearInterval(repeatIntervalRef.current);
      repeatIntervalRef.current = setInterval(() => {
        if (lastTriggeredDirRef.current) {
          triggerDirectionAction(lastTriggeredDirRef.current);
        }
      }, 130);
    } else if (!currentDir) {
      lastTriggeredDirRef.current = null;
      if (repeatIntervalRef.current) {
        clearInterval(repeatIntervalRef.current);
        repeatIntervalRef.current = null;
      }
    }
  };

  const handlePointerUpOrCancel = (e: React.PointerEvent<HTMLDivElement>) => {
    try {
      e.currentTarget.releasePointerCapture?.(e.pointerId);
    } catch {
      // Ignore if pointer capture release is not supported
    }

    // Check if it was a simple tap without dragging (Play/Pause)
    const distanceMoved = Math.hypot(knobPos.x, knobPos.y);
    if (!lastTriggeredDirRef.current && distanceMoved < 8) {
      fireCommand('PLAY_PAUSE', 'button');
    }

    // Reset joystick back to center with smooth return
    isDraggingRef.current = false;
    setIsDragging(false);
    setKnobPos({ x: 0, y: 0 });
    setActiveDirection(null);
    lastTriggeredDirRef.current = null;

    if (repeatIntervalRef.current) {
      clearInterval(repeatIntervalRef.current);
      repeatIntervalRef.current = null;
    }
  };

  // Click on the cross arms directly
  const handleArmClick = (dir: 'up' | 'down' | 'left' | 'right') => {
    triggerDirectionAction(dir);
  };

  useEffect(() => {
    return () => {
      if (repeatIntervalRef.current) {
        clearInterval(repeatIntervalRef.current);
      }
    };
  }, []);

  /*
    Single unified cross path rendered with SVG:
    Cross size: 190x190
    Center at (95, 95)
    Arm width: 56px, Arm end radius: 28px
    Length of each arm from center: 95px (reaches edges at 0, 190)
    This creates a single continuous, seamless, smooth unified body
    without any overlapping layers or lines between horizontal and vertical arms.
  */
  return (
    <div className="w-full flex items-center justify-center pt-0 pb-2 select-none z-20">
      <div className="relative w-[190px] h-[190px] flex items-center justify-center select-none">
        {/* Soft Ambient Depth Glow */}
        <div className="absolute inset-0 bg-white/[0.02] rounded-full blur-xl pointer-events-none" />

        {/* 
          SINGLE SEAMLESS UNIFIED CROSS BODY (مسار موحد واحد بدون تراكب أو خطوط فاصلة)
        */}
        <svg
          viewBox="0 0 190 190"
          className="absolute inset-0 w-full h-full pointer-events-none drop-shadow-[0_8px_20px_rgba(0,0,0,0.6)]"
        >
          <defs>
            {/* Smooth subtle dark gradient */}
            <linearGradient id="crossBodyGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#2c303a" />
              <stop offset="50%" stopColor="#20232b" />
              <stop offset="100%" stopColor="#191c23" />
            </linearGradient>

            {/* Glowing subtle edge border */}
            <linearGradient id="crossBorderGrad" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="rgba(255,255,255,0.35)" />
              <stop offset="50%" stopColor="rgba(255,255,255,0.12)" />
              <stop offset="100%" stopColor="rgba(255,255,255,0.22)" />
            </linearGradient>
          </defs>

          {/* Unified Cross Outline Path with rounded rounded arm caps & smooth fillets */}
          <path
            d="
              M 67,28 
              A 28,28 0 0,1 123,28 
              L 123,67 
              L 162,67 
              A 28,28 0 0,1 162,123 
              L 123,123 
              L 123,162 
              A 28,28 0 0,1 67,162 
              L 67,123 
              L 28,123 
              A 28,28 0 0,1 28,67 
              L 67,67 
              Z
            "
            fill="url(#crossBodyGrad)"
            stroke="url(#crossBorderGrad)"
            strokeWidth="1.5"
            strokeLinejoin="round"
          />

          {/* Dynamic soft directional glow highlights inside active arm */}
          {activeDirection === 'up' && (
            <path
              d="M 68,29 A 27,27 0 0,1 122,29 L 122,70 L 68,70 Z"
              fill="rgba(255,255,255,0.12)"
            />
          )}
          {activeDirection === 'down' && (
            <path
              d="M 68,120 L 122,120 L 122,161 A 27,27 0 0,1 68,161 Z"
              fill="rgba(255,255,255,0.12)"
            />
          )}
          {activeDirection === 'left' && (
            <path
              d="M 29,68 L 70,68 L 70,122 L 29,122 A 27,27 0 0,1 29,68 Z"
              fill="rgba(255,255,255,0.12)"
            />
          )}
          {activeDirection === 'right' && (
            <path
              d="M 120,68 L 161,68 A 27,27 0 0,1 161,122 L 120,122 Z"
              fill="rgba(255,255,255,0.12)"
            />
          )}
        </svg>

        {/* Clickable Arm Target Areas */}
        <button
          onClick={() => handleArmClick('up')}
          title="رفع مستوى الصوت"
          className="absolute top-1 left-1/2 -translate-x-1/2 w-14 h-16 rounded-t-full z-10 cursor-pointer opacity-0"
        />
        <button
          onClick={() => handleArmClick('down')}
          title="خفض مستوى الصوت"
          className="absolute bottom-1 left-1/2 -translate-x-1/2 w-14 h-16 rounded-b-full z-10 cursor-pointer opacity-0"
        />
        <button
          onClick={() => handleArmClick('left')}
          title="ترجيع الفيديو"
          className="absolute left-1 top-1/2 -translate-y-1/2 w-16 h-14 rounded-l-full z-10 cursor-pointer opacity-0"
        />
        <button
          onClick={() => handleArmClick('right')}
          title="تقديم الفيديو"
          className="absolute right-1 top-1/2 -translate-y-1/2 w-16 h-14 rounded-r-full z-10 cursor-pointer opacity-0"
        />

        {/* 
          INTERACTIVE CENTER JOYSTICK KNOB WITH ONLY THE ORANGE (+) GLYPH
          - Pure, clean, minimalist
          - Moves strictly in 4 directions: Up, Down, Left, Right
          - Springs back into center on release
        */}
        <div
          id="cross-joystick-knob"
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUpOrCancel}
          onPointerCancel={handlePointerUpOrCancel}
          style={{
            transform: `translate3d(${knobPos.x}px, ${knobPos.y}px, 0)`,
            transition: isDragging ? 'none' : 'transform 0.25s cubic-bezier(0.18, 0.89, 0.32, 1.28)',
            touchAction: 'none',
          }}
          className="relative z-30 w-14 h-14 rounded-full bg-gradient-to-b from-[#3a3f4c] via-[#272a33] to-[#181b22] border-2 border-white/25 shadow-[0_6px_20px_rgba(0,0,0,0.85)] cursor-grab active:cursor-grabbing flex items-center justify-center select-none"
        >
          {/* Metallic Inner Highlight */}
          <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-transparent via-white/5 to-white/20 pointer-events-none" />

          {/* Warm Orange Ambient Glow */}
          <div
            className={`absolute inset-2 rounded-full blur-sm pointer-events-none transition-all duration-150 ${
              isDragging || activeDirection ? 'bg-[#ff4a1c]/50 scale-110' : 'bg-[#ff4a1c]/25'
            }`}
          />

          {/* Glowing Plus (+) Glyph Alone - Exactly as Requested */}
          <span
            className={`relative text-[28px] font-light leading-none text-[#ff4a1c] drop-shadow-[0_0_10px_rgba(255,74,28,0.95)] select-none transition-transform duration-150 pointer-events-none ${
              isDragging ? 'scale-110' : ''
            }`}
          >
            +
          </span>
        </div>
      </div>
    </div>
  );
};
