import React, { useRef, useState } from 'react';
import { Lock, Sliders, Mic, Volume2, VolumeX, Undo2, Home, Maximize2 } from 'lucide-react';
import { ButtonLayouts, RemoteKey } from '../types';
import { playRemoteClick, triggerHaptic } from '../utils/sound';
import { Language, translations } from '../utils/i18n';

interface Props {
  onCommand: (key: RemoteKey, longPress?: boolean) => void;
  isListening?: boolean;
  isTvPowerOn?: boolean;
  isMuted?: boolean;
  language?: Language;
  onVoiceQuery?: (query: string) => void;
  editMode?: boolean;
  layouts?: ButtonLayouts;
  onLayoutsChange?: (layouts: ButtonLayouts) => void;
  selectedId?: string | null;
  onSelect?: (id: string) => void;
}

// Original remote layout: six 56px buttons around the touch surface.
const defaults: ButtonLayouts = {
  power: { x: 8.8, y: 0, size: 100, width: 100, height: 100 },
  settings: { x: 74.1, y: 0, size: 100, width: 100, height: 100 },
  keyboard: { x: 0.5, y: 13.4, size: 100, width: 100, height: 100 },
  mic: { x: 50, y: 82, size: 100, width: 100, height: 100 },
  volume: { x: 0.5, y: 13.4, size: 100, width: 100, height: 100 },
  home: { x: 83.3, y: 13.6, size: 100, width: 100, height: 100 },
  back: { x: 81.4, y: 76.6, size: 100, width: 100, height: 100 },
};
const icons = { power: Lock, settings: Sliders, mic: Mic, home: Home, back: Undo2 };
const commands: Record<string, RemoteKey> = { power: 'POWER', settings: 'SETTINGS', home: 'HOME', back: 'BACK', volume: 'VOLUME_MUTE' };

export const SurroundingButtons: React.FC<Props> = ({ onCommand, isListening = false, isTvPowerOn = true, isMuted = false, language = 'ar', editMode = false, layouts = {}, onLayoutsChange, selectedId = null, onSelect }) => {
  const t = translations[language];
  const [drag, setDrag] = useState<{ id: string; pointer: number; resize: boolean } | null>(null);
  const dragRef = useRef<{ id: string; pointer: number; resize: boolean } | null>(null);
  const moved = useRef(false);
  const start = useRef<{ x: number; y: number; layout: ButtonLayouts[string] } | null>(null);
  const getLayout = (id: string) => {
    const value = layouts[id] || defaults[id];
    return { ...value, width: value.width ?? value.size, height: value.height ?? value.size };
  };

  const updatePointer = (clientX: number, clientY: number, id: string, resize: boolean) => {
    if (!editMode || !start.current) return;
    // Use the original 360x470 button container, not the full remote surface.
    // This keeps vertical dragging accurate for the top lock/settings buttons.
    const parent = (document.querySelector('[data-customizer-area]')?.querySelector('.surrounding-buttons-surface') || document.querySelector('[data-customizer-surface]')) as HTMLElement | null;
    const rect = parent?.getBoundingClientRect();
    if (!rect) return;
    const dx = clientX - start.current.x;
    const dy = clientY - start.current.y;
    if (Math.abs(dx) > 4 || Math.abs(dy) > 4) moved.current = true;
    const old = start.current.layout;
    const widthPx = 56 * (old.width ?? old.size) / 100;
    const heightPx = 56 * (old.height ?? old.size) / 100;
    const next = resize
      ? { ...old, width: Math.max(60, Math.min(220, Math.round((old.width ?? old.size) + dx / 56 * 100))), height: Math.max(60, Math.min(220, Math.round((old.height ?? old.size) + dy / 56 * 100))), size: Math.round(((old.width ?? old.size) + (old.height ?? old.size)) / 2) }
      : { ...old, x: Math.max(-100, Math.min(160, old.x + dx / rect.width * 100)), y: Math.max(-100, Math.min(160, old.y + dy / rect.height * 100)) };
    onLayoutsChange?.({ [id]: next });
  };

  const globalMove = (event: PointerEvent) => { event.preventDefault(); const current = dragRef.current; if (current) updatePointer(event.clientX, event.clientY, current.id, current.resize); };
  const globalEnd = () => { window.removeEventListener('pointermove', globalMove); window.removeEventListener('pointerup', globalEnd); window.removeEventListener('pointercancel', globalEnd); dragRef.current = null; setDrag(null); start.current = null; };
  const beginEdit = (event: React.PointerEvent, id: string, resize = false) => {
    if (!editMode) return;
    event.preventDefault(); event.stopPropagation();
    const layout = getLayout(id);
    start.current = { x: event.clientX, y: event.clientY, layout };
    moved.current = false;
    onSelect?.(id);
    const currentDrag = { id, pointer: event.pointerId, resize };
    dragRef.current = currentDrag;
    setDrag(currentDrag);
    window.addEventListener('pointermove', globalMove, { passive: false });
    window.addEventListener('pointerup', globalEnd, { once: true });
    window.addEventListener('pointercancel', globalEnd, { once: true });
  };
  const endEdit = (_event: React.PointerEvent) => {
    if (!drag) return;
    globalEnd();
  };
  const click = (id: string) => { if (!editMode && !moved.current && commands[id]) { playRemoteClick(id === 'home' ? 'home' : id === 'power' ? 'power' : 'button'); triggerHaptic(18); onCommand(commands[id]); } moved.current = false; };

  const renderButton = (id: string, title: string, command?: RemoteKey) => {
    const Icon = icons[id as keyof typeof icons]; const layout = getLayout(id);
    const widthPx = 56 * (layout.width ?? layout.size) / 100;
    const heightPx = 56 * (layout.height ?? layout.size) / 100;
    const iconPx = Math.min(widthPx, heightPx) * .43;
    const extraTransform = id === 'mic' || id === 'volume' ? 'translate(-50px, 75px)' : undefined;
    return <div key={id} className="absolute z-30 pointer-events-auto touch-none" style={{ left: `${layout.x}%`, top: `${layout.y}%`, width: widthPx, height: heightPx, transform: extraTransform }} onPointerDown={(e) => beginEdit(e, id)} onPointerUp={endEdit} onPointerCancel={endEdit}>
      <button type="button" id={`btn-${id}`} onClick={() => click(id)} title={title} className={`remote-button w-full h-full rounded-full ${id === 'home' ? 'bg-[#ff421a] hover:bg-[#ff5530]' : 'bg-[#4f5456]/85 hover:bg-[#414648]'} active:scale-95 text-white flex items-center justify-center transition-all duration-150 shadow-md border border-white/20 cursor-pointer ${editMode && selectedId === id ? 'ring-2 ring-[#ff421a] cursor-move' : ''}`}>
        <Icon style={{ width: iconPx, height: iconPx }} className="stroke-[2.2]" />
      </button>
      {editMode && selectedId === id && <><span className="absolute -top-7 left-1/2 -translate-x-1/2 rounded-md bg-black/90 px-1.5 py-0.5 text-[10px] font-bold text-white whitespace-nowrap">{Math.round(layout.width ?? layout.size)}% × {Math.round(layout.height ?? layout.size)}%</span><button type="button" aria-label={language === 'ar' ? 'تغيير الحجم' : 'Resize'} onPointerDown={(e) => beginEdit(e, id, true)} onPointerUp={endEdit} onPointerCancel={endEdit} className="absolute -bottom-2 -right-2 w-7 h-7 rounded-full bg-[#ff421a] border-2 border-white flex items-center justify-center z-50"><Maximize2 className="w-4 h-4 text-white" /></button></>}
    </div>;
  };

  return <div data-tour="buttons" className="surrounding-buttons-surface absolute left-1/2 top-1/2 h-[470px] w-full max-w-[360px] pointer-events-none select-none z-30 overflow-visible" style={{ transform: 'translate(-50%, calc(-50% + 55px))' }}>
    {renderButton('power', isTvPowerOn ? t.powerTitleOff : t.powerTitleOn)}
    {renderButton('settings', t.settingsTitle)}
    <div className="absolute z-30 pointer-events-auto touch-none" style={{ left: `${getLayout('mic').x}%`, top: `${getLayout('mic').y}%`, width: 56 * (getLayout('mic').width ?? getLayout('mic').size) / 100, height: 56 * (getLayout('mic').height ?? getLayout('mic').size) / 100, transform: 'translate(-69px, 54px)' }} onPointerDown={(e) => editMode ? beginEdit(e, 'mic') : (window as any).AndroidBridge?.startVoice?.()} onPointerUp={(e) => { if (editMode) endEdit(e); else (window as any).AndroidBridge?.stopVoice?.(); }} onPointerCancel={(e) => editMode ? endEdit(e) : (window as any).AndroidBridge?.stopVoice?.()}>
      <button type="button" id="btn-mic" title={t.micTitle} className={`remote-button w-full h-full rounded-full bg-[#4f5456]/85 text-white flex items-center justify-center border border-white/20 ${editMode && selectedId === 'mic' ? 'ring-2 ring-[#ff421a] cursor-move' : ''}`}><Mic style={{ width: Math.min(56 * (getLayout('mic').width ?? getLayout('mic').size) / 100, 56 * (getLayout('mic').height ?? getLayout('mic').size) / 100) * .43, height: Math.min(56 * (getLayout('mic').width ?? getLayout('mic').size) / 100, 56 * (getLayout('mic').height ?? getLayout('mic').size) / 100) * .43 }} /></button>
      {editMode && selectedId === 'mic' && <><span className="absolute -top-7 left-1/2 -translate-x-1/2 rounded-md bg-black/90 px-1.5 py-0.5 text-[10px] font-bold text-white whitespace-nowrap">{Math.round(getLayout('mic').width ?? getLayout('mic').size)}% × {Math.round(getLayout('mic').height ?? getLayout('mic').size)}%</span><button type="button" onPointerDown={(e) => beginEdit(e, 'mic', true)} onPointerUp={endEdit} onPointerCancel={endEdit} className="absolute -bottom-2 -right-2 w-7 h-7 rounded-full bg-[#ff421a] border-2 border-white flex items-center justify-center z-50"><Maximize2 className="w-4 h-4 text-white" /></button></>}
    </div>
    {renderButton('home', t.homeTitle)}
    {renderButton('back', t.backTitle)}
    {(() => { const layout = getLayout('volume'); const widthPx = 56 * (layout.width ?? layout.size) / 100; const heightPx = 56 * (layout.height ?? layout.size) / 100; const iconPx = Math.min(widthPx, heightPx) * .43; return <div className="absolute z-30 pointer-events-auto touch-none" style={{ left: `${layout.x}%`, top: `${layout.y}%`, width: widthPx, height: heightPx, }} onPointerDown={(e) => beginEdit(e, 'volume')} onPointerUp={endEdit} onPointerCancel={endEdit}>
      <button type="button" id="btn-volume" title={language === 'ar' ? (isMuted ? 'إلغاء كتم الصوت' : 'كتم الصوت') : (isMuted ? 'Unmute' : 'Mute')} onClick={() => click('volume')} className={`remote-button w-full h-full rounded-full ${isMuted ? 'bg-rose-500 hover:bg-rose-400' : 'bg-[#4f5456]/85 hover:bg-[#414648]'} text-white flex items-center justify-center border border-white/20 ${editMode && selectedId === 'volume' ? 'ring-2 ring-[#ff421a] cursor-move' : ''}`}>
        {isMuted ? <VolumeX style={{ width: iconPx, height: iconPx }} className="stroke-[2.2]" /> : <Volume2 style={{ width: iconPx, height: iconPx }} className="stroke-[2.2]" />}
      </button>
      {editMode && selectedId === 'volume' && <><span className="absolute -top-7 left-1/2 -translate-x-1/2 rounded-md bg-black/90 px-1.5 py-0.5 text-[10px] font-bold text-white whitespace-nowrap">{Math.round(layout.width ?? layout.size)}% × {Math.round(layout.height ?? layout.size)}%</span><button type="button" aria-label={language === 'ar' ? 'تغيير الحجم' : 'Resize'} onPointerDown={(e) => beginEdit(e, 'volume', true)} onPointerUp={endEdit} onPointerCancel={endEdit} className="absolute -bottom-2 -right-2 w-7 h-7 rounded-full bg-[#ff421a] border-2 border-white flex items-center justify-center z-50"><Maximize2 className="w-4 h-4 text-white" /></button></>}
    </div>; })()}
  </div>;
};
