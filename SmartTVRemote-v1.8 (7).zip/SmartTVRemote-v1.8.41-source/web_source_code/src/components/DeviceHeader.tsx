import React, { useState } from 'react';
import { Tv, Check, Plus, ChevronDown } from 'lucide-react';
import { TvDevice } from '../types';
import { playRemoteClick } from '../utils/sound';

interface DeviceHeaderProps {
  currentDevice: TvDevice;
  devices: TvDevice[];
  onSelectDevice: (device: TvDevice) => void;
  onOpenSettings: () => void;
  onOpenAddDevice: () => void;
  isTvPowerOn?: boolean;
  onTogglePower?: () => void;
}

export const DeviceHeader: React.FC<DeviceHeaderProps> = ({
  currentDevice,
  devices,
  onSelectDevice,
  onOpenAddDevice,
}) => {
  const [dropdownOpen, setDropdownOpen] = useState(false);

  return (
    <header className="relative w-full px-5 pt-3 pb-2 flex items-center justify-center z-30 select-none">
      {/* Device Picker (Center) */}
      <div className="relative">
        <button
          id="device-selector-button"
          onClick={() => {
            playRemoteClick('button');
            setDropdownOpen((prev) => !prev);
          }}
          className="flex items-center gap-2 px-3 py-1.5 rounded-full hover:bg-white/5 active:bg-white/10 transition-colors group cursor-pointer"
        >
          {/* Blue TV Icon from the image */}
          <div className="relative">
            <Tv className="w-5 h-5 text-[#2997ff] fill-[#2997ff]/20 stroke-[2.2]" />
            <span
              className={`absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full ${
                currentDevice.isOnline ? 'bg-emerald-400 ring-2 ring-[#121316]' : 'bg-amber-400'
              }`}
            />
          </div>

          <span className="text-[15px] font-semibold text-[#2997ff] tracking-tight group-hover:text-[#47a5ff] transition-colors">
            {currentDevice.name}
          </span>
          <ChevronDown className={`w-3.5 h-3.5 text-[#2997ff]/70 transition-transform duration-200 ${dropdownOpen ? 'rotate-180' : ''}`} />
        </button>

        {/* Dropdown Menu */}
        {dropdownOpen && (
          <>
            <div
              className="fixed inset-0 z-40"
              onClick={() => setDropdownOpen(false)}
            />
            <div className="absolute left-1/2 -translate-x-1/2 top-full mt-2 w-72 bg-[#1c1f24] border border-white/10 rounded-2xl shadow-2xl z-50 py-2 overflow-hidden backdrop-blur-xl animate-in fade-in zoom-in-95 duration-150">
              <div className="px-3.5 py-1.5 text-[11px] font-semibold uppercase tracking-wider text-white/40 border-b border-white/5 flex items-center justify-between">
                <span>Select Target TV</span>
                <span className="text-[10px] text-emerald-400 font-mono">LAN Ready</span>
              </div>

              <div className="py-1 max-h-60 overflow-y-auto">
                {devices.map((device) => {
                  const isSelected = device.id === currentDevice.id;
                  return (
                    <button
                      key={device.id}
                      onClick={() => {
                        playRemoteClick('button');
                        onSelectDevice(device);
                        setDropdownOpen(false);
                      }}
                      className={`w-full px-3.5 py-2.5 flex items-center justify-between text-left transition-colors ${
                        isSelected ? 'bg-[#2997ff]/15 text-[#2997ff]' : 'text-white/80 hover:bg-white/5'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <Tv className={`w-4 h-4 ${isSelected ? 'text-[#2997ff]' : 'text-white/40'}`} />
                        <div>
                          <div className="text-sm font-medium leading-tight">{device.name}</div>
                          <div className="text-[11px] text-white/40 font-mono">
                            {device.ip}:{device.port} • {device.protocol === 'android_tv_v2' ? 'Android TV v2' : device.protocol === 'google_tv_cast' ? 'Google TV' : 'Fire TV'}
                          </div>
                        </div>
                      </div>
                      {isSelected && <Check className="w-4 h-4 text-[#2997ff]" />}
                    </button>
                  );
                })}
              </div>

              <div className="pt-1.5 border-t border-white/5 px-2">
                <button
                  onClick={() => {
                    setDropdownOpen(false);
                    onOpenAddDevice();
                  }}
                  className="w-full py-2 px-3 flex items-center justify-center gap-1.5 text-xs font-medium text-white/90 bg-white/5 hover:bg-white/10 rounded-xl transition-colors"
                >
                  <Plus className="w-3.5 h-3.5 text-[#2997ff]" />
                  <span>Pair New Android TV / Google TV</span>
                </button>
              </div>
            </div>
          </>
        )}
      </div>
    </header>
  );
};
