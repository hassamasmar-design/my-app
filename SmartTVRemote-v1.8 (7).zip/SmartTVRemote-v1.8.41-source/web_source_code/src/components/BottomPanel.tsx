import React, { useState, useRef } from 'react';
import { VolumeX, Volume2, Minus, Plus, ChevronUp, ChevronDown, List } from 'lucide-react';
import { RemoteKey } from '../types';
import { playRemoteClick, triggerHaptic } from '../utils/sound';

interface BottomPanelProps {
  onCommand: (key: RemoteKey) => void;
  isMuted?: boolean;
  volumeLevel?: number;
}

export const BottomPanel: React.FC<BottomPanelProps> = ({
  onCommand,
  isMuted = false,
  volumeLevel = 28,
}) => {
  const [activeTab, setActiveTab] = useState<'volume' | 'channels'>('volume');
  const repeatTimerRef = useRef<NodeJS.Timeout | null>(null);

  const handleAction = (key: RemoteKey) => {
    playRemoteClick('button');
    triggerHaptic(15);
    onCommand(key);
  };

  // Support holding down volume buttons
  const startRepeat = (key: RemoteKey) => {
    handleAction(key);
    repeatTimerRef.current = setTimeout(() => {
      const interval = setInterval(() => {
        handleAction(key);
      }, 150);
      repeatTimerRef.current = interval as unknown as NodeJS.Timeout;
    }, 400);
  };

  const stopRepeat = () => {
    if (repeatTimerRef.current) {
      clearTimeout(repeatTimerRef.current);
      clearInterval(repeatTimerRef.current);
      repeatTimerRef.current = null;
    }
  };

  return (
    <div className="w-full px-4 pt-1 pb-4 select-none z-20">
      {/* Dual Dash Grip Handle Indicator from Image (=) */}
      <div className="flex flex-col items-center justify-center gap-[3px] py-1.5 mb-1 opacity-70">
        <div className="w-5 h-[2.5px] rounded-full bg-[#464a52]" />
        <div className="w-5 h-[2.5px] rounded-full bg-[#464a52]" />
      </div>

      {/* Main Bottom Container matching the exact image with organic tabs and pill buttons */}
      <div className="w-full bg-[#181a1e] rounded-[32px] p-2.5 border border-white/20 shadow-2xl relative overflow-hidden">
        {/* Tabs Bar: "Volume" | "Channels" - Organic curve tab design exactly from image */}
        <div className="relative flex items-center w-full mb-3 select-none">
          {/* Active indicator shape with smooth curved cutout */}
          <div
            className={`absolute top-0 bottom-0 rounded-2xl bg-[#23262b] transition-all duration-300 ease-out border border-white/20 shadow-sm ${
              activeTab === 'volume' ? 'left-0 w-[52%]' : 'left-[48%] w-[52%]'
            }`}
          />

          {/* Volume Tab */}
          <button
            id="tab-volume"
            onClick={() => {
              playRemoteClick('button');
              setActiveTab('volume');
            }}
            className={`relative z-10 flex-1 py-2 text-center text-[15px] transition-colors duration-150 cursor-pointer ${
              activeTab === 'volume'
                ? 'text-white font-semibold'
                : 'text-[#828894] hover:text-white/80 font-normal'
            }`}
          >
            الصوت
          </button>

          {/* Channels Tab */}
          <button
            id="tab-channels"
            onClick={() => {
              playRemoteClick('button');
              setActiveTab('channels');
            }}
            className={`relative z-10 flex-1 py-2 text-center text-[15px] transition-colors duration-150 cursor-pointer ${
              activeTab === 'channels'
                ? 'text-white font-semibold'
                : 'text-[#828894] hover:text-white/80 font-normal'
            }`}
          >
            القنوات
          </button>
        </div>

        {/* Tab 1: Volume Controls - 3 horizontal oblong pill buttons */}
        {activeTab === 'volume' ? (
          <div className="grid grid-cols-3 gap-2 px-1 pb-1">
            {/* Mute Button */}
            <button
              id="btn-volume-mute"
              onClick={() => handleAction('VOLUME_MUTE')}
              title={isMuted ? 'إلغاء كتم الصوت' : 'كتم الصوت'}
              className={`h-14 rounded-full flex items-center justify-center transition-all duration-150 active:scale-95 cursor-pointer ${
                isMuted
                  ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                  : 'bg-[#22252a] hover:bg-[#2b2e35] active:bg-[#1a1c20] text-[#d4d8df] hover:text-white border border-white/20'
              }`}
            >
              <VolumeX className="w-6 h-6 stroke-[2.2]" />
            </button>

            {/* Volume Down (-) Button */}
            <button
              id="btn-volume-down"
              onPointerDown={() => startRepeat('VOLUME_DOWN')}
              onPointerUp={stopRepeat}
              onPointerLeave={stopRepeat}
              title="خفض مستوى الصوت (-)"
              className="h-14 rounded-full bg-[#4f5456]/85 hover:bg-[#414648] active:scale-95 text-white flex items-center justify-center border border-white/20 transition-all duration-150 cursor-pointer"
            >
              <Minus className="w-7 h-7 stroke-[2.8]" />
            </button>

            {/* Volume Up (+) Button */}
            <button
              id="btn-volume-up"
              onPointerDown={() => startRepeat('VOLUME_UP')}
              onPointerUp={stopRepeat}
              onPointerLeave={stopRepeat}
              title="رفع مستوى الصوت (+)"
              className="h-14 rounded-full bg-[#4f5456]/85 hover:bg-[#414648] active:scale-95 text-white flex items-center justify-center border border-white/20 transition-all duration-150 cursor-pointer"
            >
              <Plus className="w-7 h-7 stroke-[2.8]" />
            </button>
          </div>
        ) : (
          /* Tab 2: Channels Controls */
          <div className="grid grid-cols-3 gap-2 px-1 pb-1">
            {/* Channel Down */}
            <button
              id="btn-channel-down"
              onClick={() => handleAction('CHANNEL_DOWN')}
              title="القناة السابقة (CH -)"
              className="h-14 rounded-full bg-[#4f5456]/85 hover:bg-[#414648] active:scale-95 text-white flex flex-col items-center justify-center border border-white/20 transition-all duration-150 cursor-pointer"
            >
              <ChevronDown className="w-6 h-6 stroke-[2.5]" />
              <span className="text-[9px] uppercase font-bold tracking-wider opacity-60">CH -</span>
            </button>

            {/* Channel List / Guide */}
            <button
              id="btn-channel-list"
              onClick={() => handleAction('CHANNEL_LIST')}
              title="دليل القنوات (Guide)"
              className="h-14 rounded-full bg-[#4f5456]/85 hover:bg-[#414648] active:scale-95 text-white flex flex-col items-center justify-center border border-white/20 transition-all duration-150 cursor-pointer"
            >
              <List className="w-5 h-5 stroke-[2.2]" />
              <span className="text-[9px] font-bold tracking-wider opacity-60">الدليل</span>
            </button>

            {/* Channel Up */}
            <button
              id="btn-channel-up"
              onClick={() => handleAction('CHANNEL_UP')}
              title="القناة التالية (CH +)"
              className="h-14 rounded-full bg-[#4f5456]/85 hover:bg-[#414648] active:scale-95 text-white flex flex-col items-center justify-center border border-white/20 transition-all duration-150 cursor-pointer"
            >
              <ChevronUp className="w-6 h-6 stroke-[2.5]" />
              <span className="text-[9px] uppercase font-bold tracking-wider opacity-60">CH +</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
