import React from 'react';
import { X, Tv, Volume2, VolumeX, Sparkles, Youtube, Film, Play } from 'lucide-react';
import { TvStatus } from '../types';
import { Language } from '../utils/i18n';

interface TvSimulatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  status: TvStatus;
  deviceName: string;
  language?: Language;
}

export const TvSimulatorModal: React.FC<TvSimulatorModalProps> = ({
  isOpen,
  onClose,
  status,
  deviceName,
  language = 'ar',
}) => {
  if (!isOpen) return null;

  const isAr = language === 'ar';

  const apps = [
    { name: 'YouTube', icon: Youtube, color: 'bg-red-600' },
    { name: 'Netflix', icon: Film, color: 'bg-red-700' },
    { name: 'Prime Video', icon: Play, color: 'bg-blue-600' },
    { name: 'Google TV', icon: Tv, color: 'bg-indigo-600' },
    { name: isAr ? 'الإعدادات' : 'Settings', icon: Sparkles, color: 'bg-zinc-700' },
  ];

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md animate-in fade-in duration-200"
      dir={isAr ? 'rtl' : 'ltr'}
    >
      <div className="relative w-full max-w-2xl bg-[#111317] border border-white/15 rounded-3xl overflow-hidden shadow-2xl flex flex-col text-white">
        {/* Modal Top Bar */}
        <div className="px-5 py-3.5 border-b border-white/10 flex items-center justify-between bg-[#16181d]">
          <div className="flex items-center gap-2">
            <Tv className="w-4 h-4 text-[#2997ff]" />
            <span className="text-xs font-semibold text-white/90">
              {isAr ? `شاشة محاكاة التلفزيون التفاعلية (${deviceName})` : `Interactive TV Simulator Screen (${deviceName})`}
            </span>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4 text-white/70" />
          </button>
        </div>

        {/* TV Screen Display */}
        <div className="p-4 sm:p-6 bg-[#0a0b0e] flex flex-col items-center">
          {/* Outer TV Bezel */}
          <div className="relative w-full aspect-video rounded-2xl bg-[#0e1014] border-4 border-[#24272e] shadow-2xl overflow-hidden flex flex-col justify-between p-5">
            {/* TV Screen Power Off State */}
            {!status.power ? (
              <div className="absolute inset-0 bg-black/95 flex flex-col items-center justify-center text-white/30 space-y-2 z-20">
                <div className="w-3 h-3 rounded-full bg-red-500 animate-ping" />
                <span className="text-xs font-mono">
                  {isAr ? 'وضع الاستعداد / التلفاز مغلق' : 'Standby Mode / TV is Off'}
                </span>
              </div>
            ) : (
              <>
                {/* TV Header Banner */}
                <div className="flex items-center justify-between z-10">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold tracking-wider text-[#2997ff]">
                      {deviceName}
                    </span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-white/10 text-white/70">
                      HDMI 1 • 4K HDR
                    </span>
                  </div>

                  {/* Volume Overlay if recently changed */}
                  <div className="flex items-center gap-2 bg-black/70 backdrop-blur-md px-3 py-1 rounded-full border border-white/10">
                    {status.muted ? (
                      <VolumeX className="w-3.5 h-3.5 text-rose-400" />
                    ) : (
                      <Volume2 className="w-3.5 h-3.5 text-[#2997ff]" />
                    )}
                    <span className="text-xs font-mono font-medium">
                      {status.muted ? (isAr ? 'مكتوم' : 'Muted') : `${status.volume}%`}
                    </span>
                    <div className="w-16 h-1.5 bg-white/20 rounded-full overflow-hidden">
                      <div
                        className={`h-full transition-all duration-150 ${status.muted ? 'bg-rose-500' : 'bg-[#2997ff]'}`}
                        style={{ width: `${status.muted ? 0 : status.volume}%` }}
                      />
                    </div>
                  </div>
                </div>

                {/* TV Apps Grid */}
                <div className="my-auto">
                  <div className="text-[11px] text-white/40 mb-2 font-medium">
                    {isAr
                      ? 'التطبيقات المثبتة (استخدم لوحة اللمس للتنقل والضغط للتحديد):'
                      : 'Installed Apps (Use touchpad to navigate & click to select):'}
                  </div>
                  <div className="grid grid-cols-5 gap-3">
                    {apps.map((app, index) => {
                      const isFocused = status.selectedNavIndex === index;
                      const Icon = app.icon;
                      return (
                        <div
                          key={app.name}
                          className={`aspect-video rounded-xl flex flex-col items-center justify-center gap-1.5 p-2 transition-all duration-200 ${
                            isFocused
                              ? 'ring-4 ring-[#2997ff] scale-105 bg-white/15 shadow-lg shadow-[#2997ff]/20'
                              : 'bg-white/5 opacity-70 hover:opacity-100'
                          }`}
                        >
                          <div className={`w-8 h-8 rounded-lg ${app.color} flex items-center justify-center shadow-md`}>
                            <Icon className="w-4 h-4 text-white" />
                          </div>
                          <span className="text-[11px] font-medium truncate max-w-full">
                            {app.name}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Video Playback Bar inside TV Simulator */}
                <div className="bg-black/60 backdrop-blur-md rounded-xl p-2.5 border border-white/10 my-1 flex flex-col gap-1.5">
                  <div className="flex items-center justify-between text-[11px]">
                    <div className="flex items-center gap-2 overflow-hidden flex-1 mr-2">
                      <span className={`w-2 h-2 rounded-full shrink-0 ${status.isPlaying ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
                      <div className="flex flex-col min-w-0">
                        <span className="font-semibold text-white/90 truncate">
                          {status.currentMediaTitle || (isAr ? 'تشغيل الفيديو (YouTube 4K)' : 'Video Playback (YouTube 4K)')}
                        </span>
                        <span className="text-[9px] text-red-400">YouTube</span>
                      </div>
                    </div>
                    <span className="font-mono text-xs text-[#2997ff]">
                      {Math.floor((status.playbackPosition || 0) / 60).toString().padStart(2, '0')}:
                      {Math.floor((status.playbackPosition || 0) % 60).toString().padStart(2, '0')} /{' '}
                      {Math.floor((status.playbackDuration || 600) / 60).toString().padStart(2, '0')}:
                      {Math.floor((status.playbackDuration || 600) % 60).toString().padStart(2, '0')}
                    </span>
                  </div>
                  <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-[#2997ff] to-[#ff4a1c] transition-all duration-300 rounded-full"
                      style={{ width: `${Math.min(100, Math.max(0, ((status.playbackPosition || 0) / (status.playbackDuration || 600)) * 100))}%` }}
                    />
                  </div>
                </div>

                {/* TV Bottom Footer with Last Command HUD */}
                <div className="flex items-center justify-between text-[11px] text-white/50 border-t border-white/10 pt-2">
                  <div className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-400" />
                    <span>{isAr ? 'النظام: جاهز ومتصل' : 'System: Ready & Connected'}</span>
                  </div>

                  {status.lastCommand && (
                    <div className="font-mono text-[#2997ff] bg-white/5 px-2.5 py-0.5 rounded-md border border-white/5">
                      {status.lastCommand}
                    </div>
                  )}
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
