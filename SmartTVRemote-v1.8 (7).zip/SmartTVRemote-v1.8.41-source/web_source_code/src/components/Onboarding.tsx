import React, { useState } from 'react';

interface OnboardingProps {
  onFinish: () => void;
}

const slides = [
  { image: 'onboarding/welcome-1.webp', text: 'أهلاً وسهلاً بكم في تطبيقنا ريموت سمارت' },
  { image: 'onboarding/welcome-2.webp', text: 'يسهّل عليك التحكم بكل شاشة في بيتك' },
  { image: 'onboarding/welcome-3.webp', text: 'يناسب احتياجك، سهل وبسيط ومناسب لكافة الأعمار' },
  { image: 'onboarding/welcome-4.webp', text: 'يمكنك تخصيص أزراره ونقلها حسب تفضيلك\nويمكنك تغيير ألوان الواجهة والأزرار كما تحب' },
  { image: 'onboarding/welcome-5.webp', text: 'نتمنى لكم تجربة مميزة' },
];

export const Onboarding: React.FC<OnboardingProps> = ({ onFinish }) => {
  const [index, setIndex] = useState(0);
  const isLast = index === slides.length - 1;


  const finish = () => {
    try {
      window.localStorage.setItem('smart-remote-onboarding-v2-complete', '1');
    } catch {
      // Continue even when storage is unavailable in the WebView.
    }
    onFinish();
  };

  const next = () => {
    if (isLast) {
      finish();
    } else {
      setIndex((current) => current + 1);
    }
  };

  return (
    <div className="onboarding-screen" dir="rtl">
      <img
        key={slides[index].image}
        className="onboarding-image"
        src={slides[index].image}
        alt=""
      />
      <div className="onboarding-shade" />
      <div className="onboarding-content">
        {slides[index].text && (
          <h1 key={slides[index].text} className="onboarding-title onboarding-typewriter">
            {slides[index].text.split('\n').map((line, lineIndex) => (
              <React.Fragment key={line}>
                {lineIndex > 0 && <br />}
                {line}
              </React.Fragment>
            ))}
          </h1>
        )}

        <div className="onboarding-dots" aria-label="صفحات الترحيب">
          {slides.map((_, dotIndex) => (
            <span key={dotIndex} className={`onboarding-dot ${dotIndex === index ? 'is-active' : ''}`} />
          ))}
        </div>

        <div className="onboarding-actions">
          <button type="button" className="onboarding-skip" onClick={finish}>
            تخطي
          </button>
          <button type="button" className="onboarding-next" onClick={next}>
            {isLast ? 'دخول إلى التطبيق' : 'استمرار'}
          </button>
        </div>

        {index > 0 && (
          <button type="button" className="onboarding-back" onClick={() => setIndex((current) => current - 1)}>
            رجوع
          </button>
        )}
      </div>
    </div>
  );
};
