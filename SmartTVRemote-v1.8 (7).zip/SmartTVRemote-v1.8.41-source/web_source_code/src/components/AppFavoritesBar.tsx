import React from 'react';

export type AppItem = { id: string; name: string; nameAr: string; color: string; packageId: string; deepLink: string; icon: string };
export const APPS: AppItem[] = [
  { id: 'youtube', name: 'YouTube', nameAr: 'YouTube', color: '#ff2020', packageId: 'com.google.android.youtube.tv', deepLink: 'vnd.youtube://', icon: 'app-icons/youtube.svg' },
  { id: 'netflix', name: 'Netflix', nameAr: 'Netflix', color: '#b20710', packageId: 'com.netflix.ninja', deepLink: 'https://www.netflix.com/title.*', icon: 'app-icons/netflix.svg' },
  { id: 'shahid', name: 'Shahid', nameAr: 'شاهد', color: '#151515', packageId: 'net.mbc.shahidTV', deepLink: 'https://shahid.mbc.net/', icon: 'app-icons/shahid.png' },
  { id: 'stc-tv', name: 'stc tv', nameAr: 'stc tv', color: '#4f008c', packageId: 'com.stctv.android', deepLink: 'https://www.stctv.com/', icon: 'app-icons/stc-tv.svg' },
  { id: 'prime-video', name: 'Prime Video', nameAr: 'Prime Video', color: '#00a8e1', packageId: 'com.amazon.amazonvideo.livingroom', deepLink: 'https://app.primevideo.com', icon: 'app-icons/prime-video.svg' },
  { id: 'osn', name: 'OSN+', nameAr: 'OSN+', color: '#0a102d', packageId: 'com.osn.go', deepLink: 'https://osnplus.com/', icon: 'app-icons/osn.svg' },
  { id: 'noor-play', name: 'Noor Play', nameAr: 'Noor Play', color: '#f3b21b', packageId: 'ps.goldendeveloper.alnoor', deepLink: 'https://www.noorplay.com/', icon: 'app-icons/noor-play.svg' },
  { id: 'adtv', name: 'ADtv', nameAr: 'ADtv', color: '#d71920', packageId: 'ae.admedia.adtv', deepLink: 'https://adtv.ae/', icon: 'app-icons/adtv.svg' },
  { id: 'crunchyroll', name: 'Crunchyroll', nameAr: 'Crunchyroll', color: '#f47521', packageId: 'com.crunchyroll.crunchyroid', deepLink: 'https://www.crunchyroll.com/', icon: 'app-icons/crunchyroll.svg' },
  { id: 'apple-tv', name: 'Apple TV', nameAr: 'Apple TV', color: '#222222', packageId: 'com.apple.atve.androidtv.appletv', deepLink: 'https://tv.apple.com/', icon: 'app-icons/apple-tv.svg' },
  { id: 'hbo-max', name: 'HBO Max', nameAr: 'HBO Max', color: '#5822b4', packageId: 'com.hbo.hbonow', deepLink: 'https://max.com/', icon: 'app-icons/hbo-max.svg' },
];
interface Props { language: 'ar' | 'en'; onOpenApp: (app: AppItem) => void; tutorialHighlightActive?: boolean; }

export const AppFavoritesBar: React.FC<Props> = ({ language, onOpenApp, tutorialHighlightActive = false }) => {
  const isAr = language === 'ar';
  const appEdgePadding = 19;
  const appsContentWidth = APPS.length * 78 + Math.max(0, APPS.length - 1) * 15 + appEdgePadding * 2;
  return (
    <section className="w-full h-[120px] shrink-0 px-3 pb-2" dir="rtl" aria-label={isAr ? 'اختصارات التطبيقات' : 'App shortcuts'}>
      <div
        className="app-shortcuts-native-scroll mx-auto h-[112px] w-full max-w-[410px] overflow-x-auto overflow-y-hidden rounded-2xl bg-black/25 px-2 pt-2"
        dir="rtl"
        style={{ WebkitOverflowScrolling: 'touch', touchAction: 'pan-x', overscrollBehaviorX: 'contain', scrollbarWidth: 'none' }}
      >
        <div className="flex gap-[15px]" style={{ direction: 'rtl', width: `${appsContentWidth}px`, minWidth: `${appsContentWidth}px`, height: '100px', paddingLeft: `${appEdgePadding}px`, paddingRight: `${appEdgePadding}px`, boxSizing: 'border-box' }}>
          {APPS.map(app => (
            <div key={app.id} dir={isAr ? 'rtl' : 'ltr'} className="relative flex h-[94px] shrink-0 grow-0 basis-[78px] rounded-2xl border border-white/20 bg-white/[0.055] px-1 py-1 shadow-[0_0_6px_rgba(255,255,255,.08)]" style={tutorialHighlightActive ? { zIndex: 2 } : undefined}>
              <button type="button" title={isAr ? app.nameAr : app.name} onClick={() => onOpenApp(app)} className="flex h-full w-full min-w-0 flex-col items-center justify-start gap-0.5 rounded-xl px-1 py-1 text-white active:scale-95">
                <span className={`flex h-[56px] w-[56px] shrink-0 items-center justify-center rounded-2xl shadow-sm ${app.id === 'apple-tv' || app.id === 'hbo-max' ? 'bg-white' : 'bg-black/25'}`}>
                  <img src={app.icon} alt={isAr ? app.nameAr : app.name} draggable="false" loading="eager" className="block h-12 w-12 rounded-2xl object-contain" />
                </span>
                <span className="absolute bottom-1 left-1/2 z-10 block h-[19px] max-w-[calc(100%-8px)] -translate-x-1/2 overflow-visible whitespace-nowrap text-center text-[10px] font-bold leading-none text-white drop-shadow-[0_1px_3px_rgba(0,0,0,.95)]">
                  {isAr ? app.nameAr : app.name}
                </span>
              </button>
              {tutorialHighlightActive && <span aria-hidden="true" className="tour-app-outline" />}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
export default AppFavoritesBar;
export type { Props as AppFavoritesBarProps };
