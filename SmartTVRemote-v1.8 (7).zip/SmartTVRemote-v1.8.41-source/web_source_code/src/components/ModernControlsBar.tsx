import React, { useCallback, useRef } from 'react';
import { SkipForward, Play, Pause, SkipBack } from 'lucide-react';
import { RemoteKey } from '../types';
import { playRemoteClick, triggerHaptic } from '../utils/sound';
import { Language } from '../utils/i18n';

interface ModernControlsBarProps {
  onCommand: (key: RemoteKey) => void;
  language?: Language;
  isPlaying?: boolean;
}

export const ModernControlsBar: React.FC<ModernControlsBarProps> = ({ onCommand, language = 'ar', isPlaying = true }) => {
  const fireCommand = useCallback((key: RemoteKey, soundType: 'button' | 'seek' = 'seek') => {
    playRemoteClick(soundType);
    triggerHaptic(22);
    onCommand(key);
  }, [onCommand]);
  const repeatTimer = useRef<number | null>(null);
  const startHold = (key: RemoteKey) => {
    if (repeatTimer.current !== null) window.clearInterval(repeatTimer.current);
    fireCommand(key, 'seek');
    repeatTimer.current = window.setInterval(() => fireCommand(key, 'seek'), 140);
  };
  const stopHold = () => { if (repeatTimer.current !== null) { window.clearInterval(repeatTimer.current); repeatTimer.current = null; } };
  const button = 'remote-button w-[56px] h-[56px] rounded-lg bg-[#4f5456]/85 hover:bg-[#414648] border border-white/20 shadow-md active:scale-95 text-white flex items-center justify-center transition-all cursor-pointer group';
  return (
    <div className="flex items-center justify-center gap-2 select-none z-20">
      <button onPointerDown={() => startHold('SEEK_FORWARD')} onPointerUp={stopHold} onPointerCancel={stopHold} onPointerLeave={stopHold} title={language === 'ar' ? 'تقديم الفيديو' : 'Fast forward'} className={`${button}`}>
        <SkipForward className="w-7 h-7 stroke-[2.2] text-white group-hover:scale-110 transition-transform" />
      </button>
      <button onClick={() => fireCommand('PLAY_PAUSE', 'button')} title={isPlaying ? (language === 'ar' ? 'إيقاف مؤقت' : 'Pause') : (language === 'ar' ? 'تشغيل' : 'Play')} className={`${button}`}>
        {isPlaying ? <Pause className="w-7 h-7 fill-current stroke-[2.2] text-white group-hover:scale-110 transition-transform" /> : <Play className="w-7 h-7 fill-current stroke-[2.2] text-white group-hover:scale-110 transition-transform" />}
      </button>
      <button onPointerDown={() => startHold('REWIND_FAST')} onPointerUp={stopHold} onPointerCancel={stopHold} onPointerLeave={stopHold} title={language === 'ar' ? 'ترجيع الفيديو' : 'Rewind'} className={`${button}`}>
        <SkipBack className="w-7 h-7 stroke-[2.2] text-white group-hover:scale-110 transition-transform" />
      </button>
    </div>
  );
};
