import React, { useEffect, useRef, useState } from 'react';
import { Tv, RefreshCw, X, ChevronDown } from 'lucide-react';
import { TvDevice } from '../types';
import { playRemoteClick } from '../utils/sound';
import { Language, translations } from '../utils/i18n';

interface DeviceStripProps {
  currentDevice: TvDevice;
  wifiConnected: boolean;
  devices: TvDevice[];
  onSelectDevice: (device: TvDevice) => void;
  onOpenAddDevice: () => void;
  onStartDiscovery?: () => void;
  onReconnect?: (device: TvDevice) => void;
  onDisconnect?: (device: TvDevice) => void;
  onPairCodeSubmit?: (code: string) => Promise<boolean>;
  fullScreen?: boolean;
  onSkipPicker?: () => void;
  onOpenPicker?: () => void;
  language?: Language;
}

export const DeviceStrip: React.FC<DeviceStripProps> = ({ currentDevice, wifiConnected, devices, onSelectDevice, onOpenAddDevice, onStartDiscovery, onReconnect, onDisconnect, onPairCodeSubmit, language = 'ar', fullScreen = false, onSkipPicker, onOpenPicker }) => {
  const t = translations[language];
  const currentDeviceOnline = currentDevice.isOnline;
  const deviceOnline = (device: TvDevice) => device.isOnline;
  const [searching, setSearching] = useState(false);
  const [pairing, setPairing] = useState(false);
  const [code, setCode] = useState('');
  const [pairingBusy, setPairingBusy] = useState(false);
  const discoveryRef = useRef(onStartDiscovery);

  useEffect(() => { discoveryRef.current = onStartDiscovery; }, [onStartDiscovery]);

  // Keep the device list fresh while the remote is open. Native discovery
  // reports newly visible devices and connection callbacks update their state.
  useEffect(() => {
    discoveryRef.current?.();
    const timer = window.setInterval(() => discoveryRef.current?.(), 250);
    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    const done = () => setSearching(false);
    window.addEventListener('nativeDiscoveryFinished', done);
    return () => window.removeEventListener('nativeDiscoveryFinished', done);
  }, []);

  useEffect(() => {
    const paired = () => { setPairing(false); setPairingBusy(false); };
    window.addEventListener('nativePaired', paired);
    return () => window.removeEventListener('nativePaired', paired);
  }, []);

  const beginSearch = () => {
    playRemoteClick('button');
    setSearching(true);
    onStartDiscovery?.();
    window.setTimeout(() => setSearching(false), 8000);
  };

  const handleConnectionAction = (device: TvDevice) => {
    if (deviceOnline(device)) {
      playRemoteClick('button');
      onDisconnect?.(device);
      return;
    }
    choose(device);
  };

  const choose = (device: TvDevice) => {
    if (pairing || pairingBusy) return;
    playRemoteClick('button');
    onSelectDevice(device);
    // A paired TV only needs a new socket, even while it is temporarily offline.
    // Starting pairing here used to erase the saved session and left no code flow.
    if (!device.paired) { setPairing(true); setCode(''); }
    else onReconnect?.(device);
  };

  const submitCode = async (e: React.FormEvent) => {
    e.preventDefault();
    if (code.length !== 6 || !onPairCodeSubmit) return;
    setPairingBusy(true);
    const ok = await onPairCodeSubmit(code);
    setPairingBusy(false);
    if (ok) setPairing(false);
  };

  useEffect(() => {
    if (!fullScreen) return;
    setSearching(true);
    onStartDiscovery?.();
    const timer = window.setTimeout(() => setSearching(false), 10000);
    return () => window.clearTimeout(timer);
  }, [fullScreen, onStartDiscovery]);

  return <>
    {fullScreen && <div data-tour="search-picker" className="device-picker-strip fixed inset-0 z-[120] flex min-h-screen flex-col bg-[#090a0d]/75 text-white backdrop-blur-xl" dir={language === 'ar' ? 'rtl' : 'ltr'}>
      <button type="button" onClick={onSkipPicker} aria-label="تخطي" className="absolute right-4 top-4 z-10 flex h-11 w-11 items-center justify-center rounded-full bg-white/10 text-white/80 hover:bg-white/20"><X className="h-6 w-6" /></button>
      <div className="flex flex-1 flex-col items-center justify-start overflow-y-auto px-5 pt-6 text-center">
        <h1 className="text-2xl font-black sm:text-3xl">اختر تلفزيونك</h1>
        <div className="mt-8 w-full max-w-lg space-y-2 text-right">
          {devices.length === 0 && <p className="rounded-2xl border border-white/10 bg-white/[.055] px-4 py-5 text-center text-sm text-white/60">{wifiConnected ? (language === 'ar' ? 'لا توجد أجهزة تلفاز ظاهرة الآن' : 'No TVs are visible right now') : (language === 'ar' ? 'اتصل بشبكة Wi-Fi للبحث عن التلفاز' : 'Connect to Wi-Fi to search for TVs')}</p>}
          {devices.map(device => <div key={device.id} className="rounded-2xl border border-white/10 bg-white/[.055] px-4 py-3 shadow-[0_10px_30px_rgba(0,0,0,.12)]">
            <div className="flex items-center gap-3">
            <div className="min-w-0 flex-1 text-start text-sm font-bold text-[#ff8b72]">
              <span className="block truncate">{device.name}</span>
            </div>
            <button type="button" onClick={() => handleConnectionAction(device)} className={`shrink-0 whitespace-nowrap rounded-xl px-3 py-2 text-[11px] font-bold ${deviceOnline(device) ? 'border border-emerald-400/30 bg-emerald-400/10 text-emerald-300' : 'bg-[#ff421a] text-white'}`}>
              {deviceOnline(device) ? (language === 'ar' ? 'متصل / قطع اتصال' : 'Connected / Disconnect') : (language === 'ar' ? 'اتصل' : 'Connect')}
            </button>
            </div>
          </div>)}
        </div>
      </div>
    </div>}
    {!fullScreen && <div className="device-picker-strip relative z-[100] flex w-full justify-center px-4 pt-2 pb-1" dir={language === 'ar' ? 'rtl' : 'ltr'}>
      <button data-tour="search-control" type="button" aria-label={currentDeviceOnline ? currentDevice.name : (language === 'ar' ? 'ابحث عن تلفاز' : 'Search for a TV')} onClick={() => { playRemoteClick('button'); onOpenPicker?.(); }} className="flex items-center gap-2 rounded-2xl border border-white/15 bg-white/10 px-4 py-2 text-sm font-semibold shadow-lg backdrop-blur-md transition-all hover:bg-white/15">
        <span className={`max-w-[180px] truncate transition-colors ${currentDeviceOnline ? 'text-emerald-400' : 'text-white/75'}`}>{currentDeviceOnline ? currentDevice.name : (language === 'ar' ? 'ابحث' : 'Search')}</span>
        {!currentDeviceOnline && <ChevronDown aria-hidden="true" className="h-4 w-4 shrink-0 text-white/80" />}
      </button>
    </div>}
    {pairing && <div className="fixed inset-0 z-[130] flex items-center justify-center bg-[#090a0d]/75 p-3 backdrop-blur-xl" dir={language === 'ar' ? 'rtl' : 'ltr'}>
      <form onSubmit={submitCode} className="w-[min(88vw,340px)] rounded-3xl border border-white/10 bg-[#202226]/95 p-6 text-center shadow-2xl"><Tv className="mx-auto h-9 w-9 text-[#ff8b72]" /><h3 className="mt-3 text-lg font-semibold">{currentDevice.name}</h3><p className="mt-2 text-sm text-white/65">{t.pairingCode}</p><input autoFocus value={code} onChange={e => setCode(e.target.value.toUpperCase().replace(/[^0-9A-F]/g, '').slice(0, 6))} inputMode="text" autoCapitalize="characters" autoCorrect="off" spellCheck={false} placeholder="A1B2C3" maxLength={6} className="mt-4 w-full rounded-xl border border-white/15 bg-black/30 px-4 py-3 text-center font-mono uppercase tracking-[0.5em]" /><button disabled={pairingBusy || code.length !== 6} className="mt-4 w-full rounded-xl bg-[#ff421a] py-3 text-sm font-semibold disabled:opacity-40">{pairingBusy ? <RefreshCw className="mx-auto h-4 w-4 animate-spin" /> : t.confirmCode}</button><button type="button" onClick={() => { (window as any).AndroidBridge?.disconnect?.(); setPairing(false); setPairingBusy(false); }} className="mt-3 text-xs text-white/55">{t.close}</button></form>
    </div>}
  </>;
};
