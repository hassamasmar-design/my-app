import React, { useState, useEffect } from 'react';
import { X, Mic, MicOff, Search, Sparkles } from 'lucide-react';
import { playRemoteClick, triggerHaptic } from '../utils/sound';
import { Language } from '../utils/i18n';

interface VoiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSendVoiceQuery: (query: string) => void;
  language?: Language;
}

export const VoiceModal: React.FC<VoiceModalProps> = ({
  isOpen,
  onClose,
  onSendVoiceQuery,
  language = 'ar',
}) => {
  const [transcript, setTranscript] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [hasSpeechRecognition, setHasSpeechRecognition] = useState(true);
  const isAr = language === 'ar';

  useEffect(() => {
    if (!isOpen) {
      setTranscript('');
      setIsListening(false);
      return;
    }

    // Check SpeechRecognition API safely
    const win = window as unknown as {
      SpeechRecognition?: new () => any;
      webkitSpeechRecognition?: new () => any;
    };
    const SpeechRecognitionClass = win.SpeechRecognition || win.webkitSpeechRecognition;

    if (!SpeechRecognitionClass) {
      setHasSpeechRecognition(false);
      setIsListening(false);
      return;
    }

    setHasSpeechRecognition(true);
    try {
      const recognition = new SpeechRecognitionClass();
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = isAr ? 'ar-SA' : 'en-US';

      recognition.onstart = () => {
        setIsListening(true);
        triggerHaptic(25);
      };

      recognition.onresult = (event: any) => {
        const results = event.results;
        if (!results) return;
        const text = Array.from({ length: results.length }, (_, i) => results[i])
          .map((res: any) => res[0]?.transcript || '')
          .join('');
        setTranscript(text);
      };

      recognition.onerror = () => {
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognition.start();

      return () => {
        try {
          recognition.abort();
        } catch {
          // ignore abort error
        }
      };
    } catch {
      setHasSpeechRecognition(false);
      setIsListening(false);
    }
  }, [isOpen, isAr]);

  if (!isOpen) return null;

  const handleSend = () => {
    if (!transcript) return;
    playRemoteClick('button');
    triggerHaptic(20);
    onSendVoiceQuery(transcript);
    onClose();
  };

  const handleQuickCommand = (cmd: string) => {
    playRemoteClick('button');
    triggerHaptic(20);
    onSendVoiceQuery(cmd);
    onClose();
  };

  const quickCommands = isAr
    ? ['افتح يوتيوب', 'افتح نتفلكس', 'ابحث عن أفلام', 'إيقاف مؤقت', 'رفع الصوت']
    : ['Open YouTube', 'Open Netflix', 'Search movies', 'Pause', 'Volume Up'];

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200"
      dir={isAr ? 'rtl' : 'ltr'}
    >
      <div className="w-full max-w-sm bg-[#1a1c22] border border-white/10 rounded-3xl shadow-2xl p-6 flex flex-col items-center text-center text-white">
        <div className="w-full flex justify-end">
          <button
            onClick={() => {
              playRemoteClick('button');
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4 text-white/70" />
          </button>
        </div>

        {/* Animated Microphone Orb */}
        <div className="relative my-4">
          <div
            className={`w-24 h-24 rounded-full flex items-center justify-center transition-all duration-300 ${
              isListening
                ? 'bg-rose-500 shadow-2xl shadow-rose-500/50 scale-105 ring-8 ring-rose-500/20 animate-pulse'
                : 'bg-white/10'
            }`}
          >
            <Mic className={`w-10 h-10 ${isListening ? 'text-white' : 'text-white/60'}`} />
          </div>
        </div>

        <h3 className="text-base font-semibold mb-1">
          {isListening
            ? (isAr ? 'جاري الاستماع للبحث الصوتي...' : 'Listening to voice...')
            : (isAr ? 'البحث الصوتي الذكي' : 'Smart Voice Search')}
        </h3>
        <p className="text-xs text-white/50 mb-4">
          {isAr
            ? 'تحدث الآن للبحث في التلفزيون أو فتح التطبيقات'
            : 'Speak now to search TV or launch streaming apps'}
        </p>

        {/* Transcript Box */}
        <div className="w-full min-h-[56px] p-3 rounded-2xl bg-[#121317] border border-white/10 text-sm mb-4 flex items-center justify-center text-center">
          {transcript ? (
            <span className="text-white font-medium">{transcript}</span>
          ) : (
            <span className="text-white/30 italic text-xs">
              {isListening
                ? (isAr ? 'تفضل بالكلام...' : 'Listening...')
                : (isAr ? 'قل مثلاً: "افتح يوتيوب" أو "شغل كرتون"' : 'Say e.g.: "Open YouTube" or "Play Cartoon"')}
            </span>
          )}
        </div>

        {transcript ? (
          <button
            onClick={handleSend}
            className="w-full py-2.5 bg-[#2997ff] hover:bg-[#1a88f0] text-white font-medium text-xs rounded-xl transition-all mb-4 flex items-center justify-center gap-2 cursor-pointer"
          >
            <Search className="w-4 h-4" />
            <span>{isAr ? 'إرسال الأمر للتلفزيون' : 'Send to TV'}</span>
          </button>
        ) : null}

        {/* Quick Voice Suggestions */}
        <div className="w-full text-center">
          <div className="text-[11px] font-semibold text-white/40 uppercase mb-2 flex items-center justify-center gap-1.5">
            <Sparkles className="w-3 h-3 text-[#2997ff]" />
            <span>{isAr ? 'أوامر صوتية سريعة' : 'Quick Voice Commands'}</span>
          </div>
          <div className="flex flex-wrap justify-center gap-1.5">
            {quickCommands.map((cmd) => (
              <button
                key={cmd}
                onClick={() => handleQuickCommand(cmd)}
                className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-xs text-white/70 transition-colors cursor-pointer"
              >
                {cmd}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
