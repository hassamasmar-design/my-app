import React, { useRef, useEffect } from 'react';
import { RemoteKey } from '../types';
import { playRemoteClick, triggerHaptic } from '../utils/sound';

interface TouchpadProps {
  onCommand: (cmd: RemoteKey, longPress?: boolean) => void;
  sensitivity?: number; // Touch sensitivity, fixed by default
  mouseSpeed?: number; // 0.25x to 5x, mouse mode only
  wifiConnected?: boolean;
  showTourOutline?: boolean;
  mouseMode?: boolean;
  mouseInvertY?: boolean;
}

export const Touchpad: React.FC<TouchpadProps> = ({ onCommand, sensitivity = 3, mouseSpeed = 1, wifiConnected = false, showTourOutline = false, mouseMode = false, mouseInvertY = false }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const touchStartRef = useRef<{ x: number; y: number; time: number } | null>(null);
  const lastPointRef = useRef<{ x: number; y: number } | null>(null);
  const isDraggingRef = useRef(false);
  const movedRef = useRef(false);
  const sentDuringGestureRef = useRef(false);
  const holdDelayRef = useRef<number | null>(null);
  const holdRepeatRef = useRef<number | null>(null);
  const heldRef = useRef(false);
  const heldDirectionRef = useRef<RemoteKey | null>(null);

  const cancelHold = () => {
    if (holdDelayRef.current !== null) window.clearTimeout(holdDelayRef.current);
    if (holdRepeatRef.current !== null) window.clearInterval(holdRepeatRef.current);
    holdDelayRef.current = null;
    holdRepeatRef.current = null;
    heldRef.current = false;
    heldDirectionRef.current = null;
  };
  const beginHold = () => {
    if (mouseMode) return;
    cancelHold();
    holdDelayRef.current = window.setTimeout(() => {
      heldRef.current = true;
      playRemoteClick('button');
      triggerHaptic(15);
      onCommand('DPAD_CENTER');
      holdRepeatRef.current = window.setInterval(() => onCommand('DPAD_CENTER'), 140);
    }, 350);
  };
  const finishHold = () => {
    const wasHeld = heldRef.current;
    cancelHold();
    return wasHeld;
  };

  // Pixel distance threshold for swipe detection based on sensitivity (1: 45px, 3: 30px, 5: 18px)
  const swipeThreshold = Math.max(16, 45 - (sensitivity - 1) * 7);
  // Keep the whole touch surface usable for directional navigation.
  const swipeDistance = swipeThreshold;

  const sendDirectionalStep = (direction: RemoteKey) => {
    playRemoteClick('button');
    triggerHaptic(15);
    // One swipe must remain one SHORT command. Android TV interprets a
    // long-press as key-repeat, not as a longer cursor displacement.
    onCommand(direction, false);
    sentDuringGestureRef.current = true;
  };

  const beginDirectionalRepeat = (direction: RemoteKey) => {
    if (heldDirectionRef.current === direction && holdRepeatRef.current !== null) return;
    if (holdRepeatRef.current !== null) {
      window.clearTimeout(holdRepeatRef.current);
      window.clearInterval(holdRepeatRef.current);
    }
    heldDirectionRef.current = direction;
    // Keep the first swipe separate from the repeated commands. This avoids
    // one swipe being interpreted as two immediate DPAD presses.
    holdRepeatRef.current = window.setTimeout(() => {
      if (!isDraggingRef.current || !heldDirectionRef.current) return;
      onCommand(heldDirectionRef.current, false);
      holdRepeatRef.current = window.setInterval(() => {
        if (isDraggingRef.current && heldDirectionRef.current) {
          onCommand(heldDirectionRef.current, false);
        }
      }, 50);
    }, 250);
  };

  const directionForDelta = (dx: number, dy: number): RemoteKey => {
    if (Math.abs(dx) > Math.abs(dy)) return dx > 0 ? 'DPAD_RIGHT' : 'DPAD_LEFT';
    return dy > 0 ? 'DPAD_DOWN' : 'DPAD_UP';
  };

  // Directional swipes are used only by the touch-navigation mode.
  const processMovement = (x: number, y: number) => {
    if (mouseMode) {
      const last = lastPointRef.current;
      if (!last) return;
      const dx = x - last.x;
      const dy = y - last.y;
      lastPointRef.current = { x, y };
      if (dx !== 0 || dy !== 0) {
        movedRef.current = true;
        sentDuringGestureRef.current = true;
        const scale = Math.max(0.25, Math.min(5, mouseSpeed));
        const relativeY = mouseInvertY ? -dy : dy;
        // Send relative mouse reports over Bluetooth HID; mouse mode never falls back to D-pad keys.
        (window as any).AndroidBridge?.sendMouseMove?.(dx * scale, relativeY * scale);
      }
      return;
    }
    if (movedRef.current) return;
    const last = lastPointRef.current;
    if (!last) return;
    const dx = x - last.x;
    const dy = y - last.y;
    if (Math.hypot(dx, dy) < swipeDistance) return;
    cancelHold();
    movedRef.current = true;
    const direction = directionForDelta(dx, dy);
    sendDirectionalStep(direction);
    beginDirectionalRepeat(direction);
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLElement>) => {
    // Only primary mouse button or touch
    if (e.button !== 0 && e.pointerType === 'mouse') return;
    // Touch devices use the explicit touch handlers below to avoid duplicate events.
    if (e.pointerType === 'touch') return;

    // Stop propagation so parent containers do not catch it
    e.stopPropagation();

    const rect = containerRef.current?.getBoundingClientRect();
    if (!rect) return;

    touchStartRef.current = {
      x: e.clientX,
      y: e.clientY,
      time: Date.now(),
    };
    lastPointRef.current = { x: e.clientX, y: e.clientY };
    movedRef.current = false;
    sentDuringGestureRef.current = false;
    isDraggingRef.current = true;
    beginHold();

    // Capture pointer on the SVG touch area
    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch {
      // ignore
    }
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLElement>) => {
    if (!isDraggingRef.current || !touchStartRef.current) return;
    processMovement(e.clientX, e.clientY);
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLElement>) => {
    if (!isDraggingRef.current || !touchStartRef.current) return;

    const dx = e.clientX - touchStartRef.current.x;
    const dy = e.clientY - touchStartRef.current.y;
    const dt = Date.now() - touchStartRef.current.time;
    const distance = Math.hypot(dx, dy);
    const wasHeld = finishHold();
    processMovement(e.clientX, e.clientY);
    cancelHold();
    const moved = movedRef.current || sentDuringGestureRef.current;
    isDraggingRef.current = false;
    touchStartRef.current = null;
    lastPointRef.current = null;
    movedRef.current = false;

    try {
      e.currentTarget.releasePointerCapture(e.pointerId);
    } catch {
      // ignore
    }

    // Movement commands were sent continuously while the finger was moving.
    if (moved) {
      sentDuringGestureRef.current = false;
      return;
    }

    if (distance < swipeThreshold && dt < 350 && !wasHeld) {
      triggerHaptic(20);
      if (mouseMode) {
        (window as any).AndroidBridge?.sendMouseClick?.();
      } else {
        playRemoteClick('button');
        onCommand('DPAD_CENTER');
      }
    }
    sentDuringGestureRef.current = false;
  };

  const handlePointerCancel = (e: React.PointerEvent<HTMLElement>) => {
    cancelHold();
    isDraggingRef.current = false;
    touchStartRef.current = null;
    lastPointRef.current = null;
    movedRef.current = false;
    sentDuringGestureRef.current = false;
    try {
      e.currentTarget.releasePointerCapture(e.pointerId);
    } catch {
      // ignore
    }
  };

  // Android WebView fallback: handle native touch events as well as pointer events.
  const handleTouchStart = (e: React.TouchEvent<HTMLElement>) => {
    const touch = e.touches[0];
    if (!touch) return;
    e.preventDefault();
    touchStartRef.current = { x: touch.clientX, y: touch.clientY, time: Date.now() };
    lastPointRef.current = { x: touch.clientX, y: touch.clientY };
    movedRef.current = false;
    sentDuringGestureRef.current = false;
    isDraggingRef.current = true;
    beginHold();
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLElement>) => {
    if (!isDraggingRef.current || !touchStartRef.current) return;
    const touch = e.touches[0];
    if (!touch) return;
    e.preventDefault();
    processMovement(touch.clientX, touch.clientY);
  };

  const handleTouchEnd = (e: React.TouchEvent<HTMLElement>) => {
    if (!isDraggingRef.current || !touchStartRef.current) return;
    e.preventDefault();
    const touch = e.changedTouches[0];
    if (!touch) return;
    const dx = touch.clientX - touchStartRef.current.x;
    const dy = touch.clientY - touchStartRef.current.y;
    const dt = Date.now() - touchStartRef.current.time;
    const distance = Math.hypot(dx, dy);
    const wasHeld = finishHold();
    processMovement(touch.clientX, touch.clientY);
    cancelHold();
    const moved = movedRef.current || sentDuringGestureRef.current;
    isDraggingRef.current = false;
    touchStartRef.current = null;
    lastPointRef.current = null;
    movedRef.current = false;

    if (moved) {
      sentDuringGestureRef.current = false;
      return;
    }
    if (distance < swipeThreshold && dt < 350 && !wasHeld) {
      triggerHaptic(20);
      if (mouseMode) {
        (window as any).AndroidBridge?.sendMouseClick?.();
      } else {
        playRemoteClick('button');
        onCommand('DPAD_CENTER');
      }
    }
    sentDuringGestureRef.current = false;
  };

  const handleTouchCancel = () => {
    cancelHold();
    isDraggingRef.current = false;
    touchStartRef.current = null;
    lastPointRef.current = null;
    movedRef.current = false;
    sentDuringGestureRef.current = false;
  };

  // Keyboard navigation support
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore if user is typing in an input
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement)?.tagName)) return;

      switch (e.key) {
        case 'ArrowUp':
          e.preventDefault();
          playRemoteClick('button');
          triggerHaptic(12);
          onCommand('DPAD_UP');
          break;
        case 'ArrowDown':
          e.preventDefault();
          playRemoteClick('button');
          triggerHaptic(12);
          onCommand('DPAD_DOWN');
          break;
        case 'ArrowLeft':
          e.preventDefault();
          playRemoteClick('button');
          triggerHaptic(12);
          onCommand('DPAD_LEFT');
          break;
        case 'ArrowRight':
          e.preventDefault();
          playRemoteClick('button');
          triggerHaptic(12);
          onCommand('DPAD_RIGHT');
          break;
        case 'Enter':
        case ' ':
          e.preventDefault();
          playRemoteClick('button');
          triggerHaptic(20);
          onCommand('DPAD_CENTER');
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onCommand]);

  /*
   * EXACT RED DASHED OUTLINE
   * The shape corresponds directly to the user's uploaded image:
   * - Flat horizontal top border beneath Menu & Sliders
   * - Inward notch around Keyboard button (top-left)
   * - Outward flank bulge along left side between Keyboard & Back
   * - Inward notch around Back button (bottom-left)
   * - Flat horizontal bottom border
   * - Inward notch around Home button (bottom-right)
   * - Outward flank bulge along right side between Home & Mic
   * - Inward notch around Mic button (top-right)
   */
  const touchAreaPath = `
    M 90 70
    L 270 70
    C 285 70 293 78 293 90
    C 293 110 306 126 332 128
    C 346 129 352 142 352 165
    L 352 315
    C 352 332 346 345 328 349
    C 298 354 286 366 286 388
    C 286 402 274 414 252 414
    L 108 414
    C 86 414 74 402 74 388
    C 74 366 62 354 32 349
    C 14 345 8 332 8 315
    L 8 165
    C 8 142 14 129 28 128
    C 54 126 67 110 67 90
    C 67 78 75 70 90 70
    Z
  `;

  return (
    <div
      ref={containerRef}
      id="touchpad-surface"
      data-input-mode={mouseMode ? 'mouse' : 'touch'}
      aria-label={mouseMode ? 'وضع الماوس' : 'وضع اللمس'}
      className="relative w-full h-[470px] select-none pointer-events-auto touch-none flex items-center justify-center"
      style={{ WebkitTapHighlightColor: 'transparent' }}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      onTouchCancel={handleTouchCancel}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerCancel={handlePointerCancel}
    >
      {/* SVG for Red Dashed Boundary and Custom Clipped Dark Touch Surface */}
      <svg
        viewBox="0 0 360 470"
        className="absolute inset-0 w-full h-full pointer-events-none drop-shadow-md"
        preserveAspectRatio="none"
      >
        <defs>
          <clipPath id="touchpad-clip">
            <path d={touchAreaPath} />
          </clipPath>
          {/* Scary Deep Void Abyss Gradient */}
          <radialGradient id="scary-void" cx="50%" cy="50%" r="55%">
            <stop offset="0%" stopColor="#000000" stopOpacity="1" />
            <stop offset="50%" stopColor="#020203" stopOpacity="1" />
            <stop offset="85%" stopColor="#060608" stopOpacity="1" />
            <stop offset="100%" stopColor="#0a0a0e" stopOpacity="1" />
          </radialGradient>
        </defs>

        {/* Pitch Black Void Base - Only this path receives touch events! */}
        <path
          d={touchAreaPath}
          fill="var(--touch-area-color, #000000)"
          className="pointer-events-none cursor-grab active:cursor-grabbing touch-none transition-colors duration-200"
        />
        {/* Abyssal Vignette Fill */}
        <path
          d={touchAreaPath}
          fill="var(--touch-area-color, #000000)"
          className="pointer-events-none"
        />

        {/* Static tutorial contour follows the exact touch-area silhouette. */}
        {showTourOutline && (
          <path
            d={touchAreaPath}
            fill="none"
            stroke="#ffd166"
            strokeWidth="3"
            strokeOpacity="1"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="pointer-events-none tour-touchpad-outline"
          />
        )}

        {/* BOUNDARY LINE MATCHING THE HOME BUTTON COLOR (#ff421a) */}
        <path
          d={touchAreaPath}
          fill="none"
          stroke="var(--border-color, #ff421a)"
          strokeWidth="2.2"
          pathLength={1000}
          strokeDasharray="970 30"
          strokeDashoffset="0"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="touchpad-border-self-blackout opacity-95 pointer-events-none"
        />
      </svg>

    </div>
  );
};
