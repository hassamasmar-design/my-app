import React from 'react';
import { RemoteKey } from '../../types';
import { playRemoteClick, triggerHaptic } from '../../utils/sound';
import { Language } from '../../utils/i18n';
import {
  Power,
  Sliders,
  Keyboard,
  Mic,
  Home,
  Undo2,
  ChevronUp,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Disc,
  Volume2,
  VolumeX,
  Volume1,
  Play,
  Pause,
  FastForward,
  Compass,
} from 'lucide-react';

interface LgMagicRemoteLayoutProps {
  onCommand: (key: RemoteKey) => void;
  isTvPowerOn: boolean;
  language: Language;
  onOpenSettings: () => void;
  onOpenKeyboard: () => void;
  onOpenVoice: () => void;
}

export const LgMagicRemoteLayout: React.FC<LgMagicRemoteLayoutProps> = ({
  onCommand,
  isTvPowerOn,
  language,
  onOpenSettings,
  onOpenKeyboard,
  onOpenVoice,
}) => {
  const isAr = language === 'ar';

  const press = (key: RemoteKey, haptic = 18, sound: 'button' | 'home' | 'power' | 'seek' = 'button') => {
    playRemoteClick(sound);
    triggerHaptic(haptic);
    onCommand(key);
  };

  return (
    <div className="w-full flex-1 flex flex-col justify-between px-6 py-4 select-none">
      {/* Top Header: Power & Magic Pointer Status */}
      <div className="flex items-center justify-between pt-1">
        <button
          id="lg-btn-power"
          onClick={() => press('POWER', 30, 'power')}
          title={isAr ? 'تشغيل / إطفاء' : 'Power On/Off'}
          className={`w-12 h-12 rounded-full flex items-center justify-center transition-all cursor-pointer shadow-lg active:scale-95 ${
            isTvPowerOn
              ? 'bg-[#c41535] text-white shadow-rose-900/40 hover:bg-[#a3102b]'
              : 'bg-[#252830] text-rose-400 hover:bg-[#30343f]'
          }`}
        >
          <Power className="w-5 h-5 stroke-[2.5]" />
        </button>

        {/* Brand Badge */}
        <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#1e2028] border border-white/10">
          <Compass className="w-3.5 h-3.5 text-[#ff2d55] animate-spin" style={{ animationDuration: '8s' }} />
          <span className="text-[10px] font-bold tracking-wider text-white/90">LG MAGIC</span>
        </div>

        <button
          id="lg-btn-settings"
          onClick={() => {
            playRemoteClick('button');
            triggerHaptic(15);
            onOpenSettings();
          }}
          className="w-12 h-12 rounded-full bg-[#252830] hover:bg-[#2f333e] active:scale-95 text-[#2997ff] flex items-center justify-center transition-all cursor-pointer border border-white/5 shadow-md"
        >
          <Sliders className="w-5 h-5" />
        </button>
      </div>

      {/* Quick Access Utility Row */}
      <div className="grid grid-cols-3 gap-2.5 my-2">
        <button
          id="lg-btn-kbd"
          onClick={() => {
            playRemoteClick('button');
            triggerHaptic(15);
            onOpenKeyboard();
          }}
          className="py-2.5 rounded-xl bg-[#20232a] hover:bg-[#282c35] active:scale-95 text-xs text-white/80 border border-white/5 flex items-center justify-center gap-1 cursor-pointer transition-all"
        >
          <Keyboard className="w-3.5 h-3.5 text-white/60" />
          <span>{isAr ? 'كيبورد' : 'Keyboard'}</span>
        </button>

        <button
          id="lg-btn-mic"
          onClick={() => {
            playRemoteClick('button');
            triggerHaptic(20);
            onOpenVoice();
          }}
          className="py-2.5 rounded-xl bg-[#ff2d55]/15 hover:bg-[#ff2d55]/25 text-[#ff2d55] border border-[#ff2d55]/30 active:scale-95 text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-all"
        >
          <Mic className="w-3.5 h-3.5" />
          <span>{isAr ? 'صوت AI' : 'Voice'}</span>
        </button>

        <button
          id="lg-btn-mute"
          onClick={() => press('VOLUME_MUTE')}
          className="py-2.5 rounded-xl bg-[#20232a] hover:bg-[#282c35] active:scale-95 text-xs text-white/80 border border-white/5 flex items-center justify-center gap-1 cursor-pointer transition-all"
        >
          <VolumeX className="w-3.5 h-3.5 text-amber-400" />
          <span>{isAr ? 'كتم' : 'Mute'}</span>
        </button>
      </div>

      {/* LG Magic Wheel / Scroll Disc Centerpiece */}
      <div className="relative my-4 flex items-center justify-center">
        <div className="relative w-60 h-60 rounded-full bg-gradient-to-b from-[#252932] to-[#15171d] border-2 border-white/10 shadow-[0_12px_35px_rgba(0,0,0,0.85)] p-2 flex items-center justify-center">
          {/* Navigation Arrows */}
          <button
            id="lg-dpad-up"
            onClick={() => press('DPAD_UP')}
            className="absolute top-2 left-1/2 -translate-x-1/2 w-16 h-12 flex items-center justify-center text-white/70 hover:text-[#ff2d55] active:scale-90 transition-all cursor-pointer"
          >
            <ChevronUp className="w-7 h-7 stroke-[2.5]" />
          </button>

          <button
            id="lg-dpad-down"
            onClick={() => press('DPAD_DOWN')}
            className="absolute bottom-2 left-1/2 -translate-x-1/2 w-16 h-12 flex items-center justify-center text-white/70 hover:text-[#ff2d55] active:scale-90 transition-all cursor-pointer"
          >
            <ChevronDown className="w-7 h-7 stroke-[2.5]" />
          </button>

          <button
            id="lg-dpad-left"
            onClick={() => press('DPAD_LEFT')}
            className="absolute left-2 top-1/2 -translate-y-1/2 w-12 h-16 flex items-center justify-center text-white/70 hover:text-[#ff2d55] active:scale-90 transition-all cursor-pointer"
          >
            <ChevronLeft className="w-7 h-7 stroke-[2.5]" />
          </button>

          <button
            id="lg-dpad-right"
            onClick={() => press('DPAD_RIGHT')}
            className="absolute right-2 top-1/2 -translate-y-1/2 w-12 h-16 flex items-center justify-center text-white/70 hover:text-[#ff2d55] active:scale-90 transition-all cursor-pointer"
          >
            <ChevronRight className="w-7 h-7 stroke-[2.5]" />
          </button>

          {/* Central Magic Scroll Wheel (عجلة الماجيك الشهيرة في ريموت إل جي) */}
          <button
            id="lg-magic-wheel"
            onClick={() => press('DPAD_CENTER', 25)}
            className="group w-28 h-28 rounded-full bg-gradient-to-b from-[#2e3340] to-[#1a1c24] border-2 border-white/20 shadow-inner flex flex-col items-center justify-center text-white active:scale-95 transition-all cursor-pointer hover:border-[#ff2d55]/60"
          >
            <div className="w-8 h-10 rounded-lg bg-[#15171d] border border-white/10 flex flex-col items-center justify-center gap-1 shadow-sm mb-1 group-hover:border-[#ff2d55]">
              <div className="w-4 h-0.5 bg-white/40" />
              <div className="w-4 h-0.5 bg-[#ff2d55]" />
              <div className="w-4 h-0.5 bg-white/40" />
            </div>
            <span className="text-[10px] font-bold text-white/90">WHEEL / OK</span>
          </button>
        </div>
      </div>

      {/* Nav Controls: Back, Home, Live Zoom/Menu */}
      <div className="grid grid-cols-3 gap-3 my-2">
        <button
          id="lg-btn-back"
          onClick={() => press('BACK')}
          title={isAr ? 'رجوع' : 'Back'}
          className="py-3 rounded-2xl bg-[#20232a] hover:bg-[#282c35] active:scale-95 text-white/80 flex flex-col items-center justify-center gap-1 border border-white/5 transition-all cursor-pointer"
        >
          <Undo2 className="w-5 h-5" />
          <span className="text-[10px]">{isAr ? 'رجوع' : 'Back'}</span>
        </button>

        <button
          id="lg-btn-home"
          onClick={() => press('HOME', 25, 'home')}
          title={isAr ? 'الرئيسية' : 'Home'}
          className="py-3 rounded-2xl bg-[#20232a] hover:bg-[#282c35] active:scale-95 text-[#ff2d55] flex flex-col items-center justify-center gap-1 border border-[#ff2d55]/20 transition-all cursor-pointer shadow-md"
        >
          <Home className="w-5 h-5" />
          <span className="text-[10px] font-bold">{isAr ? 'الرئيسية' : 'Home'}</span>
        </button>

        <button
          id="lg-btn-menu"
          onClick={() => press('MENU')}
          title={isAr ? 'القائمة' : 'Menu'}
          className="py-3 rounded-2xl bg-[#20232a] hover:bg-[#282c35] active:scale-95 text-white/80 flex flex-col items-center justify-center gap-1 border border-white/5 transition-all cursor-pointer"
        >
          <Disc className="w-5 h-5" />
          <span className="text-[10px]">{isAr ? 'خيارات' : 'Options'}</span>
        </button>
      </div>

      {/* Bottom Volume / FastForward / Channels */}
      <div className="grid grid-cols-3 gap-3 pt-2 items-center">
        {/* Volume */}
        <div className="flex flex-col items-center bg-[#1b1e25] rounded-2xl p-1 border border-white/5">
          <button
            id="lg-vol-up"
            onClick={() => press('VOLUME_UP')}
            className="w-full py-2 flex items-center justify-center text-white/70 hover:text-[#ff2d55] active:scale-90 transition-all cursor-pointer"
          >
            <Volume2 className="w-4 h-4" />
          </button>
          <span className="text-[10px] font-mono font-bold text-white/40 my-0.5">VOL</span>
          <button
            id="lg-vol-down"
            onClick={() => press('VOLUME_DOWN')}
            className="w-full py-2 flex items-center justify-center text-white/70 hover:text-[#ff2d55] active:scale-90 transition-all cursor-pointer"
          >
            <Volume1 className="w-4 h-4" />
          </button>
        </div>

        {/* FastForward +10s Hero */}
        <button
          id="lg-btn-fast-forward"
          onClick={() => press('SEEK_FORWARD', 20, 'seek')}
          className="h-24 rounded-2xl bg-gradient-to-b from-[#2e323d] to-[#1f2229] border border-[#ff5722]/30 shadow-lg flex flex-col items-center justify-center gap-1 text-[#ff5722] active:scale-95 transition-all cursor-pointer"
        >
          <FastForward className="w-6 h-6 stroke-[2.2]" />
          <span className="text-[11px] font-mono font-bold text-white/90">+10s</span>
          <span className="text-[9px] text-white/40">{isAr ? 'تقديم سريع' : 'Fast Forward'}</span>
        </button>

        {/* Channel */}
        <div className="flex flex-col items-center bg-[#1b1e25] rounded-2xl p-1 border border-white/5">
          <button
            id="lg-ch-up"
            onClick={() => press('CHANNEL_UP')}
            className="w-full py-2 flex items-center justify-center text-white/70 hover:text-[#ff2d55] active:scale-90 transition-all cursor-pointer"
          >
            <ChevronUp className="w-4 h-4" />
          </button>
          <span className="text-[10px] font-mono font-bold text-white/40 my-0.5">CH</span>
          <button
            id="lg-ch-down"
            onClick={() => press('CHANNEL_DOWN')}
            className="w-full py-2 flex items-center justify-center text-white/70 hover:text-[#ff2d55] active:scale-90 transition-all cursor-pointer"
          >
            <ChevronDown className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
