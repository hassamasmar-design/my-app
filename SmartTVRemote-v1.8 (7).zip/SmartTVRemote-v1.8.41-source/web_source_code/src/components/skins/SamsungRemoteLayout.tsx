import React from 'react';
import { RemoteKey } from '../../types';
import { playRemoteClick, triggerHaptic } from '../../utils/sound';
import { Language } from '../../utils/i18n';
import {
  Power,
  Sliders,
  Keyboard,
  Mic,
  Home,
  Undo2,
  ChevronUp,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Volume2,
  VolumeX,
  Volume1,
  Play,
  Pause,
  FastForward,
  Tv,
} from 'lucide-react';

interface SamsungRemoteLayoutProps {
  onCommand: (key: RemoteKey) => void;
  isTvPowerOn: boolean;
  language: Language;
  onOpenSettings: () => void;
  onOpenKeyboard: () => void;
  onOpenVoice: () => void;
}

export const SamsungRemoteLayout: React.FC<SamsungRemoteLayoutProps> = ({
  onCommand,
  isTvPowerOn,
  language,
  onOpenSettings,
  onOpenKeyboard,
  onOpenVoice,
}) => {
  const isAr = language === 'ar';

  const press = (key: RemoteKey, haptic = 18, sound: 'button' | 'home' | 'power' | 'seek' = 'button') => {
    playRemoteClick(sound);
    triggerHaptic(haptic);
    onCommand(key);
  };

  return (
    <div className="w-full flex-1 flex flex-col justify-between px-6 py-4 select-none">
      {/* Top Section: Power, Source/Settings, Mic */}
      <div className="flex items-center justify-between pt-1">
        {/* Power Button */}
        <button
          id="samsung-btn-power"
          onClick={() => press('POWER', 30, 'power')}
          title={isAr ? 'تشغيل / إطفاء التلفاز' : 'Power On/Off'}
          className={`w-12 h-12 rounded-full flex items-center justify-center transition-all cursor-pointer shadow-lg active:scale-95 ${
            isTvPowerOn
              ? 'bg-[#e50914] text-white shadow-red-900/40 hover:bg-red-600'
              : 'bg-[#2a2d34] text-red-400 hover:bg-[#343842]'
          }`}
        >
          <Power className="w-5 h-5 stroke-[2.5]" />
        </button>

        {/* Brand Badge */}
        <div className="px-3 py-1 rounded-full bg-[#1b1e24] border border-white/10 text-[11px] font-bold tracking-widest text-[#2997ff] uppercase">
          SAMSUNG ONE
        </div>

        {/* Mic / Voice */}
        <button
          id="samsung-btn-mic"
          onClick={() => {
            playRemoteClick('button');
            triggerHaptic(20);
            onOpenVoice();
          }}
          title={isAr ? 'البحث الصوتي' : 'Voice Assistant'}
          className="w-12 h-12 rounded-full bg-[#252830] hover:bg-[#2e323c] active:scale-95 text-[#2997ff] flex items-center justify-center transition-all cursor-pointer border border-white/5 shadow-md"
        >
          <Mic className="w-5 h-5" />
        </button>
      </div>

      {/* Numerical & Utility Shortcuts (123, Settings, Keyboard) */}
      <div className="grid grid-cols-3 gap-3 my-2 px-2">
        <button
          id="samsung-btn-123"
          onClick={() => press('CHANNEL_LIST')}
          className="py-2.5 rounded-2xl bg-[#1d2026] hover:bg-[#252932] active:scale-95 text-xs font-semibold text-white/80 border border-white/5 transition-all cursor-pointer flex items-center justify-center gap-1"
        >
          <Tv className="w-3.5 h-3.5 text-[#2997ff]" />
          <span>123</span>
        </button>

        <button
          id="samsung-btn-kbd"
          onClick={() => {
            playRemoteClick('button');
            triggerHaptic(15);
            onOpenKeyboard();
          }}
          className="py-2.5 rounded-2xl bg-[#1d2026] hover:bg-[#252932] active:scale-95 text-xs font-semibold text-white/80 border border-white/5 transition-all cursor-pointer flex items-center justify-center gap-1.5"
        >
          <Keyboard className="w-3.5 h-3.5 text-white/70" />
          <span>{isAr ? 'لوحة' : 'Keypad'}</span>
        </button>

        <button
          id="samsung-btn-settings"
          onClick={() => {
            playRemoteClick('button');
            triggerHaptic(15);
            onOpenSettings();
          }}
          className="py-2.5 rounded-2xl bg-[#1d2026] hover:bg-[#252932] active:scale-95 text-xs font-semibold text-white/80 border border-white/5 transition-all cursor-pointer flex items-center justify-center gap-1.5"
        >
          <Sliders className="w-3.5 h-3.5 text-[#2997ff]" />
          <span>{isAr ? 'إعدادات' : 'Settings'}</span>
        </button>
      </div>

      {/* Samsung Signature Circular D-Pad Nav Ring */}
      <div className="relative my-4 flex items-center justify-center">
        <div className="relative w-56 h-56 rounded-full bg-gradient-to-b from-[#232730] to-[#171920] border-2 border-white/10 shadow-[0_12px_35px_rgba(0,0,0,0.8)] p-2 flex items-center justify-center">
          {/* UP Button */}
          <button
            id="samsung-dpad-up"
            onClick={() => press('DPAD_UP')}
            className="absolute top-2 left-1/2 -translate-x-1/2 w-16 h-12 flex items-center justify-center text-white/70 hover:text-[#2997ff] active:scale-90 transition-all cursor-pointer"
          >
            <ChevronUp className="w-7 h-7 stroke-[2.5]" />
          </button>

          {/* DOWN Button */}
          <button
            id="samsung-dpad-down"
            onClick={() => press('DPAD_DOWN')}
            className="absolute bottom-2 left-1/2 -translate-x-1/2 w-16 h-12 flex items-center justify-center text-white/70 hover:text-[#2997ff] active:scale-90 transition-all cursor-pointer"
          >
            <ChevronDown className="w-7 h-7 stroke-[2.5]" />
          </button>

          {/* LEFT Button */}
          <button
            id="samsung-dpad-left"
            onClick={() => press('DPAD_LEFT')}
            className="absolute left-2 top-1/2 -translate-y-1/2 w-12 h-16 flex items-center justify-center text-white/70 hover:text-[#2997ff] active:scale-90 transition-all cursor-pointer"
          >
            <ChevronLeft className="w-7 h-7 stroke-[2.5]" />
          </button>

          {/* RIGHT Button */}
          <button
            id="samsung-dpad-right"
            onClick={() => press('DPAD_RIGHT')}
            className="absolute right-2 top-1/2 -translate-y-1/2 w-12 h-16 flex items-center justify-center text-white/70 hover:text-[#2997ff] active:scale-90 transition-all cursor-pointer"
          >
            <ChevronRight className="w-7 h-7 stroke-[2.5]" />
          </button>

          {/* Center OK Button */}
          <button
            id="samsung-dpad-center"
            onClick={() => press('DPAD_CENTER', 25)}
            className="w-24 h-24 rounded-full bg-gradient-to-b from-[#2d323e] to-[#1c1e26] border border-white/15 shadow-inner flex flex-col items-center justify-center text-white active:scale-95 transition-all cursor-pointer hover:border-[#2997ff]/50"
          >
            <span className="text-xs font-bold tracking-wider text-[#2997ff]">OK</span>
            <span className="text-[10px] text-white/40">{isAr ? 'تأكيد' : 'Select'}</span>
          </button>
        </div>
      </div>

      {/* Nav Row: Back, Home, Play/Pause */}
      <div className="grid grid-cols-3 gap-3 my-2 px-2">
        <button
          id="samsung-btn-back"
          onClick={() => press('BACK')}
          title={isAr ? 'رجوع' : 'Back'}
          className="py-3 rounded-2xl bg-[#21242c] hover:bg-[#2a2e38] active:scale-95 text-white/80 flex flex-col items-center justify-center gap-1 border border-white/5 transition-all cursor-pointer"
        >
          <Undo2 className="w-5 h-5" />
          <span className="text-[10px]">{isAr ? 'رجوع' : 'Back'}</span>
        </button>

        <button
          id="samsung-btn-home"
          onClick={() => press('HOME', 25, 'home')}
          title={isAr ? 'الرئيسية' : 'Home'}
          className="py-3 rounded-2xl bg-[#21242c] hover:bg-[#2a2e38] active:scale-95 text-white flex flex-col items-center justify-center gap-1 border border-white/10 transition-all cursor-pointer shadow-md"
        >
          <Home className="w-5 h-5 text-[#2997ff]" />
          <span className="text-[10px] font-bold text-[#2997ff]">{isAr ? 'الرئيسية' : 'Home'}</span>
        </button>

        <button
          id="samsung-btn-play"
          onClick={() => press('PLAY_PAUSE')}
          title={isAr ? 'تشغيل / إيقاف' : 'Play / Pause'}
          className="py-3 rounded-2xl bg-[#21242c] hover:bg-[#2a2e38] active:scale-95 text-white/80 flex flex-col items-center justify-center gap-1 border border-white/5 transition-all cursor-pointer"
        >
          <div className="flex items-center gap-0.5">
            <Play className="w-3.5 h-3.5 fill-current" />
            <Pause className="w-3.5 h-3.5 fill-current" />
          </div>
          <span className="text-[10px]">{isAr ? 'تشغيل' : 'Play'}</span>
        </button>
      </div>

      {/* Samsung Rockers: Volume Rocker & Channel Rocker + FastForward */}
      <div className="grid grid-cols-3 gap-3 pt-2 items-center px-2">
        {/* Volume Rocker Column */}
        <div className="flex flex-col items-center bg-[#1c1f26] rounded-2xl p-1 border border-white/5">
          <button
            id="samsung-vol-up"
            onClick={() => press('VOLUME_UP')}
            className="w-full py-2 flex items-center justify-center text-white/70 hover:text-[#2997ff] active:scale-90 transition-all cursor-pointer"
          >
            <Volume2 className="w-4 h-4" />
          </button>
          <span className="text-[10px] font-mono font-bold text-white/40 my-0.5">VOL</span>
          <button
            id="samsung-vol-down"
            onClick={() => press('VOLUME_DOWN')}
            className="w-full py-2 flex items-center justify-center text-white/70 hover:text-[#2997ff] active:scale-90 transition-all cursor-pointer"
          >
            <Volume1 className="w-4 h-4" />
          </button>
        </div>

        {/* Fast Forward Hero */}
        <button
          id="samsung-btn-fast-forward"
          onClick={() => press('SEEK_FORWARD', 20, 'seek')}
          className="h-24 rounded-2xl bg-gradient-to-b from-[#2e323d] to-[#1f2229] border border-[#ff5722]/30 shadow-lg flex flex-col items-center justify-center gap-1 text-[#ff5722] active:scale-95 transition-all cursor-pointer"
        >
          <FastForward className="w-6 h-6 stroke-[2.2]" />
          <span className="text-[11px] font-mono font-bold text-white/90">+10s</span>
          <span className="text-[9px] text-white/40">{isAr ? 'تقديم سريع' : 'Fast Forward'}</span>
        </button>

        {/* Channel Rocker Column */}
        <div className="flex flex-col items-center bg-[#1c1f26] rounded-2xl p-1 border border-white/5">
          <button
            id="samsung-ch-up"
            onClick={() => press('CHANNEL_UP')}
            className="w-full py-2 flex items-center justify-center text-white/70 hover:text-[#2997ff] active:scale-90 transition-all cursor-pointer"
          >
            <ChevronUp className="w-4 h-4" />
          </button>
          <span className="text-[10px] font-mono font-bold text-white/40 my-0.5">CH</span>
          <button
            id="samsung-ch-down"
            onClick={() => press('CHANNEL_DOWN')}
            className="w-full py-2 flex items-center justify-center text-white/70 hover:text-[#2997ff] active:scale-90 transition-all cursor-pointer"
          >
            <ChevronDown className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
