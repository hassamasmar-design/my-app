import React, { useRef, useState, useCallback } from 'react';
import { RemoteKey } from '../../types';
import { playRemoteClick, triggerHaptic } from '../../utils/sound';
import { Language } from '../../utils/i18n';
import {
  Power,
  Sliders,
  Keyboard,
  Mic,
  Tv,
  Undo2,
  Play,
  Pause,
  Volume2,
  VolumeX,
  Volume1,
  FastForward,
} from 'lucide-react';

interface AppleTvRemoteLayoutProps {
  onCommand: (key: RemoteKey) => void;
  isTvPowerOn: boolean;
  language: Language;
  onOpenSettings: () => void;
  onOpenKeyboard: () => void;
  onOpenVoice: () => void;
  sensitivity?: number;
}

export const AppleTvRemoteLayout: React.FC<AppleTvRemoteLayoutProps> = ({
  onCommand,
  isTvPowerOn,
  language,
  onOpenSettings,
  onOpenKeyboard,
  onOpenVoice,
  sensitivity = 3,
}) => {
  const isAr = language === 'ar';
  const touchStartRef = useRef<{ x: number; y: number; time: number } | null>(null);
  const [isSwiping, setIsSwiping] = useState(false);

  const press = (key: RemoteKey, haptic = 16, sound: 'button' | 'home' | 'power' | 'seek' = 'button') => {
    playRemoteClick(sound);
    triggerHaptic(haptic);
    onCommand(key);
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    touchStartRef.current = { x: e.clientX, y: e.clientY, time: Date.now() };
    setIsSwiping(true);
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!touchStartRef.current) return;
    const dx = e.clientX - touchStartRef.current.x;
    const dy = e.clientY - touchStartRef.current.y;
    const dt = Date.now() - touchStartRef.current.time;
    const dist = Math.sqrt(dx * dx + dy * dy);

    touchStartRef.current = null;
    setIsSwiping(false);

    // Tap if minimal movement
    if (dist < 12 && dt < 350) {
      press('DPAD_CENTER', 24);
      return;
    }

    // Swipe threshold
    const threshold = Math.max(15, 38 - (sensitivity - 1) * 5);
    if (dist >= threshold) {
      if (Math.abs(dx) > Math.abs(dy)) {
        if (dx > 0) press('DPAD_RIGHT', 18);
        else press('DPAD_LEFT', 18);
      } else {
        if (dy > 0) press('DPAD_DOWN', 18);
        else press('DPAD_UP', 18);
      }
    }
  };

  return (
    <div className="w-full flex-1 flex flex-col justify-between px-6 py-4 select-none">
      {/* Top Metallic Bar: Power & Siri / Voice Side Button */}
      <div className="flex items-center justify-between pt-1">
        <button
          id="apple-btn-power"
          onClick={() => press('POWER', 30, 'power')}
          title={isAr ? 'تشغيل / إطفاء' : 'Power'}
          className={`w-11 h-11 rounded-full flex items-center justify-center transition-all cursor-pointer shadow-md active:scale-95 ${
            isTvPowerOn
              ? 'bg-[#32363f] text-white hover:bg-[#3d424e]'
              : 'bg-[#212328] text-white/40 hover:bg-[#2b2e35]'
          }`}
        >
          <Power className="w-4 h-4 stroke-[2.2]" />
        </button>

        {/* Apple TV Minimalist Badge */}
        <div className="px-3.5 py-1 rounded-full bg-[#1e2127] border border-white/10 text-[10px] font-semibold tracking-wider text-white/80 flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-white/70" />
          <span>SIRI REMOTE</span>
        </div>

        {/* Settings button */}
        <button
          id="apple-btn-settings"
          onClick={() => {
            playRemoteClick('button');
            triggerHaptic(15);
            onOpenSettings();
          }}
          className="w-11 h-11 rounded-full bg-[#212328] hover:bg-[#2e313a] active:scale-95 text-[#2997ff] flex items-center justify-center transition-all cursor-pointer border border-white/5 shadow-md"
        >
          <Sliders className="w-4 h-4" />
        </button>
      </div>

      {/* Apple TV Signature Clickpad (Large Circular Touch Surface with Outer Ring) */}
      <div className="relative my-4 flex items-center justify-center">
        <div
          onPointerDown={handlePointerDown}
          onPointerUp={handlePointerUp}
          className="relative w-64 h-64 rounded-full bg-gradient-to-b from-[#2a2d36] to-[#1c1e24] border-2 border-white/15 shadow-[0_15px_40px_rgba(0,0,0,0.85)] p-2.5 flex items-center justify-center cursor-grab active:cursor-grabbing touch-none select-none"
        >
          {/* Outer Direction Click Dots */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              press('DPAD_UP');
            }}
            className="absolute top-2 left-1/2 -translate-x-1/2 w-16 h-10 flex items-center justify-center text-white/50 hover:text-white transition-colors cursor-pointer"
          >
            <div className="w-2 h-2 rounded-full bg-white/40 hover:bg-white" />
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              press('DPAD_DOWN');
            }}
            className="absolute bottom-2 left-1/2 -translate-x-1/2 w-16 h-10 flex items-center justify-center text-white/50 hover:text-white transition-colors cursor-pointer"
          >
            <div className="w-2 h-2 rounded-full bg-white/40 hover:bg-white" />
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              press('DPAD_LEFT');
            }}
            className="absolute left-2 top-1/2 -translate-y-1/2 w-10 h-16 flex items-center justify-center text-white/50 hover:text-white transition-colors cursor-pointer"
          >
            <div className="w-2 h-2 rounded-full bg-white/40 hover:bg-white" />
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              press('DPAD_RIGHT');
            }}
            className="absolute right-2 top-1/2 -translate-y-1/2 w-10 h-16 flex items-center justify-center text-white/50 hover:text-white transition-colors cursor-pointer"
          >
            <div className="w-2 h-2 rounded-full bg-white/40 hover:bg-white" />
          </button>

          {/* Inner Touchpad / Click Button */}
          <div
            className={`w-36 h-36 rounded-full bg-gradient-to-b from-[#343944] to-[#21242d] border border-white/20 shadow-inner flex flex-col items-center justify-center text-white transition-all ${
              isSwiping ? 'scale-98 border-[#2997ff]' : ''
            }`}
          >
            <span className="text-xs font-semibold text-white/80">Touch & Click</span>
            <span className="text-[10px] text-white/40">{isAr ? 'لمس وتمرير' : 'Swipe / Tap'}</span>
          </div>
        </div>
      </div>

      {/* Grid of Apple TV Minimal Circular Buttons (Back, TV/Home, Mic, Play/Pause) */}
      <div className="grid grid-cols-2 gap-4 max-w-[280px] mx-auto my-2">
        {/* Back Button */}
        <button
          id="apple-btn-back"
          onClick={() => press('BACK')}
          title={isAr ? 'رجوع' : 'Back (<)'}
          className="h-14 rounded-2xl bg-[#23262e] hover:bg-[#2c303a] active:scale-95 text-white flex items-center justify-center gap-2 border border-white/10 transition-all cursor-pointer shadow-md"
        >
          <Undo2 className="w-5 h-5 text-white/80" />
          <span className="text-xs font-medium">{isAr ? 'رجوع' : 'Back'}</span>
        </button>

        {/* TV / Home Button */}
        <button
          id="apple-btn-home"
          onClick={() => press('HOME', 25, 'home')}
          title={isAr ? 'شاشة التلفاز' : 'TV / Control Center'}
          className="h-14 rounded-2xl bg-[#23262e] hover:bg-[#2c303a] active:scale-95 text-white flex items-center justify-center gap-2 border border-white/10 transition-all cursor-pointer shadow-md"
        >
          <Tv className="w-5 h-5 text-[#2997ff]" />
          <span className="text-xs font-medium text-[#2997ff]">{isAr ? 'تلفاز' : 'TV'}</span>
        </button>

        {/* Siri / Voice Button */}
        <button
          id="apple-btn-siri"
          onClick={() => {
            playRemoteClick('button');
            triggerHaptic(20);
            onOpenVoice();
          }}
          className="h-14 rounded-2xl bg-[#23262e] hover:bg-[#2c303a] active:scale-95 text-white flex items-center justify-center gap-2 border border-white/10 transition-all cursor-pointer shadow-md"
        >
          <Mic className="w-5 h-5 text-purple-400" />
          <span className="text-xs font-medium">{isAr ? 'سيري / صوت' : 'Siri'}</span>
        </button>

        {/* Play / Pause Button */}
        <button
          id="apple-btn-play"
          onClick={() => press('PLAY_PAUSE')}
          className="h-14 rounded-2xl bg-[#23262e] hover:bg-[#2c303a] active:scale-95 text-white flex items-center justify-center gap-2 border border-white/10 transition-all cursor-pointer shadow-md"
        >
          <div className="flex items-center gap-0.5">
            <Play className="w-3.5 h-3.5 fill-current" />
            <Pause className="w-3.5 h-3.5 fill-current" />
          </div>
          <span className="text-xs font-medium">{isAr ? 'تشغيل' : 'Play'}</span>
        </button>
      </div>

      {/* Bottom Row: Volume Rocker & FastForward (+10s) */}
      <div className="grid grid-cols-2 gap-4 max-w-[280px] mx-auto pt-2 items-center">
        {/* Apple TV Vertical Volume Pill */}
        <div className="h-16 flex items-center justify-around bg-[#1e2127] rounded-2xl p-1 border border-white/10 shadow-md">
          <button
            id="apple-vol-down"
            onClick={() => press('VOLUME_DOWN')}
            className="w-12 h-12 rounded-xl flex items-center justify-center text-white/70 hover:text-white active:scale-90 transition-all cursor-pointer"
          >
            <Volume1 className="w-5 h-5" />
          </button>
          <div className="w-[1px] h-6 bg-white/10" />
          <button
            id="apple-vol-up"
            onClick={() => press('VOLUME_UP')}
            className="w-12 h-12 rounded-xl flex items-center justify-center text-white/70 hover:text-white active:scale-90 transition-all cursor-pointer"
          >
            <Volume2 className="w-5 h-5" />
          </button>
        </div>

        {/* FastForward Hero */}
        <button
          id="apple-btn-fast-forward"
          onClick={() => press('SEEK_FORWARD', 20, 'seek')}
          className="h-16 rounded-2xl bg-gradient-to-b from-[#2d313c] to-[#1f2229] border border-[#ff5722]/30 shadow-lg flex items-center justify-center gap-2 text-[#ff5722] active:scale-95 transition-all cursor-pointer"
        >
          <FastForward className="w-5 h-5 stroke-[2.2]" />
          <div className="flex flex-col items-start">
            <span className="text-xs font-mono font-bold text-white/90">+10s</span>
            <span className="text-[9px] text-white/40">{isAr ? 'تقديم' : 'Forward'}</span>
          </div>
        </button>
      </div>
    </div>
  );
};
