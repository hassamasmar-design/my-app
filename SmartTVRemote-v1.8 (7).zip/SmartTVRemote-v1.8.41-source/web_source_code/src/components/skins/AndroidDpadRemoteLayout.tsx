import React from 'react';
import { RemoteKey } from '../../types';
import { playRemoteClick, triggerHaptic } from '../../utils/sound';
import { Language } from '../../utils/i18n';
import {
  Power,
  Sliders,
  Keyboard,
  Mic,
  Home,
  Undo2,
  ChevronUp,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Volume2,
  VolumeX,
  Volume1,
  Play,
  Pause,
  FastForward,
  Rewind,
  Menu,
  Tv,
} from 'lucide-react';

interface AndroidDpadRemoteLayoutProps {
  onCommand: (key: RemoteKey) => void;
  isTvPowerOn: boolean;
  language: Language;
  onOpenSettings: () => void;
  onOpenKeyboard: () => void;
  onOpenVoice: () => void;
}

export const AndroidDpadRemoteLayout: React.FC<AndroidDpadRemoteLayoutProps> = ({
  onCommand,
  isTvPowerOn,
  language,
  onOpenSettings,
  onOpenKeyboard,
  onOpenVoice,
}) => {
  const isAr = language === 'ar';

  const press = (key: RemoteKey, haptic = 18, sound: 'button' | 'home' | 'power' | 'seek' = 'button') => {
    playRemoteClick(sound);
    triggerHaptic(haptic);
    onCommand(key);
  };

  return (
    <div className="w-full flex-1 flex flex-col justify-between px-6 py-4 select-none">
      {/* Top Header: Power, Brand & Settings */}
      <div className="flex items-center justify-between pt-1">
        <button
          id="android-btn-power"
          onClick={() => press('POWER', 30, 'power')}
          title={isAr ? 'تشغيل / إطفاء' : 'Power'}
          className={`w-12 h-12 rounded-full flex items-center justify-center transition-all cursor-pointer shadow-lg active:scale-95 ${
            isTvPowerOn
              ? 'bg-emerald-600 text-white shadow-emerald-900/40 hover:bg-emerald-500'
              : 'bg-[#23262d] text-emerald-400 hover:bg-[#2d313a]'
          }`}
        >
          <Power className="w-5 h-5 stroke-[2.5]" />
        </button>

        {/* Android TV Badge */}
        <div className="flex items-center gap-1 px-3 py-1 rounded-full bg-[#1b1f26] border border-white/10 text-xs font-bold text-emerald-400">
          <span>android tv</span>
        </div>

        <button
          id="android-btn-settings"
          onClick={() => {
            playRemoteClick('button');
            triggerHaptic(15);
            onOpenSettings();
          }}
          className="w-12 h-12 rounded-full bg-[#23262d] hover:bg-[#2e323b] active:scale-95 text-[#2997ff] flex items-center justify-center transition-all cursor-pointer border border-white/5 shadow-md"
        >
          <Sliders className="w-5 h-5" />
        </button>
      </div>

      {/* Row 2: Google Assistant / Mic, Keyboard, Inputs */}
      <div className="grid grid-cols-3 gap-3 my-2">
        <button
          id="android-btn-mic"
          onClick={() => {
            playRemoteClick('button');
            triggerHaptic(20);
            onOpenVoice();
          }}
          className="py-2.5 rounded-2xl bg-[#23262d] hover:bg-[#2e323b] active:scale-95 text-white/90 border border-white/5 flex items-center justify-center gap-1.5 cursor-pointer shadow-sm transition-all"
        >
          <Mic className="w-4 h-4 text-emerald-400" />
          <span className="text-xs font-semibold">{isAr ? 'مساعد جوجل' : 'Google AI'}</span>
        </button>

        <button
          id="android-btn-keyboard"
          onClick={() => {
            playRemoteClick('button');
            triggerHaptic(15);
            onOpenKeyboard();
          }}
          className="py-2.5 rounded-2xl bg-[#23262d] hover:bg-[#2e323b] active:scale-95 text-white/80 border border-white/5 flex items-center justify-center gap-1.5 cursor-pointer transition-all"
        >
          <Keyboard className="w-4 h-4 text-white/60" />
          <span className="text-xs">{isAr ? 'كتابة' : 'Type'}</span>
        </button>

        <button
          id="android-btn-menu"
          onClick={() => press('MENU')}
          className="py-2.5 rounded-2xl bg-[#23262d] hover:bg-[#2e323b] active:scale-95 text-white/80 border border-white/5 flex items-center justify-center gap-1.5 cursor-pointer transition-all"
        >
          <Menu className="w-4 h-4" />
          <span className="text-xs">{isAr ? 'القائمة' : 'Menu'}</span>
        </button>
      </div>

      {/* Large Cross D-Pad / Nav Ring for Android TV */}
      <div className="relative my-4 flex items-center justify-center">
        <div className="relative w-60 h-60 rounded-3xl bg-gradient-to-b from-[#252932] to-[#171920] border-2 border-white/10 shadow-[0_12px_35px_rgba(0,0,0,0.85)] p-2 flex items-center justify-center">
          {/* UP Button */}
          <button
            id="android-dpad-up"
            onClick={() => press('DPAD_UP')}
            className="absolute top-2 left-1/2 -translate-x-1/2 w-20 h-14 rounded-2xl bg-[#20232b] hover:bg-[#2b303b] flex items-center justify-center text-white/70 hover:text-emerald-400 active:scale-90 transition-all cursor-pointer shadow-sm"
          >
            <ChevronUp className="w-8 h-8 stroke-[2.5]" />
          </button>

          {/* DOWN Button */}
          <button
            id="android-dpad-down"
            onClick={() => press('DPAD_DOWN')}
            className="absolute bottom-2 left-1/2 -translate-x-1/2 w-20 h-14 rounded-2xl bg-[#20232b] hover:bg-[#2b303b] flex items-center justify-center text-white/70 hover:text-emerald-400 active:scale-90 transition-all cursor-pointer shadow-sm"
          >
            <ChevronDown className="w-8 h-8 stroke-[2.5]" />
          </button>

          {/* LEFT Button */}
          <button
            id="android-dpad-left"
            onClick={() => press('DPAD_LEFT')}
            className="absolute left-2 top-1/2 -translate-y-1/2 w-14 h-20 rounded-2xl bg-[#20232b] hover:bg-[#2b303b] flex items-center justify-center text-white/70 hover:text-emerald-400 active:scale-90 transition-all cursor-pointer shadow-sm"
          >
            <ChevronLeft className="w-8 h-8 stroke-[2.5]" />
          </button>

          {/* RIGHT Button */}
          <button
            id="android-dpad-right"
            onClick={() => press('DPAD_RIGHT')}
            className="absolute right-2 top-1/2 -translate-y-1/2 w-14 h-20 rounded-2xl bg-[#20232b] hover:bg-[#2b303b] flex items-center justify-center text-white/70 hover:text-emerald-400 active:scale-90 transition-all cursor-pointer shadow-sm"
          >
            <ChevronRight className="w-8 h-8 stroke-[2.5]" />
          </button>

          {/* Center OK Button */}
          <button
            id="android-dpad-center"
            onClick={() => press('DPAD_CENTER', 25)}
            className="w-24 h-24 rounded-2xl bg-gradient-to-b from-[#2d323e] to-[#1c1e26] border border-emerald-500/30 shadow-inner flex flex-col items-center justify-center text-white active:scale-95 transition-all cursor-pointer hover:border-emerald-500"
          >
            <span className="text-sm font-bold tracking-wider text-emerald-400">SELECT</span>
            <span className="text-[10px] text-white/40">{isAr ? 'موافق' : 'OK'}</span>
          </button>
        </div>
      </div>

      {/* Nav Controls: Back, Home, Live TV */}
      <div className="grid grid-cols-3 gap-3 my-2">
        <button
          id="android-btn-back"
          onClick={() => press('BACK')}
          title={isAr ? 'رجوع' : 'Back'}
          className="py-3 rounded-2xl bg-[#23262d] hover:bg-[#2c3039] active:scale-95 text-white/80 flex flex-col items-center justify-center gap-1 border border-white/5 transition-all cursor-pointer"
        >
          <Undo2 className="w-5 h-5" />
          <span className="text-[10px]">{isAr ? 'رجوع' : 'Back'}</span>
        </button>

        <button
          id="android-btn-home"
          onClick={() => press('HOME', 25, 'home')}
          title={isAr ? 'الرئيسية' : 'Home'}
          className="py-3 rounded-2xl bg-[#23262d] hover:bg-[#2c3039] active:scale-95 text-emerald-400 flex flex-col items-center justify-center gap-1 border border-emerald-500/20 transition-all cursor-pointer shadow-md"
        >
          <Home className="w-5 h-5" />
          <span className="text-[10px] font-bold">{isAr ? 'الرئيسية' : 'Home'}</span>
        </button>

        <button
          id="android-btn-tv"
          onClick={() => press('PLAY_PAUSE')}
          title={isAr ? 'تشغيل / إيقاف' : 'Play/Pause'}
          className="py-3 rounded-2xl bg-[#23262d] hover:bg-[#2c3039] active:scale-95 text-white/80 flex flex-col items-center justify-center gap-1 border border-white/5 transition-all cursor-pointer"
        >
          <div className="flex items-center gap-0.5">
            <Play className="w-3.5 h-3.5 fill-current" />
            <Pause className="w-3.5 h-3.5 fill-current" />
          </div>
          <span className="text-[10px]">{isAr ? 'تشغيل' : 'Play'}</span>
        </button>
      </div>

      {/* Bottom Controls: Volume Rocker, Fast Forward Hero, Mute */}
      <div className="grid grid-cols-3 gap-3 pt-2 items-center">
        {/* Volume */}
        <div className="flex flex-col items-center bg-[#1d2027] rounded-2xl p-1 border border-white/5">
          <button
            id="android-vol-up"
            onClick={() => press('VOLUME_UP')}
            className="w-full py-2 flex items-center justify-center text-white/70 hover:text-emerald-400 active:scale-90 transition-all cursor-pointer"
          >
            <Volume2 className="w-4 h-4" />
          </button>
          <span className="text-[10px] font-mono font-bold text-white/40 my-0.5">VOL</span>
          <button
            id="android-vol-down"
            onClick={() => press('VOLUME_DOWN')}
            className="w-full py-2 flex items-center justify-center text-white/70 hover:text-emerald-400 active:scale-90 transition-all cursor-pointer"
          >
            <Volume1 className="w-4 h-4" />
          </button>
        </div>

        {/* FastForward Hero */}
        <button
          id="android-btn-fast-forward"
          onClick={() => press('SEEK_FORWARD', 20, 'seek')}
          className="h-24 rounded-2xl bg-gradient-to-b from-[#2e323d] to-[#1f2229] border border-[#ff5722]/30 shadow-lg flex flex-col items-center justify-center gap-1 text-[#ff5722] active:scale-95 transition-all cursor-pointer"
        >
          <FastForward className="w-6 h-6 stroke-[2.2]" />
          <span className="text-[11px] font-mono font-bold text-white/90">+10s</span>
          <span className="text-[9px] text-white/40">{isAr ? 'تقديم سريع' : 'Fast Forward'}</span>
        </button>

        {/* Mute / Channels */}
        <div className="flex flex-col items-center bg-[#1d2027] rounded-2xl p-1 border border-white/5">
          <button
            id="android-ch-up"
            onClick={() => press('CHANNEL_UP')}
            className="w-full py-2 flex items-center justify-center text-white/70 hover:text-emerald-400 active:scale-90 transition-all cursor-pointer"
          >
            <ChevronUp className="w-4 h-4" />
          </button>
          <span className="text-[10px] font-mono font-bold text-white/40 my-0.5">CH</span>
          <button
            id="android-ch-down"
            onClick={() => press('CHANNEL_DOWN')}
            className="w-full py-2 flex items-center justify-center text-white/70 hover:text-emerald-400 active:scale-90 transition-all cursor-pointer"
          >
            <ChevronDown className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
