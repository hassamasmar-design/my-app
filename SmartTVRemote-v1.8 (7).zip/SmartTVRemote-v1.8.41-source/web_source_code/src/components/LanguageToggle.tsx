import React from 'react';
import { Languages } from 'lucide-react';
import { Language } from '../utils/i18n';
import { playRemoteClick, triggerHaptic } from '../utils/sound';

interface LanguageToggleProps {
  currentLang: Language;
  onToggle: (lang: Language) => void;
}

export const LanguageToggle: React.FC<LanguageToggleProps> = ({
  currentLang,
  onToggle,
}) => {
  const toggleLanguage = () => {
    playRemoteClick('button');
    triggerHaptic(20);
    const nextLang: Language = currentLang === 'ar' ? 'en' : 'ar';
    onToggle(nextLang);
  };

  return (
    <button
      id="btn-language-toggle"
      onClick={toggleLanguage}
      title={currentLang === 'ar' ? 'Switch to English' : 'التحويل إلى العربية'}
      className="group relative flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#1b1f26]/90 hover:bg-[#252b36] active:bg-[#14171d] border border-white/10 hover:border-[#2997ff]/40 shadow-sm backdrop-blur-sm active:scale-95 transition-all duration-150 cursor-pointer text-xs font-medium text-[#d3d7e0] hover:text-white"
    >
      <Languages className="w-3.5 h-3.5 text-[#2997ff] group-hover:rotate-12 transition-transform duration-200" />
      <span className="font-semibold tracking-wide">
        {currentLang === 'ar' ? 'EN' : 'عربي'}
      </span>
      <span className="w-1.5 h-1.5 rounded-full bg-[#2997ff]/80" />
    </button>
  );
};
