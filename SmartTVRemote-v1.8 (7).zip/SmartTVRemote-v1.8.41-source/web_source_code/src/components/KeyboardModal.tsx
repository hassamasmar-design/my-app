import React, { useEffect, useRef, useState } from 'react';
import { Language } from '../utils/i18n';

interface KeyboardModalProps {
  isOpen: boolean;
  initialText?: string;
  onClose: () => void;
  onSendText: (insertedText: string, removedText: string, start: number, end: number) => void;
  onSendKey: (key: string) => void;
  language?: Language;
}

const getTextEdit = (previousText: string, nextText: string) => {
  const previousChars = Array.from(previousText);
  const nextChars = Array.from(nextText);
  let prefix = 0;
  while (prefix < previousChars.length && prefix < nextChars.length && previousChars[prefix] === nextChars[prefix]) prefix += 1;

  let previousEnd = previousChars.length;
  let nextEnd = nextChars.length;
  while (previousEnd > prefix && nextEnd > prefix && previousChars[previousEnd - 1] === nextChars[nextEnd - 1]) {
    previousEnd -= 1;
    nextEnd -= 1;
  }

  return {
    insertedText: nextChars.slice(prefix, nextEnd).join(''),
    removedText: previousChars.slice(prefix, previousEnd).join(''),
    start: previousChars.slice(0, prefix).join('').length,
    end: previousChars.slice(0, previousEnd).join('').length,
  };
};

export const KeyboardModal: React.FC<KeyboardModalProps> = ({
  isOpen,
  initialText = '',
  onSendText,
  onSendKey,
  language = 'ar',
}) => {
  const [text, setText] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);
  const lastTextRef = useRef('');
  const isAr = language === 'ar';

  const focusAndShowPhoneKeyboard = () => {
    inputRef.current?.focus();
    try { (window as any).AndroidBridge?.showSoftKeyboard?.(); } catch {}
  };

  useEffect(() => {
    if (!isOpen) {
      setText('');
      lastTextRef.current = '';
      return;
    }
    setText(initialText);
    lastTextRef.current = initialText;
    const timer = window.setTimeout(focusAndShowPhoneKeyboard, 250);
    return () => window.clearTimeout(timer);
  }, [isOpen, initialText]);

  if (!isOpen) return null;

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const nextText = event.target.value;
    const edit = getTextEdit(lastTextRef.current, nextText);
    lastTextRef.current = nextText;
    setText(nextText);
    if (edit.insertedText || edit.removedText) {
      onSendText(edit.insertedText, edit.removedText, edit.start, edit.end);
    }
  };

  const handleKeyDown = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === 'Enter') {
      event.preventDefault();
      onSendKey('ENTER');
    }
  };

  return (
    <div className="keyboard-modal fixed inset-0 z-[150] flex h-[100dvh] w-full flex-col overflow-y-auto bg-[#111315] text-white" dir={isAr ? 'rtl' : 'ltr'}>
      <header className="flex w-full items-center border-b border-white/10 bg-[#191c20] px-5 py-4">
        <div>
          <h1 className="text-lg font-black">{isAr ? 'الكتابة على التلفاز' : 'Type on TV'}</h1>
        </div>
      </header>

      <main className="mx-auto flex w-full max-w-[560px] flex-1 flex-col px-5 pb-8 pt-8 sm:px-8 sm:pt-12">
        <label className="mb-3 text-sm font-semibold text-white/75" htmlFor="tv-live-keyboard-input">{isAr ? 'النص' : 'Text'}</label>
        <input
          id="tv-live-keyboard-input"
          ref={inputRef}
          type="text"
          inputMode="text"
          enterKeyHint="send"
          dir={isAr ? 'rtl' : 'ltr'}
          value={text}
          onChange={handleChange}
          onKeyDown={handleKeyDown}
          autoComplete="off"
          autoCorrect="off"
          spellCheck={false}
          placeholder={isAr ? 'ابدأ الكتابة هنا' : 'Start typing here'}
          className="min-h-16 w-full self-start rounded-[20px] border border-white/15 bg-[#1b1e22] px-5 py-5 text-lg font-medium text-white shadow-[0_16px_48px_rgba(0,0,0,.35)] outline-none focus:border-[#ff421a]/70"
        />
      </main>
    </div>
  );
};
