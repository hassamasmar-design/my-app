import React from 'react';
import { Youtube, Play, Pause, Clock } from 'lucide-react';
import { playRemoteClick, triggerHaptic } from '../utils/sound';
import { Language, translations } from '../utils/i18n';

export interface TopTvStatusBarProps {
  isTvPowerOn: boolean;
  currentTitle: string;
  currentApp: string;
  isPlaying: boolean;
  playbackPosition?: number;
  playbackDuration?: number;
  onKeywordClick: (keyword: string) => void;
  language?: Language;
}

export const TopTvStatusBar: React.FC<TopTvStatusBarProps> = ({
  isTvPowerOn,
  currentTitle,
  currentApp,
  isPlaying,
  playbackPosition = 0,
  playbackDuration = 600,
  onKeywordClick,
  language = 'ar',
}) => {
  const t = translations[language];

  const kidsKeywords = [
    { id: 'baby', label: t.babySongs, query: language === 'ar' ? 'أغاني بيبي أطفال' : 'Baby Songs Nursery Rhymes' },
    { id: 'birds_of_paradise', label: t.birdsOfParadise, query: language === 'ar' ? 'طيور الجنة' : 'Toyor Al Janah' },
    { id: 'superman_kids', label: t.supermanKids, query: language === 'ar' ? 'سوبر مان كرتون أطفال' : 'Superman Kids Cartoon' },
    { id: 'masha_and_bear', label: t.mashaAndBear, query: language === 'ar' ? 'ماشا والدب' : 'Masha and the Bear' },
  ];

  const handleKeywordPress = (label: string, query: string) => {
    playRemoteClick('button');
    triggerHaptic(20);
    onKeywordClick(query);
  };

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = Math.floor(seconds % 60);
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const progressPercent = Math.min(
    100,
    Math.max(0, (playbackPosition / (playbackDuration || 600)) * 100)
  );

  return (
    <div className="w-full px-3.5 pt-1 pb-1 z-30 select-none">
      <div className="relative w-full rounded-2xl bg-gradient-to-b from-[#1b1e25]/95 via-[#14161d]/95 to-[#101217]/95 border border-white/15 shadow-xl p-2.5 backdrop-blur-md transition-all duration-300">
        {/* Status Header: Full media video info when on, or completely empty when TV is off */}
        {isTvPowerOn ? (
          <div className="mb-2 pb-2 border-b border-white/10">
            {/* Top Row: App Badge & Status */}
            <div className="flex items-center justify-between gap-2 mb-1.5">
              <div className="flex items-center gap-1.5 min-w-0">
                <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-red-600/25 border border-red-500/40 text-red-400">
                  <Youtube className="w-3.5 h-3.5 text-red-500 fill-current" />
                  <span className="text-[10px] font-bold uppercase tracking-wider">
                    {currentApp || 'YouTube'}
                  </span>
                </div>

                <span className="inline-flex items-center gap-1 text-[10px] font-medium text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded-full border border-emerald-500/20">
                  {isPlaying ? (
                    <>
                      <Play className="w-2.5 h-2.5 fill-current animate-pulse text-emerald-400" />
                      <span>{t.nowPlaying}</span>
                    </>
                  ) : (
                    <>
                      <Pause className="w-2.5 h-2.5 fill-current text-amber-400" />
                      <span className="text-amber-400">{t.paused}</span>
                    </>
                  )}
                </span>
              </div>

              <div className="flex items-center gap-1 text-[10px] font-mono text-white/60 bg-white/5 px-2 py-0.5 rounded-md border border-white/5">
                <Clock className="w-3 h-3 text-white/40" />
                <span>
                  {formatTime(playbackPosition)} / {formatTime(playbackDuration)}
                </span>
              </div>
            </div>

            {/* Video Title Display */}
            <div className="bg-black/40 rounded-xl px-2.5 py-1.5 border border-white/5 mb-1.5">
              <p
                className="text-xs font-semibold text-white/95 truncate leading-snug"
                title={currentTitle}
              >
                {currentTitle || t.noMediaPlaying}
              </p>
            </div>

            {/* Video Playback Progress Bar */}
            <div className="w-full bg-white/10 h-1 rounded-full overflow-hidden">
              <div
                className="bg-gradient-to-r from-red-500 to-[#ff421a] h-full rounded-full transition-all duration-300 shadow-[0_0_8px_rgba(255,66,26,0.6)]"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>
        ) : (
          /* عندما يكون التلفاز طافي يبقى فارغاً مع إشارة هادئة */
          <div className="flex items-center justify-center py-2.5 mb-2 pb-2 border-b border-white/5 text-white/25">
            <span className="text-[11px] font-mono tracking-wider">
              {t.tvStandbyEmpty}
            </span>
          </div>
        )}

        {/* Shortcut Keywords Bar (كلمات دلالية توجه لليوتيوب) */}
        <div className="w-full">
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5 justify-center">
            {kidsKeywords.map((item) => (
              <button
                key={item.id}
                id={`btn-keyword-${item.id}`}
                onClick={() => handleKeywordPress(item.label, item.query)}
                title={`${language === 'ar' ? 'تشغيل' : 'Play'} ${item.label} on YouTube`}
                className="group shrink-0 flex items-center gap-1 px-2.5 py-1 rounded-full bg-[#252932] hover:bg-[#2f3542] active:bg-[#1a1d23] border border-white/10 hover:border-red-500/40 text-[#d6d9e0] hover:text-white active:scale-95 transition-all text-[11px] font-medium cursor-pointer shadow-sm"
              >
                <Youtube className="w-3 h-3 text-red-500 group-hover:scale-110 transition-transform" />
                <span>{item.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
