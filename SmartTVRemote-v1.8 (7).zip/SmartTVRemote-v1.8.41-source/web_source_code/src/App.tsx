import React, { useState, useEffect, useCallback, useRef } from 'react';
import { DeviceStrip } from './components/DeviceStrip';
import { Touchpad } from './components/Touchpad';
import { SurroundingButtons } from './components/SurroundingButtons';
import { ModernControlsBar } from './components/ModernControlsBar';
import { CustomizableBar } from './components/CustomizableBar';
import { AppFavoritesBar } from './components/AppFavoritesBar';
import { SettingsModal } from './components/SettingsModal';
import { KeyboardModal } from './components/KeyboardModal';
import { VoiceModal } from './components/VoiceModal';
import { FluidVolumeBar } from './components/FluidVolumeBar';
import { Onboarding } from './components/Onboarding';
import { ButtonLayouts, TvDevice, RemoteKey, RemoteSettings, TvStatus } from './types';
import { Language, translations } from './utils/i18n';
import { configureFeedback } from './utils/sound';

const EMPTY_DEVICE: TvDevice = {
  id: 'none',
  name: 'لم يتم اختيار تلفزيون',
  type: 'custom',
  ip: '',
  port: 6467,
  protocol: 'android_tv_v2',
  isOnline: false,
  paired: false,
};
const TOUR_COMPLETE_KEY = 'smart-remote-control-tour-v8-complete';

const INITIAL_SETTINGS: RemoteSettings = {
  language: 'ar',
  hapticFeedback: true,
  soundFeedback: true,
  mouseSpeed: 1,
  mouseInvertY: false,
  tvIp: '192.168.1.108',
  autoConnect: true,
  theme: 'dark',
  remoteLayout: 'firetv',
  interfaceColors: { buttons: '#4f5456', buttonIcons: '#ffffff', border: '#ff421a', touchArea: '#1A1A1A', interface: '#2A2A2A' },
};

export default function App() {
  const [showOnboarding, setShowOnboarding] = useState(() => {
    try {
      return window.localStorage.getItem('smart-remote-onboarding-v2-complete') !== '1';
    } catch {
      return true;
    }
  });
  const [devices, setDevices] = useState<TvDevice[]>([]);
  const [currentDevice, setCurrentDevice] = useState<TvDevice>(() => {
    try {
      const savedHost = (window as any).AndroidBridge?.getSavedHost?.() || '';
      const paired = Boolean((window as any).AndroidBridge?.isHostPaired?.(savedHost));
      return savedHost ? { ...EMPTY_DEVICE, id: `saved-${savedHost}`, name: 'Android TV', ip: savedHost, isOnline: false, paired } : EMPTY_DEVICE;
    } catch {
      return EMPTY_DEVICE;
    }
  });
  const [tvPickerDismissed, setTvPickerDismissed] = useState(() => {
    try {
      const savedHost = (window as any).AndroidBridge?.getSavedHost?.() || '';
      return Boolean(savedHost && (window as any).AndroidBridge?.isHostPaired?.(savedHost));
    } catch {
      return false;
    }
  });
  const [settings, setSettings] = useState<RemoteSettings>(() => {
    try {
      const savedSpeed = Number(window.localStorage.getItem('smart-remote-bluetooth-mouse-speed-v1'));
      if (Number.isFinite(savedSpeed) && savedSpeed >= 0.25 && savedSpeed <= 5) {
        return { ...INITIAL_SETTINGS, mouseSpeed: savedSpeed };
      }
      const legacySensitivity = Number(window.localStorage.getItem('smart-remote-mouse-sensitivity-v1') ?? window.localStorage.getItem('smart-remote-shared-swipe-sensitivity-v1'));
      return Number.isFinite(legacySensitivity) && legacySensitivity >= 1 && legacySensitivity <= 5
        ? { ...INITIAL_SETTINGS, mouseSpeed: Math.max(0.25, Math.min(5, legacySensitivity / 3)) }
        : INITIAL_SETTINGS;
    } catch { return INITIAL_SETTINGS; }
  });
  const [mouseHidStatus, setMouseHidStatus] = useState('starting');
  const [mouseHidDevices, setMouseHidDevices] = useState<{ name: string; address: string }[]>([]);
  const [customizeMode, setCustomizeMode] = useState(false);
  const [selectedCustomizeId, setSelectedCustomizeId] = useState<string | null>(null);
  const [buttonLayouts, setButtonLayouts] = useState<ButtonLayouts>(() => {
    try {
      const layoutStorageKey = 'smart-remote-button-layouts-swapped-audio-mic-v3';
      const mutePositionMigrationKey = 'smart-remote-keyboard-hidden-mute-position-v1';
      const saved = JSON.parse(window.localStorage.getItem(layoutStorageKey) || '{}');
      const shouldMoveMute = window.localStorage.getItem(mutePositionMigrationKey) !== '1';
      let migrated = saved;
      if (shouldMoveMute) {
        migrated = { ...migrated, volume: migrated.keyboard || { x: 0.5, y: 13.4, size: 100, width: 100, height: 100 } };
      }
      if (migrated.audioBar && Number(migrated.audioBar.x) > 50) {
        migrated = { ...migrated, audioBar: { ...migrated.audioBar, x: 3 } };
      }
      if (shouldMoveMute || migrated !== saved) window.localStorage.setItem(layoutStorageKey, JSON.stringify(migrated));
      if (shouldMoveMute) window.localStorage.setItem(mutePositionMigrationKey, '1');
      return migrated;
    } catch { return {}; }
  });

  const updateButtonLayouts = useCallback((patch: ButtonLayouts) => {
    setButtonLayouts((previous) => {
      const next = { ...previous, ...patch };
      try { window.localStorage.setItem('smart-remote-button-layouts-swapped-audio-mic-v3', JSON.stringify(next)); } catch {}
      return next;
    });
  }, []);

  // Modals state
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isKeyboardOpen, setIsKeyboardOpen] = useState(false);
  const [keyboardInitialText, setKeyboardInitialText] = useState('');
  const [isVoiceOpen, setIsVoiceOpen] = useState(false);
  const [isExitConfirmationOpen, setIsExitConfirmationOpen] = useState(false);
  const [wifiConnected, setWifiConnected] = useState(false);
  const [tourStep, setTourStep] = useState<number | null>(() => {
    try {
      return window.localStorage.getItem(TOUR_COMPLETE_KEY) === '1' ? null : 0;
    } catch {
      return 0;
    }
  });
  const [tourRect, setTourRect] = useState<{ top: number; left: number; width: number; height: number } | null>(null);
  const [tourRectStep, setTourRectStep] = useState<number | null>(null);
  const [tourOutlineRects, setTourOutlineRects] = useState<Array<{ top: number; left: number; width: number; height: number; borderRadius: string }>>([]);
  const [touchpadRect, setTouchpadRect] = useState<{ top: number; left: number; width: number; height: number } | null>(null);

  // Current Language
  const currentLang: Language = settings.language || 'ar';
  const t = translations[currentLang];
  const isAr = currentLang === 'ar';
  const tourSteps = isAr ? [
    { title: 'منطقة اللمس', text: 'اسحب داخل هذه المنطقة للتنقل، واضغط في المنتصف للتأكيد.' },
    { title: 'زر الرجوع', text: 'يعود إلى الشاشة أو القائمة السابقة.' },
    { title: 'الميكروفون', text: 'اضغط باستمرار للتحدث والبحث الصوتي.' },
    { title: 'أزرار الصوت', text: 'اضغط أعلى أو أسفل لرفع الصوت وخفضه.' },
    { title: 'كتم الصوت', text: 'يكتم صوت التلفاز أو يلغي الكتم.' },
    { title: 'القفل', text: 'يشغّل التلفاز أو ينقله إلى وضع الاستعداد.' },
    { title: 'أزرار الفيديو', text: 'تشغيل وإيقاف وتقديم وترجيع المحتوى.' },
    { title: 'الإعدادات', text: 'يفتح إعدادات الاتصال والمظهر والصوت واللغة.' },
    { title: 'زر الهوم', text: 'ينقلك إلى الشاشة الرئيسية للتلفاز.' },
    { title: 'تطبيقات الوصول السريع', text: 'افتح تطبيقاتك المفضلة مباشرة من هذا الشريط.' },
    { title: 'زر ابحث', text: 'اضغط على «ابحث» للعثور على التلفاز والاتصال به. بعد الاتصال يظهر اسمه هنا.' },
  ] : [
    { title: 'Touchpad', text: 'Swipe here to navigate and tap the center to select.' },
    { title: 'Back', text: 'Returns to the previous screen or menu.' },
    { title: 'Microphone', text: 'Press and hold to speak and search by voice.' },
    { title: 'Volume buttons', text: 'Press the top or bottom to raise or lower volume.' },
    { title: 'Mute', text: 'Mutes or unmutes the TV sound.' },
    { title: 'Lock / Power', text: 'Turns the TV on or puts it into standby.' },
    { title: 'Video buttons', text: 'Play, pause, rewind, and fast-forward content.' },
    { title: 'Settings', text: 'Opens connection, appearance, sound, and language settings.' },
    { title: 'Home button', text: 'Goes to the TV home screen.' },
    { title: 'Quick-access apps', text: 'Open your favorite apps directly from this bar.' },
    { title: 'Search button', text: 'Tap Search here to find and connect to your TV. After connecting, its name appears here.' },
  ];
  const advanceTour = () => {
    if (tourStep === null) return;
    if (tourStep >= tourSteps.length - 1) {
      try { window.localStorage.setItem(TOUR_COMPLETE_KEY, '1'); } catch {}
      setTourStep(null);
      return;
    }
    if (tourStep === 0) setTvPickerDismissed(true);
    setTourStep(tourStep + 1);
  };
  const tourSelectors = ['#touchpad-surface', '#btn-back', '#btn-mic', '.audio-bar-wrapper .customizable-content > div', '#btn-volume', '#btn-power', '[data-customizable-id="videoBar"]', '#btn-settings', '#btn-home', '[data-tour="apps"]', '[data-tour="search-control"]'];

  useEffect(() => {
    if (tourStep === null || showOnboarding || isSettingsOpen || isKeyboardOpen || isVoiceOpen) { setTourRect(null); setTourRectStep(null); setTourOutlineRects([]); setTouchpadRect(null); return; }
    const updateTourRect = () => {
      const element = document.querySelector(tourSelectors[tourStep]) as HTMLElement | null;
      const touchpad = document.querySelector('#touchpad-surface') as HTMLElement | null;
      if (!element || !touchpad) { setTourRect(null); setTourRectStep(null); setTourOutlineRects([]); setTouchpadRect(null); return; }
      const rect = element.getBoundingClientRect();
      const padRect = touchpad.getBoundingClientRect();
      const targetElements = tourStep === 6
        ? Array.from(element.querySelectorAll('button'))
        : tourStep === 9 ? [] : [element];
      const scrollContainer = tourStep === 9
        ? element.querySelector('.app-shortcuts-native-scroll') as HTMLElement | null
        : null;
      const scrollRect = scrollContainer?.getBoundingClientRect();
      const outlineRects = targetElements.flatMap((target) => {
        const targetRect = target.getBoundingClientRect();
        if (targetRect.width <= 0 || targetRect.height <= 0) return [];
        if (scrollRect && (targetRect.right <= scrollRect.left || targetRect.left >= scrollRect.right || targetRect.bottom <= scrollRect.top || targetRect.top >= scrollRect.bottom)) return [];
        return [{
          top: targetRect.top,
          left: targetRect.left,
          width: targetRect.width,
          height: targetRect.height,
          borderRadius: window.getComputedStyle(target).borderRadius || '0px',
        }];
      });
      setTourRect({ top: rect.top, left: rect.left, width: rect.width, height: rect.height });
      setTourRectStep(tourStep);
      setTourOutlineRects(outlineRects);
      setTouchpadRect({ top: padRect.top, left: padRect.left, width: padRect.width, height: padRect.height });
    };
    const timer = window.setTimeout(updateTourRect, 80);
    const handleScroll = (event: Event) => {
      const scrollTarget = event.target;
      if (tourStep === 9 && scrollTarget instanceof Element && scrollTarget.closest('.app-shortcuts-native-scroll')) return;
      updateTourRect();
    };
    window.addEventListener('resize', updateTourRect);
    window.addEventListener('scroll', handleScroll, true);
    return () => { window.clearTimeout(timer); window.removeEventListener('resize', updateTourRect); window.removeEventListener('scroll', handleScroll, true); };
  }, [tourStep, showOnboarding, isSettingsOpen, isKeyboardOpen, isVoiceOpen]);

  useEffect(() => {
    configureFeedback({ soundEnabled: settings.soundFeedback, hapticEnabled: settings.hapticFeedback });
  }, [settings.soundFeedback, settings.hapticFeedback]);

  useEffect(() => {
    const onFound = (event: Event) => {
      try {
        if (!(window as any).AndroidBridge?.isWifiConnected?.()) return;
        const raw = JSON.parse((event as CustomEvent).detail || '{}');
        const paired = Boolean((window as any).AndroidBridge?.isHostPaired?.(raw.ip));
        const device: TvDevice = { id: `native-${raw.ip}`, name: raw.name || `TV ${raw.ip}`, type: raw.protocol === 'google_tv_cast' ? 'google_tv' : 'android_tv', ip: raw.ip, port: raw.port || 6467, protocol: raw.protocol || 'android_tv_v2', isOnline: false, paired };
        setDevices(prev => prev.some(d => d.ip === device.ip)
          ? prev.map(d => d.ip === device.ip ? { ...d, ...device, isOnline: d.isOnline || device.isOnline, paired: d.paired || device.paired } : d)
          : [...prev, device].slice(0, 10));
        setCurrentDevice(prev => prev.ip === device.ip ? { ...prev, ...device, isOnline: prev.isOnline } : prev);
      } catch {}
    };
    const onConnected = (event: Event) => { const host = String((event as CustomEvent).detail || '').trim(); setDevices(prev => prev.map(d => d.ip === host ? { ...d, isOnline: true, paired: true } : d)); setCurrentDevice(prev => prev.ip === host || prev.id === 'none' ? { ...prev, id: `saved-${host}`, ip: host, isOnline: true, paired: true } : prev); setTvPickerDismissed(true); };
    const onDisconnected = (event: Event) => { const host = String((event as CustomEvent).detail || '').trim(); setDevices(prev => host ? prev.filter(device => device.ip !== host) : []); setCurrentDevice(prev => !host || prev.ip === host ? { ...prev, isOnline: false } : prev); };
    const onVolumeStatus = (event: Event) => { try { const status = JSON.parse((event as CustomEvent).detail || '{}'); if (Number.isFinite(status.level)) { const maximum = Number(status.maximum); const normalized = Number.isFinite(maximum) && maximum > 0 ? Math.round((status.level / maximum) * 15) : Math.round(status.level); setTvStatus(prev => ({ ...prev, volume: Math.max(0, Math.min(15, normalized)), muted: Boolean(status.muted) })); } } catch {} };
    const onMouseHidStatus = (event: Event) => setMouseHidStatus(String((event as CustomEvent).detail || 'starting'));
    const onWifiStatus = (event: Event) => {
      try {
        const wifi = Boolean(JSON.parse((event as CustomEvent).detail || '{}').wifi);
        setWifiConnected(wifi);
        if (!wifi) {
          setCurrentDevice(prev => prev.ip && prev.isOnline ? { ...prev, isOnline: false } : prev);
          setDevices(prev => prev.length ? [] : prev);
        }
      } catch {}
    };
    window.addEventListener('nativeDeviceFound', onFound); window.addEventListener('nativeConnected', onConnected); window.addEventListener('nativePaired', onConnected); window.addEventListener('nativeDisconnected', onDisconnected); window.addEventListener('nativeVolumeStatus', onVolumeStatus); window.addEventListener('nativeWifiStatus', onWifiStatus); window.addEventListener('nativeMouseHidStatus', onMouseHidStatus);
    (window as any).AndroidBridge?.onWebViewReady?.();
    return () => { window.removeEventListener('nativeDeviceFound', onFound); window.removeEventListener('nativeConnected', onConnected); window.removeEventListener('nativePaired', onConnected); window.removeEventListener('nativeDisconnected', onDisconnected); window.removeEventListener('nativeVolumeStatus', onVolumeStatus); window.removeEventListener('nativeWifiStatus', onWifiStatus); window.removeEventListener('nativeMouseHidStatus', onMouseHidStatus); };
  }, []);

  useEffect(() => {
    const syncConnectionState = () => {
      const bridge = (window as any).AndroidBridge;
      const wifi = Boolean(bridge?.isWifiConnected?.());
      setWifiConnected(prev => prev === wifi ? prev : wifi);
      if (!wifi) {
        setCurrentDevice(prev => prev.ip && prev.isOnline ? { ...prev, isOnline: false } : prev);
        setDevices(prev => prev.length ? [] : prev);
        return;
      }
      const connectedHost = String(bridge?.getConnectedHost?.() || '').trim();
      setCurrentDevice(prev => {
        if (!prev.ip) return prev;
        const online = prev.ip === connectedHost;
        return prev.isOnline === online ? prev : { ...prev, isOnline: online };
      });
      setDevices(prev => prev.map(device => {
        const online = Boolean(connectedHost) && device.ip === connectedHost;
        return device.isOnline === online ? device : { ...device, isOnline: online };
      }));
    };
    syncConnectionState();
    const timer = window.setInterval(syncConnectionState, 1000);
    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    const onTvImeShowRequested = (event: Event) => {
      if (isKeyboardOpen) return;
      setKeyboardInitialText(String((event as CustomEvent).detail || ''));
      setIsKeyboardOpen(true);
    };
    window.addEventListener('nativeImeShowRequested', onTvImeShowRequested);
    window.addEventListener('nativeImeText', onTvImeShowRequested);
    return () => {
      window.removeEventListener('nativeImeShowRequested', onTvImeShowRequested);
      window.removeEventListener('nativeImeText', onTvImeShowRequested);
    };
  }, [isKeyboardOpen]);

  const requestBackOrExit = useCallback(() => {
    if (isExitConfirmationOpen) { setIsExitConfirmationOpen(false); return; }
    if (isVoiceOpen) { setIsVoiceOpen(false); return; }
    if (isKeyboardOpen) { setIsKeyboardOpen(false); setKeyboardInitialText(''); return; }
    if (isSettingsOpen) { setIsSettingsOpen(false); return; }
    if (showOnboarding) { setShowOnboarding(false); return; }
    setIsExitConfirmationOpen(true);
  }, [isExitConfirmationOpen, isVoiceOpen, isKeyboardOpen, isSettingsOpen, showOnboarding]);

  useEffect(() => {
    window.addEventListener('androidBackPressed', requestBackOrExit);
    return () => window.removeEventListener('androidBackPressed', requestBackOrExit);
  }, [requestBackOrExit]);

  useEffect(() => {
    let swipeStart: { x: number; y: number } | null = null;
    const onTouchStart = (event: TouchEvent) => {
      const touch = event.touches[0];
      if (!touch) return;
      if (touch.clientX <= 28 || touch.clientX >= window.innerWidth - 28) {
        swipeStart = { x: touch.clientX, y: touch.clientY };
      } else {
        swipeStart = null;
      }
    };
    const onTouchEnd = (event: TouchEvent) => {
      const start = swipeStart;
      swipeStart = null;
      const touch = event.changedTouches[0];
      if (!start || !touch) return;
      const dx = touch.clientX - start.x;
      const dy = touch.clientY - start.y;
      const fromLeft = start.x <= 28 && dx >= 100;
      const fromRight = start.x >= window.innerWidth - 28 && dx <= -100;
      if ((fromLeft || fromRight) && Math.abs(dy) < 80) requestBackOrExit();
    };
    const onTouchCancel = () => { swipeStart = null; };
    document.addEventListener('touchstart', onTouchStart, { passive: true });
    document.addEventListener('touchend', onTouchEnd, { passive: true });
    document.addEventListener('touchcancel', onTouchCancel, { passive: true });
    return () => {
      document.removeEventListener('touchstart', onTouchStart);
      document.removeEventListener('touchend', onTouchEnd);
      document.removeEventListener('touchcancel', onTouchCancel);
    };
  }, [requestBackOrExit]);

  // Command feedback toast
  const [commandFeedback, setCommandFeedback] = useState<string | null>(null);
  const [feedbackTimer, setFeedbackTimer] = useState<NodeJS.Timeout | null>(null);

  // Simulated TV Status
  const [tvStatus, setTvStatus] = useState<TvStatus>({
    power: true,
    volume: 8,
    muted: false,
    isPlaying: true,
    playbackPosition: 145,
    playbackDuration: 600,
    currentChannel: 14,
    channelName: 'MBC Action HD',
    currentApp: 'YouTube',
    currentMediaTitle: 'أغاني بيبي أطفال - طيور بيبي HD',
    selectedNavIndex: 0,
    lastCommand: null,
    lastCommandTimestamp: 0,
  });

  // Advance video playback time when playing
  useEffect(() => {
    if (!tvStatus.power || !tvStatus.isPlaying) return;
    const interval = setInterval(() => {
      setTvStatus((prev) => {
        if (!prev.power || !prev.isPlaying) return prev;
        const nextPos = prev.playbackPosition >= prev.playbackDuration ? 0 : prev.playbackPosition + 1;
        return { ...prev, playbackPosition: nextPos };
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [tvStatus.power, tvStatus.isPlaying]);

  const refreshMouseHidDevices = useCallback(() => {
    try {
      const raw = (window as any).AndroidBridge?.getBondedBluetoothDevices?.() || '[]';
      const parsed = JSON.parse(raw);
      setMouseHidDevices(Array.isArray(parsed) ? parsed.filter((device: any) => device?.address) : []);
    } catch { setMouseHidDevices([]); }
  }, []);

  // Command feedback is intentionally disabled for a clean remote surface.
  const triggerFeedback = useCallback((_msg: string) => {}, []);

  // Command handler
  const handleCommand = useCallback(
    (key: RemoteKey, longPress = false) => {
      if (key !== 'KEYBOARD') (window as any).AndroidBridge?.sendRemoteKey?.(key, longPress);
      setTvStatus((prev) => {
        const next = { ...prev, lastCommand: key, lastCommandTimestamp: Date.now() };

        switch (key) {
          case 'POWER':
            next.power = !prev.power;
            triggerFeedback(next.power ? (isAr ? 'تشغيل التلفاز' : 'TV Turned ON') : (isAr ? 'إطفاء التلفاز (وضع الاستعداد)' : 'TV Standby / OFF'));
            break;
          case 'VOLUME_UP':
            next.volume = Math.min(15, prev.volume + 1);
            next.muted = false;
            triggerFeedback(`${isAr ? 'رفع الصوت' : 'Volume Up'} (${next.volume}%)`);
            break;
          case 'VOLUME_DOWN':
            next.volume = Math.max(0, prev.volume - 1);
            next.muted = false;
            triggerFeedback(`${isAr ? 'خفض الصوت' : 'Volume Down'} (${next.volume}%)`);
            break;
          case 'VOLUME_MUTE':
            next.muted = !prev.muted;
            triggerFeedback(next.muted ? (isAr ? 'كتم الصوت 🔇' : 'Muted 🔇') : `${isAr ? 'إلغاء الكتم' : 'Unmuted'} (${next.volume}%)`);
            break;
          case 'SEEK_FORWARD':
            next.playbackPosition = Math.min(prev.playbackDuration, prev.playbackPosition + 10);
            triggerFeedback(isAr ? 'تقديم الفيديو (+10 ثوانٍ) ⏩' : 'Fast Forward (+10s) ⏩');
            break;
          case 'REWIND_FAST':
            next.playbackPosition = Math.max(0, prev.playbackPosition - 30);
            triggerFeedback(isAr ? 'ترجيع سريع (-30 ثانية) ⏪' : 'Rewind (-30s) ⏪');
            break;
          case 'FORWARD_FAST':
            next.playbackPosition = Math.min(prev.playbackDuration, prev.playbackPosition + 30);
            triggerFeedback(isAr ? 'تقديم سريع (+30 ثانية) ⏩' : 'Forward (+30s) ⏩');
            break;
          case 'PLAY_PAUSE':
            next.isPlaying = !prev.isPlaying;
            triggerFeedback(next.isPlaying ? (isAr ? 'تشغيل الفيديو ▶' : 'Play Video ▶') : (isAr ? 'إيقاف مؤقت ⏸' : 'Pause Video ⏸'));
            break;
          case 'CHANNEL_UP':
            next.currentChannel = (prev.currentChannel % 50) + 1;
            triggerFeedback(`${isAr ? 'القناة التالية' : 'Next Channel'} (${next.currentChannel})`);
            break;
          case 'CHANNEL_DOWN':
            next.currentChannel = prev.currentChannel > 1 ? prev.currentChannel - 1 : 50;
            triggerFeedback(`${isAr ? 'القناة السابقة' : 'Prev Channel'} (${next.currentChannel})`);
            break;
          case 'CHANNEL_LIST':
            triggerFeedback(isAr ? 'تم فتح دليل القنوات' : 'Channel Guide Opened');
            break;
          case 'DPAD_RIGHT':
            next.selectedNavIndex = (prev.selectedNavIndex + 1) % 5;
            triggerFeedback(isAr ? 'تنقل لليمين ►' : 'Navigate Right ►');
            break;
          case 'DPAD_LEFT':
            next.selectedNavIndex = (prev.selectedNavIndex + 4) % 5;
            triggerFeedback(isAr ? 'تنقل لليسار ◄' : 'Navigate Left ◄');
            break;
          case 'DPAD_UP':
            triggerFeedback(isAr ? 'تنقل للأعلى ▲' : 'Navigate Up ▲');
            break;
          case 'DPAD_DOWN':
            triggerFeedback(isAr ? 'تنقل للأسفل ▼' : 'Navigate Down ▼');
            break;
          case 'DPAD_CENTER':
            triggerFeedback(isAr ? 'تحديد واختيار ◉' : 'Select / OK ◉');
            break;
          case 'HOME':
            next.selectedNavIndex = 0;
            triggerFeedback(isAr ? 'الشاشة الرئيسية ⌂' : 'Home Screen ⌂');
            break;
          case 'BACK':
            triggerFeedback(isAr ? 'رجوع ↩' : 'Back ↩');
            break;
          case 'MENU':
            triggerFeedback(isAr ? 'خيارات القائمة ≡' : 'Menu Options ≡');
            break;
          case 'SETTINGS':
            setIsSettingsOpen(true);
            break;
          case 'KEYBOARD':
            setKeyboardInitialText('');
            setIsKeyboardOpen(true);
            break;
          case 'MIC':
            break;
        }
        return next;
      });
    },
    [triggerFeedback, isAr]
  );

  const volumeRepeatRef = useRef<number | null>(null);
  const startVolumeHold = (key: RemoteKey) => {
    if (volumeRepeatRef.current !== null) window.clearInterval(volumeRepeatRef.current);
    handleCommand(key);
    volumeRepeatRef.current = window.setInterval(() => handleCommand(key), 140);
  };
  const stopVolumeHold = () => { if (volumeRepeatRef.current !== null) { window.clearInterval(volumeRepeatRef.current); volumeRepeatRef.current = null; } };

  // Handle pairing submit
  const handlePairCodeSubmit = async (code: string): Promise<boolean> => {
    return await new Promise<boolean>((resolve) => {
      let settled = false;
      const finish = (success: boolean) => {
        if (settled) return;
        settled = true;
        window.removeEventListener('nativeConnected', onConnected);
        window.removeEventListener('nativePaired', onPaired);
        window.removeEventListener('nativeError', onError);
        window.clearTimeout(timeout);
        if (success) triggerFeedback(`${t.tvPairedSuccess}`);
        resolve(success);
      };
      const matchesCurrentDevice = (event: Event) => {
        const eventHost = String((event as CustomEvent).detail || '').trim();
        return !eventHost || !currentDevice.ip || eventHost === currentDevice.ip;
      };
      const onConnected = (event: Event) => { if (matchesCurrentDevice(event)) finish(true); };
      const onPaired = (event: Event) => { if (matchesCurrentDevice(event)) finish(true); };
      const onError = () => finish(false);
      window.addEventListener('nativeConnected', onConnected);
      window.addEventListener('nativePaired', onPaired);
      window.addEventListener('nativeError', onError);
      // Pairing is asynchronous; keep the dialog open while the native bridge
      // queues an early code or waits for the TV to answer.
      const timeout = window.setTimeout(() => finish(false), 45000);
      (window as any).AndroidBridge?.providePairingCode?.(code);
    });
  };

  // Keyboard text sending
  const handleSendText = (insertedText: string, removedText: string, start: number, end: number) => {
    const bridge = (window as any).AndroidBridge;
    if (typeof bridge?.sendTextEdit === 'function') bridge.sendTextEdit(insertedText, removedText, start, end);
    else if (insertedText) bridge?.sendText?.(insertedText);
  };

  const handleSendKey = (key: string) => {
    if (key === 'ENTER') (window as any).AndroidBridge?.sendEnter?.();
    else if (key === 'BACKSPACE') (window as any).AndroidBridge?.sendRemoteKey?.('KEYBOARD', false);
    else if (key === 'SPACE') (window as any).AndroidBridge?.sendText?.(' ');
    triggerFeedback(`${t.sentKey}: ${key}`);
  };

  // Voice command sending
  const handleSendVoiceQuery = (query: string) => {
    (window as any).AndroidBridge?.sendText?.(query);
    triggerFeedback(`${t.voiceCommand}: "${query}"`);
  };

  // Launch YouTube Kids keyword
  const handleKeywordLaunch = (query: string) => {
    setTvStatus((prev) => ({
      ...prev,
      power: true,
      currentApp: 'YouTube',
      isPlaying: true,
      currentMediaTitle: query,
      playbackPosition: 0,
      lastCommand: `${isAr ? 'تشغيل على يوتيوب' : 'Playing on YouTube'}: "${query}"`,
      lastCommandTimestamp: Date.now(),
    }));
    triggerFeedback(`${t.launchingOnYoutube}: "${query}" 📺`);
  };

  if (showOnboarding) {
    return <Onboarding onFinish={() => setShowOnboarding(false)} />;
  }

  const tourPanelWidth = touchpadRect ? Math.min(220, Math.max(180, touchpadRect.width - 24)) : 210;
  const tourPanelLeft = touchpadRect ? touchpadRect.left + (touchpadRect.width - tourPanelWidth) / 2 : 12;
  const tourPanelTop = touchpadRect ? touchpadRect.top + Math.min(150, Math.max(84, touchpadRect.height * 0.32)) : 12;
  // Keep the touchpad's built-in orange contour without adding a second tour frame.
  const tourHighlightRect = tourStep === 0 ? touchpadRect : tourRect;

  return (
    <div
      className={`h-[100dvh] overflow-hidden ${settings.theme === 'light' ? 'theme-light' : ''} bg-[#2A2A2A] text-white flex flex-col items-center justify-center p-0 sm:p-4 md:p-6 font-sans`}
      dir={isAr ? 'rtl' : 'ltr'}
      style={{ backgroundColor: settings.interfaceColors.interface, '--interface-color': settings.interfaceColors.interface, '--button-color': settings.interfaceColors.buttons, '--button-icon-color': settings.interfaceColors.buttonIcons, '--touch-area-color': settings.interfaceColors.touchArea, '--border-color': settings.interfaceColors.border } as React.CSSProperties}
    >
      {/* Remote Container - Exactly matching the look and proportions of the user's photo */}
        <main data-customizer-surface className="remote-interface relative w-full max-w-[410px] h-full min-h-0 max-h-full bg-[#2A2A2A] sm:rounded-[44px] shadow-2xl sm:border sm:border-black/15 flex flex-col justify-between overflow-hidden" style={{ backgroundColor: settings.interfaceColors.interface }}>
        {/* Subtle background gradient to mimic premium remote plastic casing */}
        <div
          className="absolute inset-0 bg-cover bg-center pointer-events-none"
          style={{
            backgroundColor: settings.interfaceColors.interface,
            backgroundImage: "url('/remote-background.png')",
            backgroundBlendMode: 'soft-light',
          }}
        />

        {/* Top device picker only; no simulated TV information bar */}
        <div data-tour="search" className="w-full flex flex-col items-center pt-2">
          {!customizeMode && !isSettingsOpen && !isKeyboardOpen && !isVoiceOpen && (
            <DeviceStrip
              currentDevice={currentDevice}
              wifiConnected={wifiConnected}
              devices={devices}
              onSelectDevice={(device) => {
                setTvPickerDismissed(false);
                setCurrentDevice({ ...device, isOnline: false });
                if (!device.paired) (window as any).AndroidBridge?.startPairing?.(device.ip);
              }}
              onOpenAddDevice={() => { setTvPickerDismissed(false); (window as any).AndroidBridge?.startDiscovery?.(); }}
              onOpenPicker={() => setTvPickerDismissed(false)}
              onStartDiscovery={() => (window as any).AndroidBridge?.startDiscovery?.()}
              onReconnect={(d) => { (window as any).AndroidBridge?.connect?.(d.ip); setTvPickerDismissed(false); setCurrentDevice({ ...d, isOnline: false }); setDevices(prev => prev.map(item => item.id === d.id ? { ...item, isOnline: false } : item)); }}
              onDisconnect={(d) => { (window as any).AndroidBridge?.disconnect?.(); setCurrentDevice(prev => prev.id === d.id ? { ...prev, isOnline: false } : prev); setDevices(prev => prev.map(item => item.id === d.id ? { ...item, isOnline: false } : item)); }}
              onPairCodeSubmit={handlePairCodeSubmit}
              language={currentLang}
              fullScreen={!tvPickerDismissed && tourStep === null}
              onSkipPicker={() => setTvPickerDismissed(true)}
            />
          )}
          <div
            className="w-12 h-1 rounded-full bg-white/10 shadow-inner mb-1"
            title={t.irTransmitter}
          />

          {!customizeMode && !isSettingsOpen && !isKeyboardOpen && !isVoiceOpen && <div data-tour="apps"><AppFavoritesBar language={currentLang} tutorialHighlightActive={tourStep === 9} onOpenApp={(app) => (window as any).AndroidBridge?.openApp?.(app.deepLink, null)} /></div>}

        </div>

        {/* Floating Command Feedback Toast HUD */}
        {commandFeedback && (
          <div className="absolute top-12 left-1/2 -translate-x-1/2 z-40 px-3.5 py-1.5 rounded-full bg-black/80 backdrop-blur-md border border-white/15 text-xs font-mono font-medium text-[#2997ff] shadow-lg animate-in fade-in zoom-in-95 duration-150 flex items-center gap-1.5 pointer-events-none">
            <span className="w-1.5 h-1.5 rounded-full bg-[#2997ff] animate-ping" />
            <span>{commandFeedback}</span>
          </div>
        )}

        {customizeMode && (
          <div className="absolute top-3 left-1/2 -translate-x-1/2 z-[60] flex items-center justify-center gap-2 rounded-xl border border-[#ff421a]/60 bg-[#17191d]/95 p-1.5 shadow-xl backdrop-blur-md" dir={isAr ? 'rtl' : 'ltr'}>
            <button type="button" onClick={() => { setCustomizeMode(false); setSelectedCustomizeId(null); }} className="rounded-lg bg-[#ff421a] px-3 py-1 text-[11px] font-bold leading-5 whitespace-nowrap">{isAr ? 'حفظ' : 'Save'}</button>
          <button type="button" onClick={() => { setButtonLayouts({}); try { window.localStorage.removeItem('smart-remote-button-layouts-swapped-audio-mic-v3'); window.localStorage.removeItem('smart-remote-button-layouts-original-v1'); window.localStorage.removeItem('smart-remote-button-layouts-v2'); window.localStorage.removeItem('smart-remote-button-layouts'); } catch {} }} className="rounded-lg border border-white/20 bg-white/10 px-3 py-1 text-[11px] font-semibold leading-5 text-white/80 whitespace-nowrap">{isAr ? 'إعادة الافتراضي' : 'Reset'}</button>
          </div>
        )}

        {/* Main Central Section: Surrounding Buttons & Touchpad with Red Dashed Band */}
        <div data-tour="controls" className="pointer-events-none absolute inset-0 z-10">
          <div data-customizer-area className="pointer-events-none absolute inset-0 h-full w-full">
            {/* Touchpad Area with the Red Dashed Contour from the image */}
            <CustomizableBar id="touchpad" layout={buttonLayouts.touchpad || { x: 50, y: 50, size: 100, width: 100, height: 100 }} onChange={(layout) => updateButtonLayouts({ touchpad: layout })} editMode={customizeMode} selected={selectedCustomizeId === 'touchpad'} onSelect={setSelectedCustomizeId} baseWidth={360} baseHeight={470} offsetY={55} centralHandle>
              <Touchpad onCommand={handleCommand} sensitivity={3} mouseSpeed={settings.mouseSpeed} wifiConnected={wifiConnected} showTourOutline={tourStep === 0} mouseMode={false} mouseInvertY={settings.mouseInvertY} />
            </CustomizableBar>

            {/* The 6 Round Surrounding Buttons directly mapped to touchpad bounds */}
            <SurroundingButtons
              onCommand={handleCommand}
              isListening={false}
              isTvPowerOn={tvStatus.power}
              isMuted={tvStatus.muted}
              language={currentLang}
              onVoiceQuery={handleSendVoiceQuery}
              editMode={customizeMode}
              layouts={buttonLayouts}
              onLayoutsChange={updateButtonLayouts}
              selectedId={selectedCustomizeId}
              onSelect={setSelectedCustomizeId}
            />

          </div>
        </div>

        {/* Video bar is positioned relative to the whole remote, not the touchpad area. */}
        <div data-tour="media">
        <CustomizableBar id="videoBar" layout={buttonLayouts.videoBar || { x: 50, y: 15, size: 100, width: 100, height: 100 }} onChange={(layout) => updateButtonLayouts({ videoBar: layout })} editMode={customizeMode} selected={selectedCustomizeId === 'videoBar'} onSelect={setSelectedCustomizeId} baseWidth={180} baseHeight={62} offsetX={-5} offsetY={110}>
          <ModernControlsBar onCommand={handleCommand} language={currentLang} isPlaying={tvStatus.isPlaying} />
        </CustomizableBar>
        </div>

        {/* Volume rocker: circular press targets with VOL fixed in the center. */}
        <div data-tour="volume">
        <CustomizableBar id="audioBar" layout={buttonLayouts.audioBar || { x: 3, y: 76.6, size: 100, width: 100, height: 100 }} onChange={(layout) => updateButtonLayouts({ audioBar: layout })} editMode={customizeMode} selected={selectedCustomizeId === 'audioBar'} onSelect={setSelectedCustomizeId} baseWidth={58.5} baseHeight={190} offsetX={30} offsetY={65}>
          <div className="relative flex h-full w-full flex-col items-center justify-center overflow-hidden rounded-[32px] border border-white/20 bg-[#4f5456]/85 shadow-md">
            <FluidVolumeBar volume={tvStatus.muted ? 0 : tvStatus.volume} color={settings.interfaceColors.border} />
            <div role="button" tabIndex={0} aria-label={isAr ? 'رفع الصوت' : 'Volume up'} onPointerDown={() => startVolumeHold('VOLUME_UP')} onPointerUp={stopVolumeHold} onPointerCancel={stopVolumeHold} onPointerLeave={stopVolumeHold} className="group relative z-10 flex min-h-0 flex-1 w-full touch-manipulation items-center justify-center text-white"><span className="flex h-16 w-16 items-center justify-center rounded-full text-3xl font-extralight leading-none transition-transform group-active:scale-95 group-active:bg-white/15" style={{ transform: 'translateY(-20px)' }}>+</span></div>
            <span className="pointer-events-none absolute inset-0 z-20 flex items-center justify-center select-none text-[9px] font-mono font-bold tracking-wide text-white/75">VOL</span>
            <div role="button" tabIndex={0} aria-label={isAr ? 'خفض الصوت' : 'Volume down'} onPointerDown={() => startVolumeHold('VOLUME_DOWN')} onPointerUp={stopVolumeHold} onPointerCancel={stopVolumeHold} onPointerLeave={stopVolumeHold} className="group relative z-10 flex min-h-0 flex-1 w-full touch-manipulation items-center justify-center text-white"><span className="flex h-16 w-16 items-center justify-center rounded-full text-3xl font-extralight leading-none transition-transform group-active:scale-95 group-active:bg-white/15" style={{ transform: 'translateY(20px)' }}>−</span></div>
          </div>
        </CustomizableBar>
        </div>

      </main>

      {/* Settings & Connection Libraries Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        devices={devices}
        currentDevice={currentDevice}
        onSelectDevice={setCurrentDevice}
        onUpdateDevice={(updated) => {
          setDevices((prev) => prev.map((d) => (d.id === updated.id ? updated : d)));
          setCurrentDevice(updated);
        }}
        settings={settings}
        mouseHidStatus={mouseHidStatus}
        mouseHidDevices={mouseHidDevices}
        onStartMouseHid={() => (window as any).AndroidBridge?.startMouseHidPairing?.()}
        onRefreshMouseHidDevices={refreshMouseHidDevices}
        onConnectMouseHidDevice={(address) => (window as any).AndroidBridge?.connectMouseHost?.(address)}
        onUpdateSettings={(newSettings) => setSettings((prev) => {
          const next = { ...prev, ...newSettings };
          if (typeof newSettings.mouseSpeed === 'number') {
            try { window.localStorage.setItem('smart-remote-bluetooth-mouse-speed-v1', String(newSettings.mouseSpeed)); } catch {}
          }
          return next;
        })}
        onPairCodeSubmit={handlePairCodeSubmit}
        onOpenCustomizer={() => { setIsSettingsOpen(false); setCustomizeMode(true); }}
      />

      {/* Keyboard Input Modal */}
      <KeyboardModal
        isOpen={isKeyboardOpen}
        initialText={keyboardInitialText}
        onClose={() => { setIsKeyboardOpen(false); setKeyboardInitialText(''); }}
        onSendText={handleSendText}
        onSendKey={handleSendKey}
        language={currentLang}
      />

      {/* Voice Assistant Modal */}
      <VoiceModal
        isOpen={isVoiceOpen}
        onClose={() => setIsVoiceOpen(false)}
        onSendVoiceQuery={handleSendVoiceQuery}
        language={currentLang}
      />

      {isExitConfirmationOpen && (
        <div className="fixed inset-0 z-[250] flex items-center justify-center bg-black/75 p-5 backdrop-blur-sm" dir={isAr ? 'rtl' : 'ltr'}>
          <section role="dialog" aria-modal="true" aria-labelledby="exit-confirmation-title" className="w-full max-w-[360px] rounded-3xl border border-white/10 bg-[#1b1e22] p-5 text-white shadow-2xl">
            <h2 id="exit-confirmation-title" className="text-center text-lg font-black">{isAr ? 'هل تود المغادرة؟' : 'Do you want to exit?'}</h2>
            <div className="mt-5 grid grid-cols-2 gap-3" dir="ltr">
              <button type="button" onClick={() => (window as any).AndroidBridge?.exitApp?.()} className="min-h-12 rounded-xl bg-[#ff421a] text-sm font-black text-white">{isAr ? 'نعم' : 'Yes'}</button>
              <button type="button" onClick={() => setIsExitConfirmationOpen(false)} className="min-h-12 rounded-xl border border-white/15 bg-white/[.06] text-sm font-bold text-white/85">{isAr ? 'لا' : 'No'}</button>
            </div>
          </section>
        </div>
      )}

      {tourStep !== null && !showOnboarding && !isSettingsOpen && !isKeyboardOpen && !isVoiceOpen && tourHighlightRect && (
        <div
          role="button"
          tabIndex={0}
          aria-label={isAr ? 'التالي' : 'Next'}
          onClick={advanceTour}
          onKeyDown={(event) => { if (event.key === 'Enter' || event.key === ' ') advanceTour(); }}
          className="pointer-events-none fixed inset-0 z-[210] bg-black/35"
          dir={isAr ? 'rtl' : 'ltr'}
        >
          {tourRectStep === tourStep && tourStep !== 0 && tourOutlineRects.map((outlineRect, index) => (
            <div
              key={`tour-outline-${tourStep}-${index}`}
              aria-hidden="true"
              className="pointer-events-none fixed tour-highlight-outline"
              style={{
                top: outlineRect.top,
                left: outlineRect.left,
                width: outlineRect.width,
                height: outlineRect.height,
                borderRadius: outlineRect.borderRadius,
              }}
            />
          ))}
          <div
            className="pointer-events-auto fixed aspect-square rounded-xl border border-[#ff8b72]/70 bg-[#17191d]/[.98] p-3 text-white shadow-2xl"
            style={{
              left: tourPanelLeft,
              top: tourPanelTop,
              width: tourPanelWidth,
            }}
            onClick={(event) => event.stopPropagation()}
          >
            <div className="mb-1 text-[10px] font-bold text-[#ff8b72]">{`${(tourStep ?? 0) + 1} / ${tourSteps.length}`}</div>
            <h2 className="text-sm font-black leading-5">{tourSteps[tourStep].title}</h2>
            <p className="mt-1.5 text-[12px] font-semibold leading-5 text-white/80">{tourSteps[tourStep].text}</p>
            <button type="button" onClick={advanceTour} className="mt-2 w-full rounded-lg bg-[#ff421a] py-2 text-xs font-black">
              {tourStep === tourSteps.length - 1 ? (isAr ? 'إنهاء' : 'Finish') : (isAr ? 'التالي' : 'Next')}
            </button>
            <p className="mt-1 text-center text-[9px] text-white/45">{isAr ? 'اضغط للمتابعة' : 'Tap to continue'}</p>
          </div>
        </div>
      )}

    </div>
  );
}
