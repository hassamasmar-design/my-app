/**
 * Audio and haptic feedback shared by every remote control.
 * The supplied immersive-control click is preferred; Web Audio remains as a
 * fallback for browsers/WebViews that cannot decode the bundled file.
 */
const audioPool: HTMLAudioElement[] = [];
let audioCursor = 0;
let fallbackContext: AudioContext | null = null;
let lastClickAt = 0;
let soundEnabled = true;
let hapticEnabled = true;

export function configureFeedback(preferences: { soundEnabled?: boolean; hapticEnabled?: boolean }) {
  if (typeof preferences.soundEnabled === 'boolean') soundEnabled = preferences.soundEnabled;
  if (typeof preferences.hapticEnabled === 'boolean') hapticEnabled = preferences.hapticEnabled;
  if (!hapticEnabled && typeof navigator !== 'undefined' && 'vibrate' in navigator) {
    try { navigator.vibrate(0); } catch { /* optional */ }
  }
}

function getAudioFromPool(): HTMLAudioElement | null {
  if (typeof window === 'undefined' || typeof Audio === 'undefined') return null;
  if (audioPool.length === 0) {
    for (let index = 0; index < 8; index += 1) {
      const audio = new Audio('/button-click.mp3');
      audio.preload = 'auto';
      audio.volume = 0.72;
      audioPool.push(audio);
    }
  }
  const audio = audioPool[audioCursor % audioPool.length];
  audioCursor += 1;
  return audio;
}

function playFallback(type: 'tap' | 'swipe' | 'button' | 'home' | 'power' | 'seek') {
  try {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;
    if (!fallbackContext) fallbackContext = new AudioContextClass();
    const ctx = fallbackContext;
    if (ctx.state === 'suspended') void ctx.resume();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    const now = ctx.currentTime;
    const duration = type === 'power' ? 0.12 : type === 'home' ? 0.1 : 0.055;
    osc.type = type === 'swipe' ? 'triangle' : 'sine';
    osc.frequency.setValueAtTime(type === 'home' ? 520 : 420, now);
    osc.frequency.exponentialRampToValueAtTime(type === 'power' ? 150 : 180, now + duration);
    gain.gain.setValueAtTime(0.11, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + duration);
    osc.start(now);
    osc.stop(now + duration);
  } catch {
    // Audio is optional and must never interrupt remote commands.
  }
}

export function playRemoteClick(type: 'tap' | 'swipe' | 'button' | 'home' | 'power' | 'seek' = 'button') {
  if (!soundEnabled) return;
  const now = typeof performance !== 'undefined' ? performance.now() : Date.now();
  // Prevent duplicate sound when a button has both its own feedback and the
  // global button listener.
  if (now - lastClickAt < 28) return;
  lastClickAt = now;
  try {
    const audio = getAudioFromPool();
    if (audio) {
      audio.currentTime = 0;
      const result = audio.play();
      if (result) result.catch(() => playFallback(type));
      return;
    }
  } catch {
    // Use the lightweight fallback below.
  }
  playFallback(type);
}

export function triggerHaptic(duration = 15) {
  if (hapticEnabled && typeof window !== 'undefined' && 'vibrate' in navigator) {
    try { navigator.vibrate(duration); } catch { /* optional */ }
  }
}

export function installGlobalButtonSound(enabled = true) {
  if (typeof document === 'undefined') return () => {};
  const onClick = (event: MouseEvent) => {
    const target = event.target as HTMLElement | null;
    if (enabled && target?.closest('button,[role="button"]')) playRemoteClick('button');
  };
  document.addEventListener('click', onClick, true);
  return () => document.removeEventListener('click', onClick, true);
}
