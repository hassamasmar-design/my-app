export type Language = 'ar' | 'en';

export interface Translations {
  // App & Remote
  appTitle: string;
  irTransmitter: string;
  remoteNotice: string;
  tvPowerOn: string;
  tvPowerOff: string;
  tvStandbyEmpty: string;
  nowPlaying: string;
  paused: string;
  live: string;
  noMediaPlaying: string;
  
  // Controls
  powerTitleOn: string;
  powerTitleOff: string;
  settingsTitle: string;
  keyboardTitle: string;
  micTitle: string;
  homeTitle: string;
  backTitle: string;
  fastForwardTitle: string;
  fastForwardLabel: string;
  
  // Status Bar & Keywords
  youtubeKids: string;
  babySongs: string;
  birdsOfParadise: string;
  supermanKids: string;
  mashaAndBear: string;
  
  // Feedback
  voiceCommand: string;
  sentKey: string;
  sentText: string;
  tvPairedSuccess: string;
  launchingOnYoutube: string;
  
  // Settings & Modal
  settings: string;
  language: string;
  switchLangNotice: string;
  connection: string;
  libraries: string;
  preferences: string;
  remoteInterfacesTab: string;
  switchDevice: string;
  online: string;
  offline: string;
  paired: string;
  pairTv: string;
  enterPinCode: string;
  sensitivity: string;
  hapticFeedback: string;
  soundFeedback: string;
  close: string;
  
  // Remote Skins & Interfaces
  remoteSkinTitle: string;
  remoteSkinDesc: string;
  skinFireTv: string;
  skinSamsung: string;
  skinLgMagic: string;
  skinAppleTv: string;
  skinAndroidDpad: string;

  // Simulator
  tvSimulator: string;
  tvScreen: string;
  chooseTv: string;
  searchingTv: string;
  sameWifiHint: string;
  connected: string;
  reconnect: string;
  disconnect: string;
  pairingCode: string;
  confirmCode: string;
  theme: string;
  darkTheme: string;
  lightTheme: string;
}

export const translations: Record<Language, Translations> = {
  ar: {
    appTitle: 'ريموت التلفاز الذكي',
    irTransmitter: 'مرسل الأشعة تحت الحمراء',
    remoteNotice: 'ريموت متطور للتحكم بالأجهزة والتطبيقات',
    tvPowerOn: 'تشغيل التلفاز',
    tvPowerOff: 'إطفاء التلفاز (وضع الاستعداد)',
    tvStandbyEmpty: '— التلفاز مطفأ (الشريط فارغ) —',
    nowPlaying: 'قيد التشغيل',
    paused: 'متوقف مؤقتاً',
    live: 'شغال',
    noMediaPlaying: 'لا يوجد فيديو قيد التشغيل',

    powerTitleOn: 'تشغيل التلفاز',
    powerTitleOff: 'إطفاء التلفاز (وضع الاستعداد)',
    settingsTitle: 'إعدادات التلفاز والاتصال واللغة',
    keyboardTitle: 'لوحة المفاتيح وإدخال النصوص',
    micTitle: 'البحث والتحكم الصوتي',
    homeTitle: 'الشاشة الرئيسية (Home)',
    backTitle: 'رجوع (Back)',
    fastForwardTitle: 'تقديم الفيديو (+10 ثوانٍ)',
    fastForwardLabel: '+10ث',

    youtubeKids: 'يوتيوب أطفال',
    babySongs: 'بيبي',
    birdsOfParadise: 'طيور الجنة',
    supermanKids: 'سوبر مان أطفال',
    mashaAndBear: 'ماشا والدب',

    voiceCommand: 'أمر صوتي',
    sentKey: 'تم إرسال الزر',
    sentText: 'تم إرسال النص',
    tvPairedSuccess: 'تم إقران التلفاز بنجاح',
    launchingOnYoutube: 'تشغيل على يوتيوب',

    settings: 'الإعدادات',
    language: 'اللغة / Language',
    switchLangNotice: 'التبديل بين العربية والإنجليزية',
    connection: 'الاتصال والأجهزة',
    libraries: 'المكتبات والبروتوكول',
    preferences: 'التفضيلات والصوت',
    remoteInterfacesTab: 'واجهات التحكم (5)',
    switchDevice: 'انقر للتبديل بين أجهزة التلفاز المتصلة',
    online: 'متصل',
    offline: 'غير متصل',
    paired: 'مقترن',
    pairTv: 'إقران التلفاز',
    enterPinCode: 'أدخل رمز PIN الظاهر على الشاشة',
    sensitivity: 'حساسية اللمس',
    hapticFeedback: 'الاهتزاز اللمسي (Haptic)',
    soundFeedback: 'أصوات النقر والتحكم',
    close: 'إغلاق',

    remoteSkinTitle: 'واجهة وشكل جهاز التحكم (5 واجهات)',
    remoteSkinDesc: 'اختر تصميم الواجهة المستوحى من أجهزة التحكم العالمية',
    skinFireTv: 'فاير تي في (Fire TV Touch)',
    skinSamsung: 'سامسونج سمارت (Samsung One)',
    skinLgMagic: 'إل جي ماجيك (LG Magic Remote)',
    skinAppleTv: 'أبل تي في (Apple TV Siri Remote)',
    skinAndroidDpad: 'أندرويد تي في الكلاسيكي (Android D-Pad)',

    tvSimulator: 'شاشة التلفاز الذكي (محاكاة حية)',
    tvScreen: 'شاشة التلفاز',
    chooseTv: 'اختر تلفزيونك',
    searchingTv: 'جاري البحث عن التلفزيون',
    sameWifiHint: 'يرجى التأكد من ربط الهاتف والتلفزيون بنفس شبكة Wi‑Fi',
    connected: 'متصل',
    reconnect: 'إعادة الاتصال',
    disconnect: 'قطع الاتصال',
    pairingCode: 'أدخل الكود الظاهر على التلفزيون',
    confirmCode: 'تأكيد الكود',
    theme: 'المظهر',
    darkTheme: 'داكن',
    lightTheme: 'فاتح',
  },
  en: {
    appTitle: 'Smart TV Magic Remote',
    irTransmitter: 'IR Transmitter',
    remoteNotice: 'Advanced smart controller for TV & streaming apps',
    tvPowerOn: 'Power On TV',
    tvPowerOff: 'Turn Off TV (Standby Mode)',
    tvStandbyEmpty: '— TV is Off (Status bar empty) —',
    nowPlaying: 'Now Playing',
    paused: 'Paused',
    live: 'Live',
    noMediaPlaying: 'No video currently playing',

    powerTitleOn: 'Turn On TV',
    powerTitleOff: 'Turn Off TV (Standby Mode)',
    settingsTitle: 'TV Settings, Connection & Language',
    keyboardTitle: 'Keyboard & Text Input',
    micTitle: 'Voice Search & Commands',
    homeTitle: 'Home Screen',
    backTitle: 'Back',
    fastForwardTitle: 'Fast Forward (+10s)',
    fastForwardLabel: '+10s',

    youtubeKids: 'YouTube Kids',
    babySongs: 'Baby Songs',
    birdsOfParadise: 'Birds of Paradise',
    supermanKids: 'Superman Kids',
    mashaAndBear: 'Masha & The Bear',

    voiceCommand: 'Voice Command',
    sentKey: 'Sent Key',
    sentText: 'Sent Text',
    tvPairedSuccess: 'TV Paired Successfully',
    launchingOnYoutube: 'Launching on YouTube',

    settings: 'Settings',
    language: 'Language / اللغة',
    switchLangNotice: 'Switch between Arabic and English',
    connection: 'Devices & Connect',
    libraries: 'Libraries & Protocol',
    preferences: 'Preferences & Audio',
    remoteInterfacesTab: 'Remote Skins (5)',
    switchDevice: 'Click to switch connected TV devices',
    online: 'Online',
    offline: 'Offline',
    paired: 'Paired',
    pairTv: 'Pair TV',
    enterPinCode: 'Enter the PIN displayed on your TV screen',
    sensitivity: 'Swipe Sensitivity',
    hapticFeedback: 'Haptic Feedback',
    soundFeedback: 'Click & Sound Feedback',
    close: 'Close',

    remoteSkinTitle: 'Remote Control Interface (5 Styles)',
    remoteSkinDesc: 'Choose interface style inspired by world-class TV remotes',
    skinFireTv: 'Fire TV Touchpad',
    skinSamsung: 'Samsung Smart Remote',
    skinLgMagic: 'LG webOS Magic Remote',
    skinAppleTv: 'Apple TV Siri Remote',
    skinAndroidDpad: 'Android TV Classic D-Pad',

    tvSimulator: 'Smart TV Screen (Live Simulator)',
    tvScreen: 'TV Display',
    chooseTv: 'Choose your TV',
    searchingTv: 'Searching for TV',
    sameWifiHint: 'Make sure your phone and TV are connected to the same Wi‑Fi network',
    connected: 'Connected',
    reconnect: 'Reconnect',
    disconnect: 'Disconnect',
    pairingCode: 'Enter the code shown on the TV',
    confirmCode: 'Confirm code',
    theme: 'Appearance',
    darkTheme: 'Dark',
    lightTheme: 'Light',
  },
};
