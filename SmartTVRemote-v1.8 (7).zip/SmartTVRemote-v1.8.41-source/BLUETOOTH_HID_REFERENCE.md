# Bluetooth HID mouse reference

The pointer-speed setting range (0.25x–5x, default 1x) follows the configuration convention in [Bluetooth Remote](https://github.com/jqssun/android-bt-remote), an open-source Android Bluetooth HID remote. The referenced project is licensed under GPL-3.0. No source code from that project was copied into this implementation; the Android HID bridge here was written independently using the public Android `BluetoothHidDevice` API.

The phone must support Android 9 or later and be paired once with the TV box as a Bluetooth mouse. After tapping **Start real mouse pairing** in the app, accept Android's discoverability prompt and select the phone in the box's Bluetooth device settings.
