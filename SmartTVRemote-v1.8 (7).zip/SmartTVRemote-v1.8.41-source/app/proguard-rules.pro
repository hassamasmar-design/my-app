# Keep the JavaScript bridge exposed to the WebView.
-keep class com.smarttv.remote.NativeRemoteBridge { *; }
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Keep Android components referenced from the manifest.
-keep public class com.smarttv.remote.MainActivity { *; }

# Keep generated protobuf message APIs used by the Android TV protocol.
-keep class com.hari.androidtvremote.androidLib.** { *; }

# LevelPlay and WebView use reflection/callbacks in their SDKs.
-keep class com.unity3d.** { *; }
-keep class com.ironsource.** { *; }
-dontwarn com.ironsource.**
-dontwarn com.unity3d.**
