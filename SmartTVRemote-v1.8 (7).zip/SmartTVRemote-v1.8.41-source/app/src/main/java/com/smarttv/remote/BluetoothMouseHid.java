package com.smarttv.remote;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothHidDevice;
import android.bluetooth.BluetoothHidDeviceAppSdpSettings;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;

import java.util.concurrent.Executor;

/** Presents the phone as a standard relative Bluetooth HID mouse. */
public final class BluetoothMouseHid {
    public interface StatusListener {
        void onStatus(String status);
    }

    private static final int REPORT_ID = 1;
    private static final byte[] MOUSE_REPORT_DESCRIPTOR = new byte[] {
            0x05, 0x01, 0x09, 0x02, (byte) 0xA1, 0x01,
            (byte) 0x85, REPORT_ID,
            0x09, 0x01, (byte) 0xA1, 0x00,
            0x05, 0x09, 0x19, 0x01, 0x29, 0x03,
            0x15, 0x00, 0x25, 0x01, (byte) 0x95, 0x03, 0x75, 0x01,
            (byte) 0x81, 0x02,
            (byte) 0x95, 0x01, 0x75, 0x05, (byte) 0x81, 0x01,
            0x05, 0x01, 0x09, 0x30, 0x09, 0x31, 0x09, 0x38,
            0x15, (byte) 0x81, 0x25, 0x7F, 0x75, 0x08, (byte) 0x95, 0x03,
            (byte) 0x81, 0x06,
            (byte) 0xC0, (byte) 0xC0
    };

    private final Context context;
    private final StatusListener statusListener;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Executor callbackExecutor = command -> handler.post(command);
    private BluetoothAdapter adapter;
    private BluetoothHidDevice hidDevice;
    private BluetoothDevice hostDevice;
    private String pendingHostAddress = "";
    private boolean profileRequested;
    private boolean appRegistered;
    private boolean notConnectedReported;
    private int buttonMask;
    private float fractionalX;
    private float fractionalY;

    public BluetoothMouseHid(Context context, StatusListener statusListener) {
        this.context = context.getApplicationContext();
        this.statusListener = statusListener;
    }

    private void status(String value) {
        if (statusListener != null) statusListener.onStatus(value);
    }

    private boolean hasConnectPermission() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.S
                || context.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean hasAdvertisePermission() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.S
                || context.checkSelfPermission(Manifest.permission.BLUETOOTH_ADVERTISE) == PackageManager.PERMISSION_GRANTED;
    }

    public synchronized void start() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
            status("unsupported_android_version");
            return;
        }
        if (!hasConnectPermission() || !hasAdvertisePermission()) {
            status("permission_required");
            return;
        }
        BluetoothManager manager = (BluetoothManager) context.getSystemService(Context.BLUETOOTH_SERVICE);
        adapter = manager == null ? null : manager.getAdapter();
        if (adapter == null) {
            status("bluetooth_unavailable");
            return;
        }
        try {
            if (!adapter.isEnabled()) {
                status("bluetooth_off");
                return;
            }
            if (profileRequested) {
                status(appRegistered ? (hostDevice == null ? "ready_to_pair" : "connected") : "starting");
                return;
            }
            profileRequested = true;
            status("starting");
            boolean requested = adapter.getProfileProxy(context, profileListener, BluetoothProfile.HID_DEVICE);
            if (!requested) {
                profileRequested = false;
                status("profile_unavailable");
            }
        } catch (SecurityException error) {
            profileRequested = false;
            status("permission_required");
        } catch (RuntimeException error) {
            profileRequested = false;
            status("profile_unavailable");
        }
    }

    private final BluetoothProfile.ServiceListener profileListener = new BluetoothProfile.ServiceListener() {
        @Override public void onServiceConnected(int profile, BluetoothProfile proxy) {
            if (profile != BluetoothProfile.HID_DEVICE || !(proxy instanceof BluetoothHidDevice)) return;
            synchronized (BluetoothMouseHid.this) {
                hidDevice = (BluetoothHidDevice) proxy;
                try {
                    BluetoothHidDeviceAppSdpSettings settings = new BluetoothHidDeviceAppSdpSettings(
                            "Smart TV Remote Mouse",
                            "Bluetooth HID relative mouse",
                            "Smart TV Remote",
                            BluetoothHidDevice.SUBCLASS1_MOUSE,
                            MOUSE_REPORT_DESCRIPTOR);
                    appRegistered = hidDevice.registerApp(settings, null, null, callbackExecutor, hidCallback);
                    status(appRegistered ? "starting" : "registration_failed");
                } catch (SecurityException error) {
                    status("permission_required");
                } catch (RuntimeException error) {
                    status("registration_failed");
                }
            }
        }

        @Override public void onServiceDisconnected(int profile) {
            synchronized (BluetoothMouseHid.this) {
                hidDevice = null;
                hostDevice = null;
                appRegistered = false;
                profileRequested = false;
                status("disconnected");
            }
        }
    };

    private final BluetoothHidDevice.Callback hidCallback = new BluetoothHidDevice.Callback() {
        @Override public void onAppStatusChanged(BluetoothDevice pluggedDevice, boolean registered) {
            synchronized (BluetoothMouseHid.this) {
                appRegistered = registered;
                if (registered && pluggedDevice != null) hostDevice = pluggedDevice;
                if (!registered) {
                    hostDevice = null;
                    status("registration_failed");
                } else if (hostDevice != null) {
                    status("connected");
                } else {
                    status("ready_to_pair");
                    if (!pendingHostAddress.isEmpty()) connectPendingHost();
                }
            }
        }

        @Override public void onConnectionStateChanged(BluetoothDevice device, int state) {
            synchronized (BluetoothMouseHid.this) {
                if (state == BluetoothProfile.STATE_CONNECTED) {
                    hostDevice = device;
                    pendingHostAddress = device.getAddress();
                    notConnectedReported = false;
                    status("connected");
                } else if (device != null && (device.equals(hostDevice)
                        || pendingHostAddress.equalsIgnoreCase(device.getAddress()))
                        && (state == BluetoothProfile.STATE_DISCONNECTED || state == BluetoothProfile.STATE_DISCONNECTING)) {
                    hostDevice = null;
                    status(appRegistered ? "ready_to_pair" : "disconnected");
                } else if (device != null && pendingHostAddress.equalsIgnoreCase(device.getAddress())
                        && state == BluetoothProfile.STATE_CONNECTING) {
                    status("connecting");
                }
            }
        }
    };

    public synchronized boolean isConnected() {
        return hidDevice != null && hostDevice != null && appRegistered;
    }

    public synchronized boolean connectHost(String address) {
        if (address == null || address.trim().isEmpty()) return false;
        String requestedAddress = address.trim();
        if (hostDevice != null && hostDevice.getAddress().equalsIgnoreCase(requestedAddress)) {
            status("connected");
            return true;
        }
        pendingHostAddress = requestedAddress;
        if (!hasConnectPermission()) {
            status("permission_required");
            return false;
        }
        if (!appRegistered || hidDevice == null || adapter == null) {
            status("starting");
            return true;
        }
        return connectPendingHost();
    }

    private boolean connectPendingHost() {
        if (pendingHostAddress.isEmpty() || hidDevice == null || adapter == null || !appRegistered) return false;
        if (!hasConnectPermission()) {
            status("permission_required");
            return false;
        }
        try {
            BluetoothDevice target = adapter.getRemoteDevice(pendingHostAddress);
            boolean started = hidDevice.connect(target);
            status(started ? "connecting" : "connection_failed");
            return started;
        } catch (IllegalArgumentException | SecurityException error) {
            status("connection_failed");
            return false;
        }
    }

    public synchronized boolean move(float deltaX, float deltaY) {
        if (!isConnected()) {
            reportNotConnected();
            return false;
        }
        float totalX = fractionalX + deltaX;
        float totalY = fractionalY + deltaY;
        int x = Math.round(totalX);
        int y = Math.round(totalY);
        fractionalX = totalX - x;
        fractionalY = totalY - y;
        x = clampRelative(x);
        y = clampRelative(y);
        if (x == 0 && y == 0) return true;
        return sendReport(buttonMask, x, y, 0);
    }

    public synchronized boolean clickLeft() {
        if (!isConnected()) {
            reportNotConnected();
            return false;
        }
        buttonMask |= 1;
        boolean sent = sendReport(buttonMask, 0, 0, 0);
        handler.postDelayed(() -> {
            synchronized (BluetoothMouseHid.this) {
                buttonMask &= ~1;
                if (isConnected()) sendReport(buttonMask, 0, 0, 0);
            }
        }, 45);
        return sent;
    }

    private void reportNotConnected() {
        if (!notConnectedReported) {
            notConnectedReported = true;
            status(appRegistered ? "ready_to_pair" : "starting");
        }
    }

    private static int clampRelative(int value) {
        return Math.max(-127, Math.min(127, value));
    }

    private boolean sendReport(int buttons, int x, int y, int wheel) {
        if (hidDevice == null || hostDevice == null || !hasConnectPermission()) return false;
        try {
            byte[] report = new byte[] {
                    (byte) (buttons & 0x07),
                    (byte) clampRelative(x),
                    (byte) clampRelative(y),
                    (byte) clampRelative(wheel)
            };
            boolean sent = hidDevice.sendReport(hostDevice, REPORT_ID, report);
            if (!sent) reportNotConnected();
            return sent;
        } catch (SecurityException error) {
            status("permission_required");
            return false;
        } catch (RuntimeException error) {
            reportNotConnected();
            return false;
        }
    }

    public synchronized void close() {
        if (hidDevice != null) {
            try {
                if (hasConnectPermission()) {
                    if (hostDevice != null) hidDevice.sendReport(hostDevice, REPORT_ID, new byte[] {0, 0, 0, 0});
                    hidDevice.unregisterApp();
                }
                if (adapter != null) adapter.closeProfileProxy(BluetoothProfile.HID_DEVICE, hidDevice);
            } catch (Exception ignored) {}
        }
        hidDevice = null;
        hostDevice = null;
        appRegistered = false;
        profileRequested = false;
    }
}
