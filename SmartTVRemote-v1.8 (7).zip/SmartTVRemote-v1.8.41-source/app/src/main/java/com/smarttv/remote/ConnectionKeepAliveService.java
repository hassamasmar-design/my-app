package com.smarttv.remote;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

/** Owns the active Android TV socket independently of the Activity lifecycle. */
public final class ConnectionKeepAliveService extends Service {
    private static final String CHANNEL_ID = "tv_connection";
    private static final int NOTIFICATION_ID = 8401;
    private static volatile NativeRemoteBridge bridge;
    private static volatile boolean serviceStarted;
    private boolean restoreSavedConnection;

    public static synchronized NativeRemoteBridge obtainBridge(Context context, android.app.Activity activity, android.webkit.WebView webView) {
        if (bridge == null) bridge = new NativeRemoteBridge(context.getApplicationContext(), null);
        bridge.attachUi(activity, webView);
        return bridge;
    }

    public static void ensureRunning(Context context, NativeRemoteBridge owner) {
        bridge = owner;
        if (serviceStarted) return;
        Intent intent = new Intent(context, ConnectionKeepAliveService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent);
        else context.startService(intent);
    }

    public static void detachUi(android.app.Activity activity) {
        NativeRemoteBridge current = bridge;
        if (current != null) current.detachUi(activity);
    }

    public static void stop(Context context) {
        context.stopService(new Intent(context, ConnectionKeepAliveService.class));
    }

    @Override public void onCreate() {
        super.onCreate();
        serviceStarted = true;
        createChannel();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification(), android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE);
        } else {
            startForeground(NOTIFICATION_ID, notification());
        }
        if (bridge == null) {
            bridge = new NativeRemoteBridge(getApplicationContext(), null);
            restoreSavedConnection = true;
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        NativeRemoteBridge current = bridge;
        if (current == null) {
            synchronized (ConnectionKeepAliveService.class) {
                if (bridge == null) bridge = new NativeRemoteBridge(getApplicationContext(), null);
                current = bridge;
                restoreSavedConnection = true;
            }
        }
        if (restoreSavedConnection) {
            restoreSavedConnection = false;
            current.onAppResume();
        }
        return START_STICKY;
    }

    @Override public void onTaskRemoved(Intent rootIntent) {
        // Keep the paired TV socket alive when the user dismisses the UI from Recents.
        super.onTaskRemoved(rootIntent);
    }

    @Override public void onDestroy() {
        serviceStarted = false;
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    private void createChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "اتصال التلفاز", NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("يبقي اتصال الريموت بالتلفاز فعالًا في الخلفية");
        channel.setShowBadge(false);
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager != null) manager.createNotificationChannel(channel);
    }

    private Notification notification() {
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pending = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        return builder.setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
                .setContentTitle("الريموت متصل")
                .setContentText("يبقى اتصال التلفاز نشطًا في الخلفية")
                .setContentIntent(pending)
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .setShowWhen(false)
                .build();
    }
}
