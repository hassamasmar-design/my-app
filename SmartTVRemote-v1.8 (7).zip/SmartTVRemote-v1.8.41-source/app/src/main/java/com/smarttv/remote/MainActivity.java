package com.smarttv.remote;

import android.annotation.SuppressLint;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;
import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends AppCompatActivity {
    private WebView webView;
    private NativeRemoteBridge nativeBridge;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(0xFF0D0E11);
            window.setNavigationBarColor(0xFF0D0E11);
        }
        webView = new WebView(this);
        webView.setBackgroundColor(0xFF0D0E11);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        // Keep the CSS viewport equal to the real phone width. Desktop overview
        // mode makes the shortcuts track fit in the viewport and disables its drag range.
        settings.setUseWideViewPort(false);
        settings.setLoadWithOverviewMode(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        nativeBridge = ConnectionKeepAliveService.obtainBridge(this, this, webView);
        webView.addJavascriptInterface(nativeBridge, "AndroidBridge");
        WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(android.webkit.PermissionRequest request) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    request.grant(new String[]{android.webkit.PermissionRequest.RESOURCE_AUDIO_CAPTURE});
                }
            }
        });
        java.util.ArrayList<String> permissionsToRequest = new java.util.ArrayList<>();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(Manifest.permission.RECORD_AUDIO);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.BLUETOOTH_CONNECT);
            }
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_ADVERTISE) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.BLUETOOTH_ADVERTISE);
            }
        }
        if (!permissionsToRequest.isEmpty()) {
            requestPermissions(permissionsToRequest.toArray(new String[0]), 701);
        } else {
            nativeBridge.startMouseHid();
        }
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
        webView.postDelayed(nativeBridge::startWifiMonitoring, 500);
        webView.postDelayed(nativeBridge::startTiltMonitoring, 300);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (nativeBridge != null) {
            nativeBridge.startTiltMonitoring();
            nativeBridge.onAppResume();
            nativeBridge.startMouseHid();
        }
    }

    @Override
    protected void onPause() {
        if (nativeBridge != null) nativeBridge.stopTiltMonitoring();
        super.onPause();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 701 && nativeBridge != null) nativeBridge.startMouseHid();
    }

    @Override
    protected void onDestroy() {
        ConnectionKeepAliveService.detachUi(this);
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (webView != null) {
            webView.evaluateJavascript("window.dispatchEvent(new Event('androidBackPressed'));", null);
        }
    }

    /** Route the phone's side volume buttons to the connected TV instead of
     * changing the phone media volume. */
    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        int keyCode = event.getKeyCode();
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (event.getAction() == KeyEvent.ACTION_DOWN && nativeBridge != null) {
                try {
                    nativeBridge.sendHardwareVolumeKey(
                            keyCode == KeyEvent.KEYCODE_VOLUME_UP ? "VOLUME_UP" : "VOLUME_DOWN"
                    );
                } catch (RuntimeException ignored) {
                    // Hardware volume presses must never close the remote UI.
                }
            }
            return true;
        }
        return super.dispatchKeyEvent(event);
    }

}
