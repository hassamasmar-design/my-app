package com.smarttv.remote;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;

import android.content.Context;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.os.Handler;
import android.os.Looper;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

import com.hari.androidtvremote.androidLib.AndroidRemoteTv;
import com.hari.androidtvremote.androidLib.AndroidTvListener;
import com.hari.androidtvremote.androidLib.remote.Remotemessage;

import java.util.HashMap;
import java.util.Map;
import java.nio.charset.StandardCharsets;

public final class NativeRemoteBridge implements SensorEventListener {
    private static final String PREFS = "native_remote_connection";
    private static final String SAVED_HOST = "saved_host";
    private static final String SAVED_PAIRED = "saved_paired";
    private static final String SAVED_PAIRED_HOST = "saved_paired_host";
    private static final String SAVED_USER_DISCONNECTED = "user_disconnected";
    private static final String SAVED_MOUSE_HID_HOST = "mouse_hid_host";
    private final Context context;
    private volatile java.lang.ref.WeakReference<Activity> activityReference;
    private volatile WebView webView;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final BluetoothMouseHid mouseHid;
    private final ConnectivityManager connectivityManager;
    private final SensorManager sensorManager;
    private final Sensor tiltSensor;
    private final float[] rotationMatrix = new float[9];
    private final float[] orientationAngles = new float[3];
    private boolean tiltMonitoring;
    private long lastTiltEvent;
    private ConnectivityManager.NetworkCallback wifiCallback;
    private AndroidRemoteTv remote;
    private String host;
    private boolean reconnectScheduled;
    private Runnable reconnectRunnable;
    private NsdManager nsdManager;
    private final java.util.Set<String> discoveredHosts = new java.util.HashSet<>();
    private SpeechRecognizer speechRecognizer;
    private boolean speechStopping;
    private int voiceGeneration;
    /** Pairing can ask for the code before the WebView finishes typing it. */
    private String pendingPairingCode;
    private boolean pairingSecretReady;
    private boolean pairingSecretSending;

    public NativeRemoteBridge(Context context, WebView webView) {
        this.context = context.getApplicationContext();
        this.activityReference = new java.lang.ref.WeakReference<>(context instanceof Activity ? (Activity) context : null);
        this.webView = webView;
        this.mouseHid = new BluetoothMouseHid(this.context, status -> event("nativeMouseHidStatus", status));
        this.connectivityManager = (ConnectivityManager) this.context.getSystemService(Context.CONNECTIVITY_SERVICE);
        this.sensorManager = (SensorManager) this.context.getSystemService(Context.SENSOR_SERVICE);
        Sensor rotation = sensorManager == null ? null : sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        Sensor gravity = sensorManager == null ? null : sensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY);
        this.tiltSensor = rotation != null ? rotation : (gravity != null ? gravity : (sensorManager == null ? null : sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)));
    }

    public void attachUi(Activity activity, WebView view) {
        activityReference = new java.lang.ref.WeakReference<>(activity);
        webView = view;
    }

    public void detachUi(Activity activity) {
        Activity attached = activityReference == null ? null : activityReference.get();
        if (attached == activity) {
            webView = null;
            activityReference.clear();
        }
    }

    private Activity currentActivity() {
        return activityReference == null ? null : activityReference.get();
    }

    private void event(String name, String detail) {
        WebView target = webView;
        if (target == null) return;
        String safe = detail == null ? "" : detail.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ");
        target.post(() -> {
            if (webView == target) target.evaluateJavascript(
                    "window.dispatchEvent(new CustomEvent('" + name + "',{detail:'" + safe + "'}));", null);
        });
    }

    public synchronized void startWifiMonitoring() {
        emitWifiStatus();
        if (connectivityManager == null || wifiCallback != null || android.os.Build.VERSION.SDK_INT < 24) return;
        wifiCallback = new ConnectivityManager.NetworkCallback() {
            @Override public void onAvailable(Network network) { emitWifiStatus(); }
            @Override public void onCapabilitiesChanged(Network network, NetworkCapabilities capabilities) { emitWifiStatus(); }
            @Override public void onLost(Network network) { emitWifiStatus(); }
        };
        try {
            connectivityManager.registerDefaultNetworkCallback(wifiCallback);
        } catch (Exception ignored) {
            wifiCallback = null;
        }
    }

    private void emitWifiStatus() {
        boolean wifi = isWifiTransportActive();
        event("nativeWifiStatus", "{\"wifi\":" + wifi + "}");
    }

    /** True only when Android's active default network is Wi-Fi, not mobile data. */
    private boolean isWifiTransportActive() {
        if (connectivityManager == null || android.os.Build.VERSION.SDK_INT < 23) return false;
        Network network = connectivityManager.getActiveNetwork();
        NetworkCapabilities capabilities = network == null ? null : connectivityManager.getNetworkCapabilities(network);
        return capabilities != null && capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI);
    }

    /** Streams the Android gravity sensor so the liquid moves without a button press. */
    public synchronized void startTiltMonitoring() {
        if (tiltMonitoring || sensorManager == null || tiltSensor == null) return;
        sensorManager.registerListener(this, tiltSensor, SensorManager.SENSOR_DELAY_GAME);
        tiltMonitoring = true;
    }

    public synchronized void stopTiltMonitoring() {
        if (!tiltMonitoring || sensorManager == null) return;
        sensorManager.unregisterListener(this);
        tiltMonitoring = false;
    }

    /** Resume the saved TV session immediately when the phone is unlocked. */
    public synchronized void onAppResume() {
        emitWifiStatus();
        android.content.SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String saved = prefs.getString(SAVED_HOST, "");
        if (saved.isEmpty()) return;
        if (prefs.getBoolean(SAVED_USER_DISCONNECTED, false)) return;
        boolean pairedForSavedHost = prefs.getBoolean(SAVED_PAIRED, false)
                && saved.equals(prefs.getString(SAVED_PAIRED_HOST, ""));
        if (!pairedForSavedHost) return;
        ConnectionKeepAliveService.ensureRunning(context, this);
        if (remote != null && saved.equals(host) && remote.isSocketAlive()) {
            event("nativeConnected", saved);
            return;
        }
        if (remote != null) {
            try { remote.abort(); } catch (Exception ignored) {}
            remote = null;
        }
        event("nativeConnecting", saved);
        connect(saved);
    }

    /** Called by the WebView after React has installed its native event listeners. */
    @JavascriptInterface
    public synchronized void onWebViewReady() {
        onAppResume();
        mouseHid.start();
    }

    @Override public void onSensorChanged(SensorEvent sensorEvent) {
        if (sensorEvent == null || sensorEvent.values.length < 3) return;
        long now = System.currentTimeMillis();
        if (now - lastTiltEvent < 16) return;
        lastTiltEvent = now;
        double roll;
        if (sensorEvent.sensor.getType() == Sensor.TYPE_ROTATION_VECTOR) {
            SensorManager.getRotationMatrixFromVector(rotationMatrix, sensorEvent.values);
            SensorManager.getOrientation(rotationMatrix, orientationAngles);
            roll = Math.toDegrees(orientationAngles[2]);
        } else {
            float x = sensorEvent.values[0];
            float y = sensorEvent.values[1];
            float z = sensorEvent.values[2];
            roll = Math.toDegrees(Math.atan2(x, Math.sqrt(y * y + z * z)));
        }
        roll = Math.max(-75.0, Math.min(75.0, roll));
        event("nativeTiltStatus", "{\"roll\":" + roll + "}");
    }

    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) {}

    @JavascriptInterface
    public synchronized void connect(String host) {
        if (host == null || host.trim().isEmpty()) return;
        cancelScheduledReconnect();
        ConnectionKeepAliveService.ensureRunning(context, this);
        this.context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString(SAVED_HOST, host.trim())
                .putBoolean(SAVED_USER_DISCONNECTED, false)
                .apply();
        if (remote != null && host.equals(this.host) && remote.isSocketAlive()) return;
        this.host = host.trim();
        remote = new AndroidRemoteTv();
        final AndroidRemoteTv instance = remote;
        instance.setVolumeChangedCallback((level, maxLevel, muted) ->
                event("nativeVolumeStatus", "{\"level\":" + level + ",\"maximum\":" + maxLevel + ",\"muted\":" + muted + "}"));
        final android.content.SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        new Thread(() -> {
            try {
                AndroidTvListener listener = new AndroidTvListener() {
                    @Override public void onSessionCreated() {}
                    @Override public void onConnectingToRemote() { event("nativeConnecting", thisHost()); }
                    @Override public void onPaired() {
                        prefs.edit().putBoolean(SAVED_PAIRED, true).putString(SAVED_PAIRED_HOST, thisHost()).apply();
                        event("nativePaired", thisHost());
                    }
                    @Override public void onConnected() {
                        // Only the active session may update the UI. Do not reject a
                        // working TV socket merely because Android's Wi-Fi transport
                        // probe is temporarily unavailable (VPN/Ethernet/resume).
                        if (instance != remote || !instance.isSocketAlive()) {
                            try { instance.abort(); } catch (Exception ignored) {}
                            return;
                        }
                        prefs.edit().putBoolean(SAVED_PAIRED, true).putString(SAVED_PAIRED_HOST, thisHost()).apply();
                        event("nativeConnected", thisHost());
                    }
                    @Override public void onDisconnect() {
                        if (instance != remote) return;
                        event("nativeDisconnected", thisHost());
                        scheduleReconnect();
                    }
                    @Override public void onError(String message) { event("nativeError", message); }
                    @Override public void onSecretRequested() { onPairingSecretRequested(); event("nativePairingRequired", ""); }
                    @Override public void onImeShow(String text, int fieldCounter) {
                        android.util.Log.i("NativeRemoteBridge", "TV IME text/status received; field=" + fieldCounter);
                        event("nativeImeText", text);
                    }
                    @Override public void onImeShowRequested(String text, int fieldCounter) {
                        android.util.Log.i("NativeRemoteBridge", "TV requested IME show; field=" + fieldCounter);
                        event("nativeImeShowRequested", text);
                    }
                    private String thisHost() { return NativeRemoteBridge.this.host == null ? "" : NativeRemoteBridge.this.host; }
                };
                boolean pairedForThisHost = prefs.getBoolean(SAVED_PAIRED, false)
                        && this.host.equals(prefs.getString(SAVED_PAIRED_HOST, ""));
                if (pairedForThisHost) instance.reconnect(this.host, listener);
                else instance.connect(this.host, listener);
            } catch (Exception e) {
                event("nativeError", e.getMessage());
            }
        }, "AndroidTV-Connect").start();
    }

    /** Starts a fresh first-time pairing flow instead of reusing a cancelled session. */
    @JavascriptInterface
    public synchronized void startPairing(String host) {
        if (host == null || host.trim().isEmpty()) return;
        cancelScheduledReconnect();
        pendingPairingCode = null;
        pairingSecretReady = false;
        pairingSecretSending = false;
        if (remote != null) {
            try { remote.abort(); } catch (Exception ignored) {}
            remote = null;
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString(SAVED_HOST, host.trim())
                .putBoolean(SAVED_PAIRED, false)
                .putBoolean(SAVED_USER_DISCONNECTED, false)
                .remove(SAVED_PAIRED_HOST)
                .apply();
        connect(host.trim());
    }

    private synchronized void cancelScheduledReconnect() {
        if (reconnectRunnable != null) {
            mainHandler.removeCallbacks(reconnectRunnable);
            reconnectRunnable = null;
        }
        reconnectScheduled = false;
    }

    private synchronized void scheduleReconnect() {
        android.content.SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String saved = prefs.getString(SAVED_HOST, "");
        boolean pairedForSavedHost = prefs.getBoolean(SAVED_PAIRED, false)
                && saved.equals(prefs.getString(SAVED_PAIRED_HOST, ""));
        if (saved.isEmpty() || !pairedForSavedHost
                || prefs.getBoolean(SAVED_USER_DISCONNECTED, false) || reconnectScheduled) return;
        reconnectScheduled = true;
        remote = null;
        reconnectRunnable = () -> {
            synchronized (NativeRemoteBridge.this) {
                reconnectScheduled = false;
                reconnectRunnable = null;
                android.content.SharedPreferences currentPrefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
                boolean stillPaired = currentPrefs.getBoolean(SAVED_PAIRED, false)
                        && saved.equals(currentPrefs.getString(SAVED_PAIRED_HOST, ""));
                if (!stillPaired || currentPrefs.getBoolean(SAVED_USER_DISCONNECTED, false)) return;
                connect(saved);
            }
        };
        mainHandler.postDelayed(reconnectRunnable, 1500);
    }

    @JavascriptInterface
    public String getSavedHost() {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(SAVED_HOST, "");
    }

    @JavascriptInterface
    public boolean isHostPaired(String host) {
        if (host == null || host.trim().isEmpty()) return false;
        android.content.SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        return prefs.getBoolean(SAVED_PAIRED, false) && host.trim().equals(prefs.getString(SAVED_PAIRED_HOST, ""));
    }

    @JavascriptInterface
    public synchronized boolean isConnected() {
        if (remote == null || host == null || !remote.isSocketAlive()) return false;
        android.content.SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        return prefs.getBoolean(SAVED_PAIRED, false)
                && host.equals(prefs.getString(SAVED_PAIRED_HOST, ""))
                && !prefs.getBoolean(SAVED_USER_DISCONNECTED, false);
    }

    @JavascriptInterface
    public boolean isWifiConnected() {
        return isWifiTransportActive();
    }

    @JavascriptInterface
    public synchronized String getConnectedHost() {
        return isConnected() ? host : "";
    }

    @JavascriptInterface
    public synchronized void providePairingCode(String code) {
        final String secret = code == null ? "" : code.trim();
        if (secret.isEmpty()) return;
        // Do not drop an early code: the pairing socket may still be negotiating.
        pendingPairingCode = secret;
        flushPendingPairingCode();
    }

    /** Called when the TV has completed pairing negotiation and is ready for the code. */
    private synchronized void onPairingSecretRequested() {
        pairingSecretReady = true;
        event("nativePairingReady", "");
        flushPendingPairingCode();
    }

    /** Sends a queued code once, off the WebView thread, after the pairing socket is ready. */
    private void flushPendingPairingCode() {
        final AndroidRemoteTv instance;
        final String secret;
        synchronized (this) {
            if (!pairingSecretReady || pairingSecretSending || pendingPairingCode == null) return;
            instance = remote;
            if (instance == null) return;
            secret = pendingPairingCode;
            pairingSecretSending = true;
        }
        new Thread(() -> {
            boolean sent = false;
            try {
                instance.sendSecret(secret);
                sent = true;
            } catch (Exception error) {
                event("nativeError", error.getMessage() == null ? "Invalid pairing code" : error.getMessage());
            } finally {
                synchronized (NativeRemoteBridge.this) {
                    pairingSecretSending = false;
                    if (sent && secret.equals(pendingPairingCode)) pendingPairingCode = null;
                }
            }
        }, "AndroidTV-PairingCode").start();
    }

    @JavascriptInterface
    public synchronized void startMouseHid() {
        mouseHid.start();
        String savedHost = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(SAVED_MOUSE_HID_HOST, "");
        if (!savedHost.isEmpty()) mouseHid.connectHost(savedHost);
    }

    @JavascriptInterface
    public void startMouseHidPairing() {
        Activity activity = currentActivity();
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S
                && (context.checkSelfPermission(android.Manifest.permission.BLUETOOTH_CONNECT) != android.content.pm.PackageManager.PERMISSION_GRANTED
                || context.checkSelfPermission(android.Manifest.permission.BLUETOOTH_ADVERTISE) != android.content.pm.PackageManager.PERMISSION_GRANTED)) {
            if (activity != null) activity.requestPermissions(new String[] {
                    android.Manifest.permission.BLUETOOTH_CONNECT,
                    android.Manifest.permission.BLUETOOTH_ADVERTISE
            }, 701);
            event("nativeMouseHidStatus", "permission_required");
            return;
        }
        mouseHid.start();
        if (activity == null) return;
        mainHandler.postDelayed(() -> {
            Activity current = currentActivity();
            if (current == null) return;
            try {
                Intent discoverable = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
                discoverable.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 120);
                current.startActivityForResult(discoverable, 702);
            } catch (RuntimeException error) {
                event("nativeMouseHidStatus", "discoverability_failed");
            }
        }, 1000);
    }

    @JavascriptInterface
    public synchronized String getBondedBluetoothDevices() {
        org.json.JSONArray devices = new org.json.JSONArray();
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S
                && context.checkSelfPermission(android.Manifest.permission.BLUETOOTH_CONNECT) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            event("nativeMouseHidStatus", "permission_required");
            return devices.toString();
        }
        try {
            android.bluetooth.BluetoothManager manager = (android.bluetooth.BluetoothManager) context.getSystemService(Context.BLUETOOTH_SERVICE);
            android.bluetooth.BluetoothAdapter adapter = manager == null ? null : manager.getAdapter();
            if (adapter == null || !adapter.isEnabled()) return devices.toString();
            for (android.bluetooth.BluetoothDevice device : adapter.getBondedDevices()) {
                org.json.JSONObject item = new org.json.JSONObject();
                item.put("name", device.getName() == null ? "Bluetooth device" : device.getName());
                item.put("address", device.getAddress());
                devices.put(item);
            }
        } catch (Exception error) {
            event("nativeMouseHidStatus", "permission_required");
        }
        return devices.toString();
    }

    @JavascriptInterface
    public synchronized boolean connectMouseHost(String address) {
        if (address == null || address.trim().isEmpty()) return false;
        String normalized = address.trim();
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(SAVED_MOUSE_HID_HOST, normalized).apply();
        return mouseHid.connectHost(normalized);
    }

    @JavascriptInterface
    public synchronized boolean isMouseHidConnected() {
        return mouseHid.isConnected();
    }

    @JavascriptInterface
    public boolean sendMouseMove(float deltaX, float deltaY) {
        return mouseHid.move(deltaX, deltaY);
    }

    @JavascriptInterface
    public boolean sendMouseClick() {
        return mouseHid.clickLeft();
    }

    public synchronized void closeMouseHid() {
        mouseHid.close();
    }

    @JavascriptInterface
    public synchronized void sendRemoteKey(String key, boolean longPress) {
        if (remote == null || !remote.isSocketAlive()) {
            event("nativeConnecting", host == null ? "" : host);
            scheduleReconnect();
            return;
        }
        Remotemessage.RemoteKeyCode code = keyCode(key);
        if (code != null) {
            try {
                // Android TV treats START_LONG as key-repeat. A touchpad swipe
                // must never start that mode, so every swipe is SHORT exactly once.
                // The longPress flag remains accepted for API compatibility.
                remote.sendCommand(code, Remotemessage.RemoteDirection.SHORT);
            } catch (RuntimeException error) {
                event("nativeError", "volume_command_failed");
                scheduleReconnect();
            }
        }
    }

    /** Hardware volume keys arrive on the Activity thread; send them off that
     * thread so a socket write or reconnect can never block/drop the key event. */
    public void sendHardwareVolumeKey(String key) {
        new Thread(() -> {
            sendRemoteKey(key, false);
        }, "HardwareVolumeKey").start();
    }

    @JavascriptInterface
    public synchronized void releaseRemoteKey(String key) {
        if (remote == null || !remote.isSocketAlive()) return;
        Remotemessage.RemoteKeyCode code = keyCode(key);
        if (code != null) remote.sendCommand(code, Remotemessage.RemoteDirection.END_LONG);
    }

    @JavascriptInterface
    public synchronized void openApp(String appLink, String fallbackLink) {
        if (appLink == null || appLink.trim().isEmpty()) return;
        if (remote == null || !remote.isSocketAlive()) {
            event("nativeError", "التلفاز غير متصل");
            scheduleReconnect();
            return;
        }
        final AndroidRemoteTv instance = remote;
        String requested = appLink.trim();
        // Remote ATV stores and sends the appLink value. The Android TV
        // Remote protocol uses this URL/deep link to resolve the installed
        // application; sending a package name or Play Store URL here does
        // not launch the TV app.
        instance.sendAppLink(requested);
    }

    @JavascriptInterface
    public synchronized boolean startVoice() {
        if (remote == null || !remote.isSocketAlive()) return false;
        final AndroidRemoteTv instance = remote;
        final int generation = ++voiceGeneration;
        new Thread(() -> {
            try {
                if (!instance.startVoice()) {
                    event("nativeVoiceError", "start_failed");
                } else {
                    synchronized (NativeRemoteBridge.this) {
                        if (generation != voiceGeneration) {
                            instance.stopVoice();
                            return;
                        }
                    }
                    event("nativeVoiceStarted", "");
                }
            } catch (Exception e) {
                event("nativeVoiceError", e.getMessage() == null ? "start_failed" : e.getMessage());
            }
        }, "AndroidTV-VoiceStart").start();
        return true;
    }

    private void beginSpeechRecognition() {
        cleanupSpeechRecognizer();
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context);
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) {}
            @Override public void onBeginningOfSpeech() {}
            @Override public void onRmsChanged(float rmsdB) {}
            @Override public void onBufferReceived(byte[] buffer) {}
            @Override public void onEndOfSpeech() {}
            @Override public void onPartialResults(Bundle partialResults) {}
            @Override public void onEvent(int eventType, Bundle params) {}
            @Override public void onError(int error) { event("nativeVoiceError", String.valueOf(error)); cleanupSpeechRecognizer(); }
            @Override public void onResults(Bundle results) {
                java.util.ArrayList<String> matches = results == null ? null : results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null && !matches.isEmpty() && remote != null && remote.isSocketAlive()) {
                    remote.sendText(matches.get(0), 0, 0);
                }
                cleanupSpeechRecognizer();
            }
        });
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-SA");
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
        speechRecognizer.startListening(intent);
        speechStopping = false;
    }

    @JavascriptInterface
    public synchronized void stopVoice() {
        voiceGeneration++;
        if (remote != null) remote.stopVoice();
        mainHandler.post(() -> {
            if (speechRecognizer != null) {
                speechStopping = true;
                try { speechRecognizer.stopListening(); } catch (Exception ignored) { cleanupSpeechRecognizer(); }
            }
        });
    }

    private synchronized void cleanupSpeechRecognizer() {
        if (speechRecognizer != null) {
            try { speechRecognizer.destroy(); } catch (Exception ignored) {}
            speechRecognizer = null;
        }
        speechStopping = false;
    }

    @JavascriptInterface
    public synchronized void sendText(String text) {
        if (remote != null) remote.sendText(text == null ? "" : text, 0, 0);
    }

    @JavascriptInterface
    public synchronized void sendTextEdit(String insertedText, String removedText, int start, int end) {
        if (remote == null || !remote.isSocketAlive()) {
            android.util.Log.w("NativeRemoteBridge", "IME edit dropped: TV socket is not connected");
            scheduleReconnect();
            return;
        }
        String safeInsertedText = insertedText == null ? "" : insertedText;
        String safeRemovedText = removedText == null ? "" : removedText;
        android.util.Log.i("NativeRemoteBridge", "IME edit received: insertLength=" + safeInsertedText.length()
                + " deleteLength=" + safeRemovedText.length() + " range=" + start + ":" + end);
        remote.sendTextEdit(safeInsertedText, safeRemovedText, start, end);
    }

    @JavascriptInterface
    public void showSoftKeyboard() {
        mainHandler.post(() -> {
            WebView target = webView;
            android.view.inputmethod.InputMethodManager inputMethodManager =
                    (android.view.inputmethod.InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
            if (target != null && inputMethodManager != null) {
                inputMethodManager.showSoftInput(target, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT);
            }
        });
    }

    @JavascriptInterface
    public void exitApp() {
        mainHandler.post(() -> {
            Activity activity = currentActivity();
            if (activity != null) activity.finish();
        });
    }

    @JavascriptInterface
    public String getClipboardText() {
        try {
            ClipboardManager clipboard = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData clip = clipboard == null ? null : clipboard.getPrimaryClip();
            if (clip != null && clip.getItemCount() > 0) {
                CharSequence value = clip.getItemAt(0).coerceToText(context);
                return value == null ? "" : value.toString();
            }
        } catch (Exception ignored) {}
        return "";
    }

    @JavascriptInterface
    public synchronized void sendEnter() {
        if (remote != null) remote.sendImeEnter();
    }

    @JavascriptInterface
    public synchronized void disconnect() {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putBoolean(SAVED_USER_DISCONNECTED, true)
                .apply();
        cancelScheduledReconnect();
        AndroidRemoteTv activeRemote = remote;
        remote = null;
        if (activeRemote != null) activeRemote.abort();
        ConnectionKeepAliveService.stop(context);
    }

    @JavascriptInterface
    public synchronized void startDiscovery() {
        if (nsdManager == null) nsdManager = (NsdManager) context.getSystemService(Context.NSD_SERVICE);
        discoveredHosts.clear();
        discoverType("_androidtvremote2._tcp.");
        discoverType("_googlecast._tcp.");
    }

    private void discoverType(String serviceType) {
        if (nsdManager == null) return;
        try {
            nsdManager.discoverServices(serviceType, NsdManager.PROTOCOL_DNS_SD, new NsdManager.DiscoveryListener() {
                @Override public void onDiscoveryStarted(String regType) {}
                @Override public void onDiscoveryStopped(String serviceType) {}
                @Override public void onStartDiscoveryFailed(String serviceType, int errorCode) { event("nativeDiscoveryFinished", ""); }
                @Override public void onStopDiscoveryFailed(String serviceType, int errorCode) {}
                @Override public void onServiceLost(NsdServiceInfo serviceInfo) {}
                @Override public void onServiceFound(NsdServiceInfo serviceInfo) {
                    try {
                        nsdManager.resolveService(serviceInfo, new NsdManager.ResolveListener() {
                            @Override public void onResolveFailed(NsdServiceInfo info, int errorCode) {}
                            @Override public void onServiceResolved(NsdServiceInfo info) {
                                String ip = info.getHost() == null ? "" : info.getHost().getHostAddress();
                                if (ip.isEmpty() || !discoveredHosts.add(ip)) return;
                                String protocol = serviceType.startsWith("_googlecast") ? "google_tv_cast" : "android_tv_v2";
                                int port = serviceType.startsWith("_googlecast") ? 8009 : 6467;
                                String name = friendlyDeviceName(info, serviceType);
                                event("nativeDeviceFound", "{\"name\":\"" + json(name) + "\",\"ip\":\"" + json(ip) + "\",\"port\":" + port + ",\"protocol\":\"" + protocol + "\"}");
                            }
                        });
                    } catch (Exception ignored) {}
                }
            });
        } catch (Exception ignored) {}
    }

    private String friendlyDeviceName(NsdServiceInfo info, String serviceType) {
        String name = "";
        try {
            byte[] friendly = info.getAttributes().get("fn");
            if (friendly != null) name = new String(friendly, StandardCharsets.UTF_8).trim();
        } catch (Exception ignored) {}
        if (name.isEmpty()) name = info.getServiceName() == null ? "" : info.getServiceName().trim();
        name = name.replaceAll("\\.(_androidtvremote2|googlecast)\\._tcp\\.?$", "").trim();
        // Do not expose an NSD id/hash as the TV name when no friendly name exists.
        if (name.length() < 2 || name.matches("[0-9a-fA-F:.-]{16,}") || name.contains("._tcp")) {
            name = serviceType.startsWith("_googlecast") ? "Google TV" : "Android TV";
        }
        return name;
    }

    private String json(String value) {
        return value.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    @JavascriptInterface
    public void vibrate(int milliseconds) {
        android.os.Vibrator vibrator = (android.os.Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
        if (vibrator != null) vibrator.vibrate(milliseconds);
    }

    private Remotemessage.RemoteKeyCode keyCode(String key) {
        Map<String, Remotemessage.RemoteKeyCode> map = new HashMap<>();
        map.put("POWER", Remotemessage.RemoteKeyCode.KEYCODE_POWER);
        map.put("HOME", Remotemessage.RemoteKeyCode.KEYCODE_HOME);
        map.put("BACK", Remotemessage.RemoteKeyCode.KEYCODE_BACK);
        map.put("MENU", Remotemessage.RemoteKeyCode.KEYCODE_MENU);
        map.put("SETTINGS", Remotemessage.RemoteKeyCode.KEYCODE_SETTINGS);
        map.put("KEYBOARD", Remotemessage.RemoteKeyCode.KEYCODE_DEL);
        map.put("MIC", Remotemessage.RemoteKeyCode.KEYCODE_VOICE_ASSIST);
        map.put("DPAD_UP", Remotemessage.RemoteKeyCode.KEYCODE_DPAD_UP);
        map.put("DPAD_DOWN", Remotemessage.RemoteKeyCode.KEYCODE_DPAD_DOWN);
        map.put("DPAD_LEFT", Remotemessage.RemoteKeyCode.KEYCODE_DPAD_LEFT);
        map.put("DPAD_RIGHT", Remotemessage.RemoteKeyCode.KEYCODE_DPAD_RIGHT);
        map.put("DPAD_CENTER", Remotemessage.RemoteKeyCode.KEYCODE_DPAD_CENTER);
        map.put("VOLUME_UP", Remotemessage.RemoteKeyCode.KEYCODE_VOLUME_UP);
        map.put("VOLUME_DOWN", Remotemessage.RemoteKeyCode.KEYCODE_VOLUME_DOWN);
        map.put("VOLUME_MUTE", Remotemessage.RemoteKeyCode.KEYCODE_VOLUME_MUTE);
        map.put("PLAY_PAUSE", Remotemessage.RemoteKeyCode.KEYCODE_MEDIA_PLAY_PAUSE);
        map.put("SEEK_FORWARD", Remotemessage.RemoteKeyCode.KEYCODE_MEDIA_FAST_FORWARD);
        map.put("FORWARD_FAST", Remotemessage.RemoteKeyCode.KEYCODE_MEDIA_FAST_FORWARD);
        map.put("REWIND_FAST", Remotemessage.RemoteKeyCode.KEYCODE_MEDIA_REWIND);
        map.put("CHANNEL_UP", Remotemessage.RemoteKeyCode.KEYCODE_CHANNEL_UP);
        map.put("CHANNEL_DOWN", Remotemessage.RemoteKeyCode.KEYCODE_CHANNEL_DOWN);
        return map.get(key);
    }
}
