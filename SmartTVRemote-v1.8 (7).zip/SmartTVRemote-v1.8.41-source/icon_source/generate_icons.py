from pathlib import Path
from PIL import Image

project = Path('/home/ubuntu/workspace/AndroidIDE_SmartTVRemote')
src = Image.open(project / 'icon_source/new_icon.png').convert('RGBA')
size = max(src.size)
canvas = Image.new('RGBA', (size, size), '#000000')
canvas.alpha_composite(src, ((size - src.width) // 2, (size - src.height) // 2))
for density, pixels in [('mdpi', 48), ('hdpi', 72), ('xhdpi', 96), ('xxhdpi', 144), ('xxxhdpi', 192)]:
    folder = project / 'app/src/main/res' / f'mipmap-{density}'
    folder.mkdir(parents=True, exist_ok=True)
    output = canvas.resize((pixels, pixels), Image.Resampling.LANCZOS)
    output.save(folder / 'ic_launcher.png', optimize=True)
    output.save(folder / 'ic_launcher_round.png', optimize=True)
